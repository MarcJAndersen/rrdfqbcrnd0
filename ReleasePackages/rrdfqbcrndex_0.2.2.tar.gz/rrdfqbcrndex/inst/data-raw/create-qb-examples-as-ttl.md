Create turtle version of example files
======================================

This script creates the result and codelist for a simple DEMO table.

``` r
library(rrdfancillary)
library(rrdfcdisc)
library(rrdfqb)
library(rrdfqbcrnd0)
devtools::load_all(pkg="../..")
```

    ## Loading rrdfqbcrndex

All files are stored in the directory

``` r
targetDir<- system.file("extdata/sample-rdf", package="rrdfqbcrndex")
(targetDir)
```

    ## [1] "/home/ma/projects/rrdfqbcrnd0/rrdfqbcrndex/inst/extdata/sample-rdf"

RDF data cubes specified in workbook
------------------------------------

First, get the workbook.

``` r
RDFCubeWorkbook<- system.file("extdata/sample-cfg", "RDFCubeWorkbook.xlsx", package="rrdfqbcrndex")
(RDFCubeWorkbook)
```

    ## [1] "/home/ma/projects/rrdfqbcrnd0/rrdfqbcrndex/inst/extdata/sample-cfg/RDFCubeWorkbook.xlsx"

Create the DM sample cube.

``` r
dm.cube.fn<- BuildCubeFromWorkbook(RDFCubeWorkbook, "DM" )
```

    ## [1] "prefix code: <http://www.example.org/dc/code/>\nprefix cts: <http://rdf.cdisc.org/ct/schema#>\nprefix dcat: <http://www.w3.org/ns/dcat#>\nprefix dct: <http://purl.org/dc/terms/>\nprefix mms: <http://rdf.cdisc.org/mms#>\nprefix owl: <http://www.w3.org/2002/07/owl#>\nprefix pav: <http://purl.org/pav>\nprefix prov: <http://www.w3.org/ns/prov#>\nprefix qb: <http://purl.org/linked-data/cube#>\nprefix rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>\nprefix rdfs: <http://www.w3.org/2000/01/rdf-schema#>\nprefix skos: <http://www.w3.org/2004/02/skos/core#>\nprefix xsd: <http://www.w3.org/2001/XMLSchema#>\nprefix rrdfqbcrnd0: <http://www.example.org/rrdfqbcrnd0/>\nprefix sdtmct: <http://rdf.cdisc.org/sdtm-terminology#>\nprefix dccs: <http://www.example.org/dc/dm/dccs/>\nprefix ds: <http://www.example.org/dc/dm/ds/>\nprefix crnd-dimension: <http://www.example.org/dc/dimension#>\nprefix crnd-attribute: <http://www.example.org/dc/attribute#>\nprefix crnd-measure: <http://www.example.org/dc/measure#>\n \nselect distinct ?DataStructureDefinition ?dimension ?cprefLabel ?cl ?clprefLabel ?vn ?vct ?vnop ?vnval\nwhere {\n   ?DataStructureDefinition a qb:DataStructureDefinition ;\n        qb:component ?component .\n   ?component a qb:ComponentSpecification .\n   ?component qb:dimension ?dimension .\n\n   ?dimension qb:codeList ?c .\n   OPTIONAL { ?c skos:prefLabel ?cprefLabel .   }\n   OPTIONAL { ?c rrdfqbcrnd0:DataSetRefD2RQ ?vnop . }\n   OPTIONAL { ?c rrdfqbcrnd0:R-columnname ?vn . }\n   OPTIONAL { ?c rrdfqbcrnd0:codeType     ?vct .          }\n\n   ?c skos:hasTopConcept ?cl .\n   OPTIONAL { ?cl skos:prefLabel ?clprefLabel . }\n   OPTIONAL { ?cl rrdfqbcrnd0:R-selectionoperator ?vnop . }\n   OPTIONAL { ?cl rrdfqbcrnd0:R-selectionvalue ?vnval .   }\n values ( ?DataStructureDefinition ) {\n(ds:dsd-DM)\n} \n}\norder by ?dimension ?cl ?dimensionrefLabel\n"
    ##    DataStructureDefinition                dimension
    ## 1                ds:dsd-DM    crnd-dimension:factor
    ## 2                ds:dsd-DM    crnd-dimension:factor
    ## 3                ds:dsd-DM    crnd-dimension:factor
    ## 4                ds:dsd-DM    crnd-dimension:factor
    ## 5                ds:dsd-DM    crnd-dimension:factor
    ## 6                ds:dsd-DM    crnd-dimension:factor
    ## 7                ds:dsd-DM crnd-dimension:procedure
    ## 8                ds:dsd-DM crnd-dimension:procedure
    ## 9                ds:dsd-DM crnd-dimension:procedure
    ## 10               ds:dsd-DM crnd-dimension:procedure
    ## 11               ds:dsd-DM crnd-dimension:procedure
    ## 12               ds:dsd-DM crnd-dimension:procedure
    ## 13               ds:dsd-DM crnd-dimension:procedure
    ## 14               ds:dsd-DM      crnd-dimension:race
    ## 15               ds:dsd-DM      crnd-dimension:race
    ## 16               ds:dsd-DM      crnd-dimension:race
    ## 17               ds:dsd-DM      crnd-dimension:race
    ## 18               ds:dsd-DM      crnd-dimension:race
    ## 19               ds:dsd-DM      crnd-dimension:race
    ## 20               ds:dsd-DM      crnd-dimension:race
    ## 21               ds:dsd-DM     crnd-dimension:saffl
    ## 22               ds:dsd-DM     crnd-dimension:saffl
    ## 23               ds:dsd-DM     crnd-dimension:saffl
    ## 24               ds:dsd-DM       crnd-dimension:sex
    ## 25               ds:dsd-DM       crnd-dimension:sex
    ## 26               ds:dsd-DM       crnd-dimension:sex
    ## 27               ds:dsd-DM       crnd-dimension:sex
    ## 28               ds:dsd-DM       crnd-dimension:sex
    ## 29               ds:dsd-DM       crnd-dimension:sex
    ## 30               ds:dsd-DM    crnd-dimension:trt01a
    ## 31               ds:dsd-DM    crnd-dimension:trt01a
    ## 32               ds:dsd-DM    crnd-dimension:trt01a
    ## 33               ds:dsd-DM    crnd-dimension:trt01a
    ## 34               ds:dsd-DM    crnd-dimension:trt01a
    ##                    cprefLabel
    ## 1     Codelist scheme: factor
    ## 2     Codelist scheme: factor
    ## 3     Codelist scheme: factor
    ## 4     Codelist scheme: factor
    ## 5     Codelist scheme: factor
    ## 6     Codelist scheme: factor
    ## 7  Codelist scheme: procedure
    ## 8  Codelist scheme: procedure
    ## 9  Codelist scheme: procedure
    ## 10 Codelist scheme: procedure
    ## 11 Codelist scheme: procedure
    ## 12 Codelist scheme: procedure
    ## 13 Codelist scheme: procedure
    ## 14      Codelist scheme: race
    ## 15      Codelist scheme: race
    ## 16      Codelist scheme: race
    ## 17      Codelist scheme: race
    ## 18      Codelist scheme: race
    ## 19      Codelist scheme: race
    ## 20      Codelist scheme: race
    ## 21     Codelist scheme: saffl
    ## 22     Codelist scheme: saffl
    ## 23     Codelist scheme: saffl
    ## 24       Codelist scheme: sex
    ## 25       Codelist scheme: sex
    ## 26       Codelist scheme: sex
    ## 27       Codelist scheme: sex
    ## 28       Codelist scheme: sex
    ## 29       Codelist scheme: sex
    ## 30    Codelist scheme: trt01a
    ## 31    Codelist scheme: trt01a
    ## 32    Codelist scheme: trt01a
    ## 33    Codelist scheme: trt01a
    ## 34    Codelist scheme: trt01a
    ##                                                     cl
    ## 1                                      code:factor-AGE
    ## 2                                 code:factor-WEIGHTBL
    ## 3                                    code:factor-_ALL_
    ## 4                                code:factor-_NONMISS_
    ## 5                               code:factor-proportion
    ## 6                                 code:factor-quantity
    ## 7                                 code:procedure-count
    ## 8                                   code:procedure-max
    ## 9                                  code:procedure-mean
    ## 10                               code:procedure-median
    ## 11                                  code:procedure-min
    ## 12                              code:procedure-percent
    ## 13                                code:procedure-stdev
    ## 14          code:race-AMERICAN_INDIAN_OR_ALASKA_NATIVE
    ## 15                                     code:race-ASIAN
    ## 16                 code:race-BLACK_OR_AFRICAN_AMERICAN
    ## 17 code:race-NATIVE_HAWAIIAN_OR_OTHER_PACIFIC_ISLANDER
    ## 18                                     code:race-WHITE
    ## 19                                     code:race-_ALL_
    ## 20                                 code:race-_NONMISS_
    ## 21                                        code:saffl-Y
    ## 22                                    code:saffl-_ALL_
    ## 23                                code:saffl-_NONMISS_
    ## 24                                          code:sex-F
    ## 25                                          code:sex-M
    ## 26                                          code:sex-U
    ## 27                                         code:sex-UN
    ## 28                                      code:sex-_ALL_
    ## 29                                  code:sex-_NONMISS_
    ## 30                                 code:trt01a-Placebo
    ## 31                    code:trt01a-Xanomeline_High_Dose
    ## 32                     code:trt01a-Xanomeline_Low_Dose
    ## 33                                   code:trt01a-_ALL_
    ## 34                               code:trt01a-_NONMISS_
    ##                                  clprefLabel        vn  vct
    ## 1                                        AGE    factor DATA
    ## 2                                   WEIGHTBL    factor DATA
    ## 3                                      _ALL_    factor DATA
    ## 4                                  _NONMISS_    factor DATA
    ## 5                                 proportion    factor DATA
    ## 6                                   quantity    factor DATA
    ## 7                                      count procedure DATA
    ## 8                                        max procedure DATA
    ## 9                                       mean procedure DATA
    ## 10                                    median procedure DATA
    ## 11                                       min procedure DATA
    ## 12                                   percent procedure DATA
    ## 13                                     stdev procedure DATA
    ## 14          AMERICAN INDIAN OR ALASKA NATIVE      race SDTM
    ## 15                                     ASIAN      race SDTM
    ## 16                 BLACK OR AFRICAN AMERICAN      race SDTM
    ## 17 NATIVE HAWAIIAN OR OTHER PACIFIC ISLANDER      race SDTM
    ## 18                                     WHITE      race SDTM
    ## 19                                     _ALL_      race SDTM
    ## 20                                 _NONMISS_      race SDTM
    ## 21                                         Y     saffl DATA
    ## 22                                     _ALL_     saffl DATA
    ## 23                                 _NONMISS_     saffl DATA
    ## 24                                         F       sex SDTM
    ## 25                                         M       sex SDTM
    ## 26                                         U       sex SDTM
    ## 27                                        UN       sex SDTM
    ## 28                                     _ALL_       sex SDTM
    ## 29                                 _NONMISS_       sex SDTM
    ## 30                                   Placebo    trt01a DATA
    ## 31                      Xanomeline High Dose    trt01a DATA
    ## 32                       Xanomeline Low Dose    trt01a DATA
    ## 33                                     _ALL_    trt01a DATA
    ## 34                                 _NONMISS_    trt01a DATA
    ##                       vnop                                     vnval
    ## 1                       ==                                       AGE
    ## 2                       ==                                  WEIGHTBL
    ## 3                     <NA>                                      <NA>
    ## 4                     <NA>                                      <NA>
    ## 5                       ==                                proportion
    ## 6                       ==                                  quantity
    ## 7                       ==                                     count
    ## 8                       ==                                       max
    ## 9                       ==                                      mean
    ## 10                      ==                                    median
    ## 11                      ==                                       min
    ## 12                      ==                                   percent
    ## 13                      ==                                     stdev
    ## 14   rrdfqbcrnd0:ADSL_RACE          AMERICAN INDIAN OR ALASKA NATIVE
    ## 15   rrdfqbcrnd0:ADSL_RACE                                     ASIAN
    ## 16   rrdfqbcrnd0:ADSL_RACE                 BLACK OR AFRICAN AMERICAN
    ## 17   rrdfqbcrnd0:ADSL_RACE NATIVE HAWAIIAN OR OTHER PACIFIC ISLANDER
    ## 18   rrdfqbcrnd0:ADSL_RACE                                     WHITE
    ## 19   rrdfqbcrnd0:ADSL_RACE                                      <NA>
    ## 20   rrdfqbcrnd0:ADSL_RACE                                      <NA>
    ## 21  rrdfqbcrnd0:ADSL_SAFFL                                         Y
    ## 22  rrdfqbcrnd0:ADSL_SAFFL                                      <NA>
    ## 23  rrdfqbcrnd0:ADSL_SAFFL                                      <NA>
    ## 24    rrdfqbcrnd0:ADSL_SEX                                         F
    ## 25    rrdfqbcrnd0:ADSL_SEX                                         M
    ## 26    rrdfqbcrnd0:ADSL_SEX                                         U
    ## 27    rrdfqbcrnd0:ADSL_SEX                                        UN
    ## 28    rrdfqbcrnd0:ADSL_SEX                                      <NA>
    ## 29    rrdfqbcrnd0:ADSL_SEX                                      <NA>
    ## 30 rrdfqbcrnd0:ADSL_TRT01A                                   Placebo
    ## 31 rrdfqbcrnd0:ADSL_TRT01A                      Xanomeline High Dose
    ## 32 rrdfqbcrnd0:ADSL_TRT01A                       Xanomeline Low Dose
    ## 33 rrdfqbcrnd0:ADSL_TRT01A                                      <NA>
    ## 34 rrdfqbcrnd0:ADSL_TRT01A                                      <NA>
    ## crnd-dimension:factor crnd-dimension:factor crnd-dimension:factor crnd-dimension:factor crnd-dimension:factor crnd-dimension:factor crnd-dimension:procedure crnd-dimension:procedure crnd-dimension:procedure crnd-dimension:procedure crnd-dimension:procedure crnd-dimension:procedure crnd-dimension:procedure crnd-dimension:race crnd-dimension:race crnd-dimension:race crnd-dimension:race crnd-dimension:race crnd-dimension:race crnd-dimension:race crnd-dimension:saffl crnd-dimension:saffl crnd-dimension:saffl crnd-dimension:sex crnd-dimension:sex crnd-dimension:sex crnd-dimension:sex crnd-dimension:sex crnd-dimension:sex crnd-dimension:trt01a crnd-dimension:trt01a crnd-dimension:trt01a crnd-dimension:trt01a crnd-dimension:trt01a

``` r
cat("DM cube stored as ", dm.cube.fn, "\n")
```

    ## DM cube stored as  /tmp/RtmpTRtZfa/DC-DM-R-V-0-5-2.ttl

``` r
targetFile<- file.path(targetDir,"DC-DM-sample.ttl")

if (file.copy( dm.cube.fn, targetFile, overwrite=TRUE)) {
  cat("DM cube copied to ", normalizePath(targetFile), "\n")
}
```

    ## DM cube copied to  /home/ma/projects/rrdfqbcrnd0/rrdfqbcrndex/inst/extdata/sample-rdf/DC-DM-sample.ttl

Create the AE sample cube.

``` r
ae.cube.fn<- BuildCubeFromWorkbook(RDFCubeWorkbook, "AE" )
```

    ## [1] "prefix code: <http://www.example.org/dc/code/>\nprefix cts: <http://rdf.cdisc.org/ct/schema#>\nprefix dcat: <http://www.w3.org/ns/dcat#>\nprefix dct: <http://purl.org/dc/terms/>\nprefix mms: <http://rdf.cdisc.org/mms#>\nprefix owl: <http://www.w3.org/2002/07/owl#>\nprefix pav: <http://purl.org/pav>\nprefix prov: <http://www.w3.org/ns/prov#>\nprefix qb: <http://purl.org/linked-data/cube#>\nprefix rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>\nprefix rdfs: <http://www.w3.org/2000/01/rdf-schema#>\nprefix skos: <http://www.w3.org/2004/02/skos/core#>\nprefix xsd: <http://www.w3.org/2001/XMLSchema#>\nprefix rrdfqbcrnd0: <http://www.example.org/rrdfqbcrnd0/>\nprefix sdtmct: <http://rdf.cdisc.org/sdtm-terminology#>\nprefix dccs: <http://www.example.org/dc/ae/dccs/>\nprefix ds: <http://www.example.org/dc/ae/ds/>\nprefix crnd-dimension: <http://www.example.org/dc/dimension#>\nprefix crnd-attribute: <http://www.example.org/dc/attribute#>\nprefix crnd-measure: <http://www.example.org/dc/measure#>\n \nselect distinct ?DataStructureDefinition ?dimension ?cprefLabel ?cl ?clprefLabel ?vn ?vct ?vnop ?vnval\nwhere {\n   ?DataStructureDefinition a qb:DataStructureDefinition ;\n        qb:component ?component .\n   ?component a qb:ComponentSpecification .\n   ?component qb:dimension ?dimension .\n\n   ?dimension qb:codeList ?c .\n   OPTIONAL { ?c skos:prefLabel ?cprefLabel .   }\n   OPTIONAL { ?c rrdfqbcrnd0:DataSetRefD2RQ ?vnop . }\n   OPTIONAL { ?c rrdfqbcrnd0:R-columnname ?vn . }\n   OPTIONAL { ?c rrdfqbcrnd0:codeType     ?vct .          }\n\n   ?c skos:hasTopConcept ?cl .\n   OPTIONAL { ?cl skos:prefLabel ?clprefLabel . }\n   OPTIONAL { ?cl rrdfqbcrnd0:R-selectionoperator ?vnop . }\n   OPTIONAL { ?cl rrdfqbcrnd0:R-selectionvalue ?vnval .   }\n values ( ?DataStructureDefinition ) {\n(ds:dsd-AE)\n} \n}\norder by ?dimension ?cl ?dimensionrefLabel\n"
    ##     DataStructureDefinition                dimension
    ## 1                 ds:dsd-AE   crnd-dimension:aedecod
    ## 2                 ds:dsd-AE   crnd-dimension:aedecod
    ## 3                 ds:dsd-AE   crnd-dimension:aedecod
    ## 4                 ds:dsd-AE   crnd-dimension:aedecod
    ## 5                 ds:dsd-AE   crnd-dimension:aedecod
    ## 6                 ds:dsd-AE   crnd-dimension:aedecod
    ## 7                 ds:dsd-AE   crnd-dimension:aedecod
    ## 8                 ds:dsd-AE   crnd-dimension:aedecod
    ## 9                 ds:dsd-AE   crnd-dimension:aedecod
    ## 10                ds:dsd-AE   crnd-dimension:aedecod
    ## 11                ds:dsd-AE   crnd-dimension:aedecod
    ## 12                ds:dsd-AE   crnd-dimension:aedecod
    ## 13                ds:dsd-AE   crnd-dimension:aedecod
    ## 14                ds:dsd-AE   crnd-dimension:aedecod
    ## 15                ds:dsd-AE   crnd-dimension:aedecod
    ## 16                ds:dsd-AE   crnd-dimension:aedecod
    ## 17                ds:dsd-AE   crnd-dimension:aedecod
    ## 18                ds:dsd-AE   crnd-dimension:aedecod
    ## 19                ds:dsd-AE   crnd-dimension:aedecod
    ## 20                ds:dsd-AE   crnd-dimension:aedecod
    ## 21                ds:dsd-AE   crnd-dimension:aedecod
    ## 22                ds:dsd-AE   crnd-dimension:aedecod
    ## 23                ds:dsd-AE   crnd-dimension:aedecod
    ## 24                ds:dsd-AE   crnd-dimension:aedecod
    ## 25                ds:dsd-AE   crnd-dimension:aedecod
    ## 26                ds:dsd-AE   crnd-dimension:aedecod
    ## 27                ds:dsd-AE   crnd-dimension:aedecod
    ## 28                ds:dsd-AE   crnd-dimension:aedecod
    ## 29                ds:dsd-AE   crnd-dimension:aedecod
    ## 30                ds:dsd-AE   crnd-dimension:aedecod
    ## 31                ds:dsd-AE   crnd-dimension:aedecod
    ## 32                ds:dsd-AE   crnd-dimension:aedecod
    ## 33                ds:dsd-AE   crnd-dimension:aedecod
    ## 34                ds:dsd-AE   crnd-dimension:aedecod
    ## 35                ds:dsd-AE   crnd-dimension:aedecod
    ## 36                ds:dsd-AE   crnd-dimension:aedecod
    ## 37                ds:dsd-AE   crnd-dimension:aedecod
    ## 38                ds:dsd-AE   crnd-dimension:aedecod
    ## 39                ds:dsd-AE   crnd-dimension:aedecod
    ## 40                ds:dsd-AE   crnd-dimension:aedecod
    ## 41                ds:dsd-AE   crnd-dimension:aedecod
    ## 42                ds:dsd-AE   crnd-dimension:aedecod
    ## 43                ds:dsd-AE   crnd-dimension:aedecod
    ## 44                ds:dsd-AE   crnd-dimension:aedecod
    ## 45                ds:dsd-AE   crnd-dimension:aedecod
    ## 46                ds:dsd-AE   crnd-dimension:aedecod
    ## 47                ds:dsd-AE   crnd-dimension:aedecod
    ## 48                ds:dsd-AE   crnd-dimension:aedecod
    ## 49                ds:dsd-AE   crnd-dimension:aedecod
    ## 50                ds:dsd-AE   crnd-dimension:aedecod
    ## 51                ds:dsd-AE   crnd-dimension:aedecod
    ## 52                ds:dsd-AE   crnd-dimension:aedecod
    ## 53                ds:dsd-AE   crnd-dimension:aedecod
    ## 54                ds:dsd-AE   crnd-dimension:aedecod
    ## 55                ds:dsd-AE   crnd-dimension:aedecod
    ## 56                ds:dsd-AE   crnd-dimension:aedecod
    ## 57                ds:dsd-AE   crnd-dimension:aedecod
    ## 58                ds:dsd-AE   crnd-dimension:aedecod
    ## 59                ds:dsd-AE   crnd-dimension:aedecod
    ## 60                ds:dsd-AE   crnd-dimension:aedecod
    ## 61                ds:dsd-AE   crnd-dimension:aedecod
    ## 62                ds:dsd-AE   crnd-dimension:aedecod
    ## 63                ds:dsd-AE   crnd-dimension:aedecod
    ## 64                ds:dsd-AE   crnd-dimension:aedecod
    ## 65                ds:dsd-AE   crnd-dimension:aedecod
    ## 66                ds:dsd-AE   crnd-dimension:aedecod
    ## 67                ds:dsd-AE   crnd-dimension:aedecod
    ## 68                ds:dsd-AE   crnd-dimension:aedecod
    ## 69                ds:dsd-AE   crnd-dimension:aedecod
    ## 70                ds:dsd-AE   crnd-dimension:aedecod
    ## 71                ds:dsd-AE   crnd-dimension:aedecod
    ## 72                ds:dsd-AE   crnd-dimension:aedecod
    ## 73                ds:dsd-AE   crnd-dimension:aedecod
    ## 74                ds:dsd-AE   crnd-dimension:aedecod
    ## 75                ds:dsd-AE   crnd-dimension:aedecod
    ## 76                ds:dsd-AE   crnd-dimension:aedecod
    ## 77                ds:dsd-AE   crnd-dimension:aedecod
    ## 78                ds:dsd-AE   crnd-dimension:aedecod
    ## 79                ds:dsd-AE   crnd-dimension:aedecod
    ## 80                ds:dsd-AE   crnd-dimension:aedecod
    ## 81                ds:dsd-AE   crnd-dimension:aedecod
    ## 82                ds:dsd-AE   crnd-dimension:aedecod
    ## 83                ds:dsd-AE   crnd-dimension:aedecod
    ## 84                ds:dsd-AE   crnd-dimension:aedecod
    ## 85                ds:dsd-AE   crnd-dimension:aedecod
    ## 86                ds:dsd-AE   crnd-dimension:aedecod
    ## 87                ds:dsd-AE   crnd-dimension:aedecod
    ## 88                ds:dsd-AE   crnd-dimension:aedecod
    ## 89                ds:dsd-AE   crnd-dimension:aedecod
    ## 90                ds:dsd-AE   crnd-dimension:aedecod
    ## 91                ds:dsd-AE   crnd-dimension:aedecod
    ## 92                ds:dsd-AE   crnd-dimension:aedecod
    ## 93                ds:dsd-AE   crnd-dimension:aedecod
    ## 94                ds:dsd-AE   crnd-dimension:aedecod
    ## 95                ds:dsd-AE   crnd-dimension:aedecod
    ## 96                ds:dsd-AE   crnd-dimension:aedecod
    ## 97                ds:dsd-AE   crnd-dimension:aedecod
    ## 98                ds:dsd-AE   crnd-dimension:aedecod
    ## 99                ds:dsd-AE   crnd-dimension:aedecod
    ## 100               ds:dsd-AE   crnd-dimension:aedecod
    ## 101               ds:dsd-AE   crnd-dimension:aedecod
    ## 102               ds:dsd-AE   crnd-dimension:aedecod
    ## 103               ds:dsd-AE   crnd-dimension:aedecod
    ## 104               ds:dsd-AE   crnd-dimension:aedecod
    ## 105               ds:dsd-AE   crnd-dimension:aedecod
    ## 106               ds:dsd-AE   crnd-dimension:aedecod
    ## 107               ds:dsd-AE   crnd-dimension:aedecod
    ## 108               ds:dsd-AE   crnd-dimension:aedecod
    ## 109               ds:dsd-AE   crnd-dimension:aedecod
    ## 110               ds:dsd-AE   crnd-dimension:aedecod
    ## 111               ds:dsd-AE   crnd-dimension:aedecod
    ## 112               ds:dsd-AE   crnd-dimension:aedecod
    ## 113               ds:dsd-AE   crnd-dimension:aedecod
    ## 114               ds:dsd-AE   crnd-dimension:aedecod
    ## 115               ds:dsd-AE   crnd-dimension:aedecod
    ## 116               ds:dsd-AE   crnd-dimension:aedecod
    ## 117               ds:dsd-AE   crnd-dimension:aedecod
    ## 118               ds:dsd-AE   crnd-dimension:aedecod
    ## 119               ds:dsd-AE   crnd-dimension:aedecod
    ## 120               ds:dsd-AE   crnd-dimension:aedecod
    ## 121               ds:dsd-AE   crnd-dimension:aedecod
    ## 122               ds:dsd-AE   crnd-dimension:aedecod
    ## 123               ds:dsd-AE   crnd-dimension:aedecod
    ## 124               ds:dsd-AE   crnd-dimension:aedecod
    ## 125               ds:dsd-AE   crnd-dimension:aedecod
    ## 126               ds:dsd-AE   crnd-dimension:aedecod
    ## 127               ds:dsd-AE   crnd-dimension:aedecod
    ## 128               ds:dsd-AE   crnd-dimension:aedecod
    ## 129               ds:dsd-AE   crnd-dimension:aedecod
    ## 130               ds:dsd-AE   crnd-dimension:aedecod
    ## 131               ds:dsd-AE   crnd-dimension:aedecod
    ## 132               ds:dsd-AE   crnd-dimension:aedecod
    ## 133               ds:dsd-AE   crnd-dimension:aedecod
    ## 134               ds:dsd-AE   crnd-dimension:aedecod
    ## 135               ds:dsd-AE   crnd-dimension:aedecod
    ## 136               ds:dsd-AE   crnd-dimension:aedecod
    ## 137               ds:dsd-AE   crnd-dimension:aedecod
    ## 138               ds:dsd-AE   crnd-dimension:aedecod
    ## 139               ds:dsd-AE   crnd-dimension:aedecod
    ## 140               ds:dsd-AE   crnd-dimension:aedecod
    ## 141               ds:dsd-AE   crnd-dimension:aedecod
    ## 142               ds:dsd-AE   crnd-dimension:aedecod
    ## 143               ds:dsd-AE   crnd-dimension:aedecod
    ## 144               ds:dsd-AE   crnd-dimension:aedecod
    ## 145               ds:dsd-AE   crnd-dimension:aedecod
    ## 146               ds:dsd-AE   crnd-dimension:aedecod
    ## 147               ds:dsd-AE   crnd-dimension:aedecod
    ## 148               ds:dsd-AE   crnd-dimension:aedecod
    ## 149               ds:dsd-AE   crnd-dimension:aedecod
    ## 150               ds:dsd-AE   crnd-dimension:aedecod
    ## 151               ds:dsd-AE   crnd-dimension:aedecod
    ## 152               ds:dsd-AE   crnd-dimension:aedecod
    ## 153               ds:dsd-AE   crnd-dimension:aedecod
    ## 154               ds:dsd-AE   crnd-dimension:aedecod
    ## 155               ds:dsd-AE   crnd-dimension:aedecod
    ## 156               ds:dsd-AE   crnd-dimension:aedecod
    ## 157               ds:dsd-AE   crnd-dimension:aedecod
    ## 158               ds:dsd-AE   crnd-dimension:aedecod
    ## 159               ds:dsd-AE   crnd-dimension:aedecod
    ## 160               ds:dsd-AE   crnd-dimension:aedecod
    ## 161               ds:dsd-AE   crnd-dimension:aedecod
    ## 162               ds:dsd-AE   crnd-dimension:aedecod
    ## 163               ds:dsd-AE   crnd-dimension:aedecod
    ## 164               ds:dsd-AE   crnd-dimension:aedecod
    ## 165               ds:dsd-AE   crnd-dimension:aedecod
    ## 166               ds:dsd-AE   crnd-dimension:aedecod
    ## 167               ds:dsd-AE   crnd-dimension:aedecod
    ## 168               ds:dsd-AE   crnd-dimension:aedecod
    ## 169               ds:dsd-AE   crnd-dimension:aedecod
    ## 170               ds:dsd-AE   crnd-dimension:aedecod
    ## 171               ds:dsd-AE   crnd-dimension:aedecod
    ## 172               ds:dsd-AE   crnd-dimension:aedecod
    ## 173               ds:dsd-AE   crnd-dimension:aedecod
    ## 174               ds:dsd-AE   crnd-dimension:aedecod
    ## 175               ds:dsd-AE   crnd-dimension:aedecod
    ## 176               ds:dsd-AE   crnd-dimension:aedecod
    ## 177               ds:dsd-AE   crnd-dimension:aedecod
    ## 178               ds:dsd-AE   crnd-dimension:aedecod
    ## 179               ds:dsd-AE   crnd-dimension:aedecod
    ## 180               ds:dsd-AE   crnd-dimension:aedecod
    ## 181               ds:dsd-AE   crnd-dimension:aedecod
    ## 182               ds:dsd-AE   crnd-dimension:aedecod
    ## 183               ds:dsd-AE   crnd-dimension:aedecod
    ## 184               ds:dsd-AE   crnd-dimension:aedecod
    ## 185               ds:dsd-AE   crnd-dimension:aedecod
    ## 186               ds:dsd-AE   crnd-dimension:aedecod
    ## 187               ds:dsd-AE   crnd-dimension:aedecod
    ## 188               ds:dsd-AE   crnd-dimension:aedecod
    ## 189               ds:dsd-AE   crnd-dimension:aedecod
    ## 190               ds:dsd-AE   crnd-dimension:aedecod
    ## 191               ds:dsd-AE   crnd-dimension:aedecod
    ## 192               ds:dsd-AE   crnd-dimension:aedecod
    ## 193               ds:dsd-AE   crnd-dimension:aedecod
    ## 194               ds:dsd-AE   crnd-dimension:aedecod
    ## 195               ds:dsd-AE   crnd-dimension:aedecod
    ## 196               ds:dsd-AE   crnd-dimension:aedecod
    ## 197               ds:dsd-AE   crnd-dimension:aedecod
    ## 198               ds:dsd-AE   crnd-dimension:aedecod
    ## 199               ds:dsd-AE   crnd-dimension:aedecod
    ## 200               ds:dsd-AE   crnd-dimension:aedecod
    ## 201               ds:dsd-AE   crnd-dimension:aedecod
    ## 202               ds:dsd-AE   crnd-dimension:aedecod
    ## 203               ds:dsd-AE   crnd-dimension:aedecod
    ## 204               ds:dsd-AE   crnd-dimension:aedecod
    ## 205               ds:dsd-AE   crnd-dimension:aedecod
    ## 206               ds:dsd-AE   crnd-dimension:aedecod
    ## 207               ds:dsd-AE   crnd-dimension:aedecod
    ## 208               ds:dsd-AE   crnd-dimension:aedecod
    ## 209               ds:dsd-AE   crnd-dimension:aedecod
    ## 210               ds:dsd-AE   crnd-dimension:aedecod
    ## 211               ds:dsd-AE   crnd-dimension:aedecod
    ## 212               ds:dsd-AE   crnd-dimension:aedecod
    ## 213               ds:dsd-AE   crnd-dimension:aedecod
    ## 214               ds:dsd-AE   crnd-dimension:aedecod
    ## 215               ds:dsd-AE   crnd-dimension:aedecod
    ## 216               ds:dsd-AE   crnd-dimension:aedecod
    ## 217               ds:dsd-AE   crnd-dimension:aedecod
    ## 218               ds:dsd-AE   crnd-dimension:aedecod
    ## 219               ds:dsd-AE   crnd-dimension:aedecod
    ## 220               ds:dsd-AE   crnd-dimension:aedecod
    ## 221               ds:dsd-AE   crnd-dimension:aedecod
    ## 222               ds:dsd-AE   crnd-dimension:aedecod
    ## 223               ds:dsd-AE   crnd-dimension:aedecod
    ## 224               ds:dsd-AE   crnd-dimension:aedecod
    ## 225               ds:dsd-AE   crnd-dimension:aedecod
    ## 226               ds:dsd-AE   crnd-dimension:aedecod
    ## 227               ds:dsd-AE   crnd-dimension:aedecod
    ## 228               ds:dsd-AE   crnd-dimension:aedecod
    ## 229               ds:dsd-AE   crnd-dimension:aedecod
    ## 230               ds:dsd-AE   crnd-dimension:aedecod
    ## 231               ds:dsd-AE   crnd-dimension:aedecod
    ## 232               ds:dsd-AE   crnd-dimension:aedecod
    ## 233               ds:dsd-AE   crnd-dimension:aedecod
    ## 234               ds:dsd-AE   crnd-dimension:aedecod
    ## 235               ds:dsd-AE   crnd-dimension:aedecod
    ## 236               ds:dsd-AE   crnd-dimension:aedecod
    ## 237               ds:dsd-AE   crnd-dimension:aedecod
    ## 238               ds:dsd-AE   crnd-dimension:aedecod
    ## 239               ds:dsd-AE   crnd-dimension:aedecod
    ## 240               ds:dsd-AE   crnd-dimension:aedecod
    ## 241               ds:dsd-AE   crnd-dimension:aedecod
    ## 242               ds:dsd-AE   crnd-dimension:aedecod
    ## 243               ds:dsd-AE   crnd-dimension:aedecod
    ## 244               ds:dsd-AE   crnd-dimension:aedecod
    ## 245               ds:dsd-AE     crnd-dimension:aesoc
    ## 246               ds:dsd-AE     crnd-dimension:aesoc
    ## 247               ds:dsd-AE     crnd-dimension:aesoc
    ## 248               ds:dsd-AE     crnd-dimension:aesoc
    ## 249               ds:dsd-AE     crnd-dimension:aesoc
    ## 250               ds:dsd-AE     crnd-dimension:aesoc
    ## 251               ds:dsd-AE     crnd-dimension:aesoc
    ## 252               ds:dsd-AE     crnd-dimension:aesoc
    ## 253               ds:dsd-AE     crnd-dimension:aesoc
    ## 254               ds:dsd-AE     crnd-dimension:aesoc
    ## 255               ds:dsd-AE     crnd-dimension:aesoc
    ## 256               ds:dsd-AE     crnd-dimension:aesoc
    ## 257               ds:dsd-AE     crnd-dimension:aesoc
    ## 258               ds:dsd-AE     crnd-dimension:aesoc
    ## 259               ds:dsd-AE     crnd-dimension:aesoc
    ## 260               ds:dsd-AE     crnd-dimension:aesoc
    ## 261               ds:dsd-AE     crnd-dimension:aesoc
    ## 262               ds:dsd-AE     crnd-dimension:aesoc
    ## 263               ds:dsd-AE     crnd-dimension:aesoc
    ## 264               ds:dsd-AE     crnd-dimension:aesoc
    ## 265               ds:dsd-AE     crnd-dimension:aesoc
    ## 266               ds:dsd-AE     crnd-dimension:aesoc
    ## 267               ds:dsd-AE     crnd-dimension:aesoc
    ## 268               ds:dsd-AE     crnd-dimension:aesoc
    ## 269               ds:dsd-AE     crnd-dimension:aesoc
    ## 270               ds:dsd-AE    crnd-dimension:factor
    ## 271               ds:dsd-AE    crnd-dimension:factor
    ## 272               ds:dsd-AE    crnd-dimension:factor
    ## 273               ds:dsd-AE    crnd-dimension:factor
    ## 274               ds:dsd-AE crnd-dimension:procedure
    ## 275               ds:dsd-AE crnd-dimension:procedure
    ## 276               ds:dsd-AE     crnd-dimension:saffl
    ## 277               ds:dsd-AE     crnd-dimension:saffl
    ## 278               ds:dsd-AE     crnd-dimension:saffl
    ## 279               ds:dsd-AE      crnd-dimension:trta
    ## 280               ds:dsd-AE      crnd-dimension:trta
    ## 281               ds:dsd-AE      crnd-dimension:trta
    ## 282               ds:dsd-AE      crnd-dimension:trta
    ## 283               ds:dsd-AE      crnd-dimension:trta
    ##                     cprefLabel
    ## 1     Codelist scheme: aedecod
    ## 2     Codelist scheme: aedecod
    ## 3     Codelist scheme: aedecod
    ## 4     Codelist scheme: aedecod
    ## 5     Codelist scheme: aedecod
    ## 6     Codelist scheme: aedecod
    ## 7     Codelist scheme: aedecod
    ## 8     Codelist scheme: aedecod
    ## 9     Codelist scheme: aedecod
    ## 10    Codelist scheme: aedecod
    ## 11    Codelist scheme: aedecod
    ## 12    Codelist scheme: aedecod
    ## 13    Codelist scheme: aedecod
    ## 14    Codelist scheme: aedecod
    ## 15    Codelist scheme: aedecod
    ## 16    Codelist scheme: aedecod
    ## 17    Codelist scheme: aedecod
    ## 18    Codelist scheme: aedecod
    ## 19    Codelist scheme: aedecod
    ## 20    Codelist scheme: aedecod
    ## 21    Codelist scheme: aedecod
    ## 22    Codelist scheme: aedecod
    ## 23    Codelist scheme: aedecod
    ## 24    Codelist scheme: aedecod
    ## 25    Codelist scheme: aedecod
    ## 26    Codelist scheme: aedecod
    ## 27    Codelist scheme: aedecod
    ## 28    Codelist scheme: aedecod
    ## 29    Codelist scheme: aedecod
    ## 30    Codelist scheme: aedecod
    ## 31    Codelist scheme: aedecod
    ## 32    Codelist scheme: aedecod
    ## 33    Codelist scheme: aedecod
    ## 34    Codelist scheme: aedecod
    ## 35    Codelist scheme: aedecod
    ## 36    Codelist scheme: aedecod
    ## 37    Codelist scheme: aedecod
    ## 38    Codelist scheme: aedecod
    ## 39    Codelist scheme: aedecod
    ## 40    Codelist scheme: aedecod
    ## 41    Codelist scheme: aedecod
    ## 42    Codelist scheme: aedecod
    ## 43    Codelist scheme: aedecod
    ## 44    Codelist scheme: aedecod
    ## 45    Codelist scheme: aedecod
    ## 46    Codelist scheme: aedecod
    ## 47    Codelist scheme: aedecod
    ## 48    Codelist scheme: aedecod
    ## 49    Codelist scheme: aedecod
    ## 50    Codelist scheme: aedecod
    ## 51    Codelist scheme: aedecod
    ## 52    Codelist scheme: aedecod
    ## 53    Codelist scheme: aedecod
    ## 54    Codelist scheme: aedecod
    ## 55    Codelist scheme: aedecod
    ## 56    Codelist scheme: aedecod
    ## 57    Codelist scheme: aedecod
    ## 58    Codelist scheme: aedecod
    ## 59    Codelist scheme: aedecod
    ## 60    Codelist scheme: aedecod
    ## 61    Codelist scheme: aedecod
    ## 62    Codelist scheme: aedecod
    ## 63    Codelist scheme: aedecod
    ## 64    Codelist scheme: aedecod
    ## 65    Codelist scheme: aedecod
    ## 66    Codelist scheme: aedecod
    ## 67    Codelist scheme: aedecod
    ## 68    Codelist scheme: aedecod
    ## 69    Codelist scheme: aedecod
    ## 70    Codelist scheme: aedecod
    ## 71    Codelist scheme: aedecod
    ## 72    Codelist scheme: aedecod
    ## 73    Codelist scheme: aedecod
    ## 74    Codelist scheme: aedecod
    ## 75    Codelist scheme: aedecod
    ## 76    Codelist scheme: aedecod
    ## 77    Codelist scheme: aedecod
    ## 78    Codelist scheme: aedecod
    ## 79    Codelist scheme: aedecod
    ## 80    Codelist scheme: aedecod
    ## 81    Codelist scheme: aedecod
    ## 82    Codelist scheme: aedecod
    ## 83    Codelist scheme: aedecod
    ## 84    Codelist scheme: aedecod
    ## 85    Codelist scheme: aedecod
    ## 86    Codelist scheme: aedecod
    ## 87    Codelist scheme: aedecod
    ## 88    Codelist scheme: aedecod
    ## 89    Codelist scheme: aedecod
    ## 90    Codelist scheme: aedecod
    ## 91    Codelist scheme: aedecod
    ## 92    Codelist scheme: aedecod
    ## 93    Codelist scheme: aedecod
    ## 94    Codelist scheme: aedecod
    ## 95    Codelist scheme: aedecod
    ## 96    Codelist scheme: aedecod
    ## 97    Codelist scheme: aedecod
    ## 98    Codelist scheme: aedecod
    ## 99    Codelist scheme: aedecod
    ## 100   Codelist scheme: aedecod
    ## 101   Codelist scheme: aedecod
    ## 102   Codelist scheme: aedecod
    ## 103   Codelist scheme: aedecod
    ## 104   Codelist scheme: aedecod
    ## 105   Codelist scheme: aedecod
    ## 106   Codelist scheme: aedecod
    ## 107   Codelist scheme: aedecod
    ## 108   Codelist scheme: aedecod
    ## 109   Codelist scheme: aedecod
    ## 110   Codelist scheme: aedecod
    ## 111   Codelist scheme: aedecod
    ## 112   Codelist scheme: aedecod
    ## 113   Codelist scheme: aedecod
    ## 114   Codelist scheme: aedecod
    ## 115   Codelist scheme: aedecod
    ## 116   Codelist scheme: aedecod
    ## 117   Codelist scheme: aedecod
    ## 118   Codelist scheme: aedecod
    ## 119   Codelist scheme: aedecod
    ## 120   Codelist scheme: aedecod
    ## 121   Codelist scheme: aedecod
    ## 122   Codelist scheme: aedecod
    ## 123   Codelist scheme: aedecod
    ## 124   Codelist scheme: aedecod
    ## 125   Codelist scheme: aedecod
    ## 126   Codelist scheme: aedecod
    ## 127   Codelist scheme: aedecod
    ## 128   Codelist scheme: aedecod
    ## 129   Codelist scheme: aedecod
    ## 130   Codelist scheme: aedecod
    ## 131   Codelist scheme: aedecod
    ## 132   Codelist scheme: aedecod
    ## 133   Codelist scheme: aedecod
    ## 134   Codelist scheme: aedecod
    ## 135   Codelist scheme: aedecod
    ## 136   Codelist scheme: aedecod
    ## 137   Codelist scheme: aedecod
    ## 138   Codelist scheme: aedecod
    ## 139   Codelist scheme: aedecod
    ## 140   Codelist scheme: aedecod
    ## 141   Codelist scheme: aedecod
    ## 142   Codelist scheme: aedecod
    ## 143   Codelist scheme: aedecod
    ## 144   Codelist scheme: aedecod
    ## 145   Codelist scheme: aedecod
    ## 146   Codelist scheme: aedecod
    ## 147   Codelist scheme: aedecod
    ## 148   Codelist scheme: aedecod
    ## 149   Codelist scheme: aedecod
    ## 150   Codelist scheme: aedecod
    ## 151   Codelist scheme: aedecod
    ## 152   Codelist scheme: aedecod
    ## 153   Codelist scheme: aedecod
    ## 154   Codelist scheme: aedecod
    ## 155   Codelist scheme: aedecod
    ## 156   Codelist scheme: aedecod
    ## 157   Codelist scheme: aedecod
    ## 158   Codelist scheme: aedecod
    ## 159   Codelist scheme: aedecod
    ## 160   Codelist scheme: aedecod
    ## 161   Codelist scheme: aedecod
    ## 162   Codelist scheme: aedecod
    ## 163   Codelist scheme: aedecod
    ## 164   Codelist scheme: aedecod
    ## 165   Codelist scheme: aedecod
    ## 166   Codelist scheme: aedecod
    ## 167   Codelist scheme: aedecod
    ## 168   Codelist scheme: aedecod
    ## 169   Codelist scheme: aedecod
    ## 170   Codelist scheme: aedecod
    ## 171   Codelist scheme: aedecod
    ## 172   Codelist scheme: aedecod
    ## 173   Codelist scheme: aedecod
    ## 174   Codelist scheme: aedecod
    ## 175   Codelist scheme: aedecod
    ## 176   Codelist scheme: aedecod
    ## 177   Codelist scheme: aedecod
    ## 178   Codelist scheme: aedecod
    ## 179   Codelist scheme: aedecod
    ## 180   Codelist scheme: aedecod
    ## 181   Codelist scheme: aedecod
    ## 182   Codelist scheme: aedecod
    ## 183   Codelist scheme: aedecod
    ## 184   Codelist scheme: aedecod
    ## 185   Codelist scheme: aedecod
    ## 186   Codelist scheme: aedecod
    ## 187   Codelist scheme: aedecod
    ## 188   Codelist scheme: aedecod
    ## 189   Codelist scheme: aedecod
    ## 190   Codelist scheme: aedecod
    ## 191   Codelist scheme: aedecod
    ## 192   Codelist scheme: aedecod
    ## 193   Codelist scheme: aedecod
    ## 194   Codelist scheme: aedecod
    ## 195   Codelist scheme: aedecod
    ## 196   Codelist scheme: aedecod
    ## 197   Codelist scheme: aedecod
    ## 198   Codelist scheme: aedecod
    ## 199   Codelist scheme: aedecod
    ## 200   Codelist scheme: aedecod
    ## 201   Codelist scheme: aedecod
    ## 202   Codelist scheme: aedecod
    ## 203   Codelist scheme: aedecod
    ## 204   Codelist scheme: aedecod
    ## 205   Codelist scheme: aedecod
    ## 206   Codelist scheme: aedecod
    ## 207   Codelist scheme: aedecod
    ## 208   Codelist scheme: aedecod
    ## 209   Codelist scheme: aedecod
    ## 210   Codelist scheme: aedecod
    ## 211   Codelist scheme: aedecod
    ## 212   Codelist scheme: aedecod
    ## 213   Codelist scheme: aedecod
    ## 214   Codelist scheme: aedecod
    ## 215   Codelist scheme: aedecod
    ## 216   Codelist scheme: aedecod
    ## 217   Codelist scheme: aedecod
    ## 218   Codelist scheme: aedecod
    ## 219   Codelist scheme: aedecod
    ## 220   Codelist scheme: aedecod
    ## 221   Codelist scheme: aedecod
    ## 222   Codelist scheme: aedecod
    ## 223   Codelist scheme: aedecod
    ## 224   Codelist scheme: aedecod
    ## 225   Codelist scheme: aedecod
    ## 226   Codelist scheme: aedecod
    ## 227   Codelist scheme: aedecod
    ## 228   Codelist scheme: aedecod
    ## 229   Codelist scheme: aedecod
    ## 230   Codelist scheme: aedecod
    ## 231   Codelist scheme: aedecod
    ## 232   Codelist scheme: aedecod
    ## 233   Codelist scheme: aedecod
    ## 234   Codelist scheme: aedecod
    ## 235   Codelist scheme: aedecod
    ## 236   Codelist scheme: aedecod
    ## 237   Codelist scheme: aedecod
    ## 238   Codelist scheme: aedecod
    ## 239   Codelist scheme: aedecod
    ## 240   Codelist scheme: aedecod
    ## 241   Codelist scheme: aedecod
    ## 242   Codelist scheme: aedecod
    ## 243   Codelist scheme: aedecod
    ## 244   Codelist scheme: aedecod
    ## 245     Codelist scheme: aesoc
    ## 246     Codelist scheme: aesoc
    ## 247     Codelist scheme: aesoc
    ## 248     Codelist scheme: aesoc
    ## 249     Codelist scheme: aesoc
    ## 250     Codelist scheme: aesoc
    ## 251     Codelist scheme: aesoc
    ## 252     Codelist scheme: aesoc
    ## 253     Codelist scheme: aesoc
    ## 254     Codelist scheme: aesoc
    ## 255     Codelist scheme: aesoc
    ## 256     Codelist scheme: aesoc
    ## 257     Codelist scheme: aesoc
    ## 258     Codelist scheme: aesoc
    ## 259     Codelist scheme: aesoc
    ## 260     Codelist scheme: aesoc
    ## 261     Codelist scheme: aesoc
    ## 262     Codelist scheme: aesoc
    ## 263     Codelist scheme: aesoc
    ## 264     Codelist scheme: aesoc
    ## 265     Codelist scheme: aesoc
    ## 266     Codelist scheme: aesoc
    ## 267     Codelist scheme: aesoc
    ## 268     Codelist scheme: aesoc
    ## 269     Codelist scheme: aesoc
    ## 270    Codelist scheme: factor
    ## 271    Codelist scheme: factor
    ## 272    Codelist scheme: factor
    ## 273    Codelist scheme: factor
    ## 274 Codelist scheme: procedure
    ## 275 Codelist scheme: procedure
    ## 276     Codelist scheme: saffl
    ## 277     Codelist scheme: saffl
    ## 278     Codelist scheme: saffl
    ## 279      Codelist scheme: trta
    ## 280      Codelist scheme: trta
    ## 281      Codelist scheme: trta
    ## 282      Codelist scheme: trta
    ## 283      Codelist scheme: trta
    ##                                                                                 cl
    ## 1                                                code:aedecod-ABDOMINAL_DISCOMFORT
    ## 2                                                      code:aedecod-ABDOMINAL_PAIN
    ## 3                                                code:aedecod-ACROCHORDON_EXCISION
    ## 4                                                   code:aedecod-ACTINIC_KERATOSIS
    ## 5                                                           code:aedecod-AGITATION
    ## 6                                                         code:aedecod-ALCOHOL_USE
    ## 7                                     code:aedecod-ALLERGIC_GRANULOMATOUS_ANGIITIS
    ## 8                                                            code:aedecod-ALOPECIA
    ## 9                                                             code:aedecod-AMNESIA
    ## 10                                                            code:aedecod-ANXIETY
    ## 11                                          code:aedecod-APPLICATION_SITE_BLEEDING
    ## 12                                        code:aedecod-APPLICATION_SITE_DERMATITIS
    ## 13                                      code:aedecod-APPLICATION_SITE_DESQUAMATION
    ## 14                                         code:aedecod-APPLICATION_SITE_DISCHARGE
    ## 15                                    code:aedecod-APPLICATION_SITE_DISCOLOURATION
    ## 16                                          code:aedecod-APPLICATION_SITE_ERYTHEMA
    ## 17                                        code:aedecod-APPLICATION_SITE_INDURATION
    ## 18                                        code:aedecod-APPLICATION_SITE_IRRITATION
    ## 19                                              code:aedecod-APPLICATION_SITE_PAIN
    ## 20                                      code:aedecod-APPLICATION_SITE_PERSPIRATION
    ## 21                                          code:aedecod-APPLICATION_SITE_PRURITUS
    ## 22                                          code:aedecod-APPLICATION_SITE_REACTION
    ## 23                                          code:aedecod-APPLICATION_SITE_SWELLING
    ## 24                                         code:aedecod-APPLICATION_SITE_URTICARIA
    ## 25                                          code:aedecod-APPLICATION_SITE_VESICLES
    ## 26                                            code:aedecod-APPLICATION_SITE_WARMTH
    ## 27                                                         code:aedecod-ARTHRALGIA
    ## 28                                                          code:aedecod-ARTHRITIS
    ## 29                                                           code:aedecod-ASTHENIA
    ## 30                                                code:aedecod-ATRIAL_FIBRILLATION
    ## 31                                                     code:aedecod-ATRIAL_FLUTTER
    ## 32                                                 code:aedecod-ATRIAL_HYPERTROPHY
    ## 33                                code:aedecod-ATRIOVENTRICULAR_BLOCK_FIRST_DEGREE
    ## 34                               code:aedecod-ATRIOVENTRICULAR_BLOCK_SECOND_DEGREE
    ## 35                                                          code:aedecod-BACK_PAIN
    ## 36                                                   code:aedecod-BALANCE_DISORDER
    ## 37                                       code:aedecod-BENIGN_PROSTATIC_HYPERPLASIA
    ## 38                                                             code:aedecod-BIOPSY
    ## 39                                                    code:aedecod-BIOPSY_PROSTATE
    ## 40                                                            code:aedecod-BLISTER
    ## 41                               code:aedecod-BLOOD_ALKALINE_PHOSPHATASE_INCREASED
    ## 42                                        code:aedecod-BLOOD_CHOLESTEROL_INCREASED
    ## 43                             code:aedecod-BLOOD_CREATINE_PHOSPHOKINASE_INCREASED
    ## 44                                            code:aedecod-BLOOD_GLUCOSE_INCREASED
    ## 45                                                code:aedecod-BLOOD_URINE_PRESENT
    ## 46                                         code:aedecod-BODY_TEMPERATURE_INCREASED
    ## 47                                                        code:aedecod-BRADYCARDIA
    ## 48                                                         code:aedecod-BRONCHITIS
    ## 49                                           code:aedecod-BUNDLE_BRANCH_BLOCK_LEFT
    ## 50                                          code:aedecod-BUNDLE_BRANCH_BLOCK_RIGHT
    ## 51                                                  code:aedecod-BURNING_SENSATION
    ## 52                                                  code:aedecod-CALCULUS_URETHRAL
    ## 53                                                   code:aedecod-CARDIAC_DISORDER
    ## 54                                         code:aedecod-CARDIAC_FAILURE_CONGESTIVE
    ## 55                                                 code:aedecod-CATARACT_OPERATION
    ## 56                                                         code:aedecod-CELLULITIS
    ## 57                                                  code:aedecod-CERUMEN_IMPACTION
    ## 58                                                         code:aedecod-CERVICITIS
    ## 59                                                   code:aedecod-CHEST_DISCOMFORT
    ## 60                                                         code:aedecod-CHEST_PAIN
    ## 61                                                             code:aedecod-CHILLS
    ## 62                                                 code:aedecod-COGNITIVE_DISORDER
    ## 63                                                         code:aedecod-COLD_SWEAT
    ## 64                                                       code:aedecod-COLON_CANCER
    ## 65                                                  code:aedecod-COMPLETED_SUICIDE
    ## 66                                           code:aedecod-COMPLEX_PARTIAL_SEIZURES
    ## 67                                                  code:aedecod-CONFUSIONAL_STATE
    ## 68                                           code:aedecod-CONJUNCTIVAL_HAEMORRHAGE
    ## 69                                                     code:aedecod-CONJUNCTIVITIS
    ## 70                                                       code:aedecod-CONSTIPATION
    ## 71                                                          code:aedecod-CONTUSION
    ## 72                                              code:aedecod-COORDINATION_ABNORMAL
    ## 73                                                              code:aedecod-COUGH
    ## 74                                                               code:aedecod-CYST
    ## 75                                                           code:aedecod-CYSTITIS
    ## 76                                                         code:aedecod-CYSTOSCOPY
    ## 77                                                 code:aedecod-DECREASED_APPETITE
    ## 78                                                        code:aedecod-DEHYDRATION
    ## 79                                                           code:aedecod-DELIRIUM
    ## 80                                                           code:aedecod-DELUSION
    ## 81                                                     code:aedecod-DEPRESSED_MOOD
    ## 82                                                  code:aedecod-DERMATITIS_ATOPIC
    ## 83                                                 code:aedecod-DERMATITIS_CONTACT
    ## 84                                                  code:aedecod-DIABETES_MELLITUS
    ## 85                                                          code:aedecod-DIARRHOEA
    ## 86                                                     code:aedecod-DISORIENTATION
    ## 87                                                          code:aedecod-DIZZINESS
    ## 88                                                      code:aedecod-DRUG_ERUPTION
    ## 89                                                          code:aedecod-DYSPEPSIA
    ## 90                                                          code:aedecod-DYSPHAGIA
    ## 91                                                          code:aedecod-DYSPHONIA
    ## 92                                                           code:aedecod-DYSPNOEA
    ## 93                                                            code:aedecod-DYSURIA
    ## 94                                                      code:aedecod-EAR_INFECTION
    ## 95                                                           code:aedecod-EAR_PAIN
    ## 96                            code:aedecod-ELECTROCARDIOGRAM_ST_SEGMENT_DEPRESSION
    ## 97                       code:aedecod-ELECTROCARDIOGRAM_T_WAVE_AMPLITUDE_DECREASED
    ## 98                                 code:aedecod-ELECTROCARDIOGRAM_T_WAVE_INVERSION
    ## 99                                                          code:aedecod-EMPHYSEMA
    ## 100                                                          code:aedecod-ENURESIS
    ## 101                                                         code:aedecod-EPISTAXIS
    ## 102                                                          code:aedecod-ERYTHEMA
    ## 103                                                       code:aedecod-EXCORIATION
    ## 104                                                       code:aedecod-EYE_ALLERGY
    ## 105                                                 code:aedecod-EYE_LASER_SURGERY
    ## 106                                                      code:aedecod-EYE_PRURITUS
    ## 107                                                      code:aedecod-EYE_SWELLING
    ## 108                                             code:aedecod-FACIAL_BONES_FRACTURE
    ## 109                                                              code:aedecod-FALL
    ## 110                                                           code:aedecod-FATIGUE
    ## 111                                                  code:aedecod-FEELING_ABNORMAL
    ## 112                                                      code:aedecod-FEELING_COLD
    ## 113                                                        code:aedecod-FLANK_PAIN
    ## 114                                                        code:aedecod-FLATULENCE
    ## 115                                                      code:aedecod-FOOD_CRAVING
    ## 116                                             code:aedecod-GASTROENTERITIS_VIRAL
    ## 117                                      code:aedecod-GASTROINTESTINAL_HAEMORRHAGE
    ## 118                                  code:aedecod-GASTROOESOPHAGEAL_REFLUX_DISEASE
    ## 119                                                          code:aedecod-GLAUCOMA
    ## 120                                                         code:aedecod-GLOSSITIS
    ## 121                                                       code:aedecod-HAEMOPTYSIS
    ## 122                                                     code:aedecod-HALLUCINATION
    ## 123                                             code:aedecod-HALLUCINATION__VISUAL
    ## 124                                                          code:aedecod-HEADACHE
    ## 125                                              code:aedecod-HEART_RATE_INCREASED
    ## 126                                              code:aedecod-HEART_RATE_IRREGULAR
    ## 127                                             code:aedecod-HEMIANOPIA_HOMONYMOUS
    ## 128                                                     code:aedecod-HIATUS_HERNIA
    ## 129                                                      code:aedecod-HIP_FRACTURE
    ## 130                                                         code:aedecod-HORDEOLUM
    ## 131                                                         code:aedecod-HOT_FLUSH
    ## 132                                               code:aedecod-HYPERBILIRUBINAEMIA
    ## 133                                             code:aedecod-HYPERCHOLESTEROLAEMIA
    ## 134                                                     code:aedecod-HYPERHIDROSIS
    ## 135                                                  code:aedecod-HYPERSENSITIVITY
    ## 136                                                       code:aedecod-HYPERSOMNIA
    ## 137                                                      code:aedecod-HYPERTENSION
    ## 138                                                     code:aedecod-HYPONATRAEMIA
    ## 139                                                       code:aedecod-HYPOTENSION
    ## 140                                                      code:aedecod-INCONTINENCE
    ## 141                                                code:aedecod-INCREASED_APPETITE
    ## 142                                                      code:aedecod-INFLAMMATION
    ## 143                                                         code:aedecod-INFLUENZA
    ## 144                                                          code:aedecod-INSOMNIA
    ## 145                                                      code:aedecod-IRRITABILITY
    ## 146                                                 code:aedecod-JOINT_DISLOCATION
    ## 147                                                          code:aedecod-LETHARGY
    ## 148                                                  code:aedecod-LIBIDO_DECREASED
    ## 149                                                          code:aedecod-LISTLESS
    ## 150                                               code:aedecod-LOCALISED_INFECTION
    ## 151                                 code:aedecod-LOWER_RESPIRATORY_TRACT_INFECTION
    ## 152                                                           code:aedecod-MALAISE
    ## 153                                    code:aedecod-MALIGNANT_FIBROUS_HISTIOCYTOMA
    ## 154                                               code:aedecod-MICTURITION_URGENCY
    ## 155                                                     code:aedecod-MUSCLE_SPASMS
    ## 156                                                 code:aedecod-MUSCULAR_WEAKNESS
    ## 157                                                           code:aedecod-MYALGIA
    ## 158                                             code:aedecod-MYOCARDIAL_INFARCTION
    ## 159                                                  code:aedecod-NASAL_CONGESTION
    ## 160                                               code:aedecod-NASAL_MUCOSA_BIOPSY
    ## 161                                                   code:aedecod-NASOPHARYNGITIS
    ## 162                                                            code:aedecod-NAUSEA
    ## 163                                                   code:aedecod-NEPHROLITHIASIS
    ## 164                                        code:aedecod-NEUTROPHIL_COUNT_INCREASED
    ## 165                                                         code:aedecod-NIGHTMARE
    ## 166                                                            code:aedecod-OEDEMA
    ## 167                                                 code:aedecod-OEDEMA_PERIPHERAL
    ## 168                                                     code:aedecod-ONYCHOMYCOSIS
    ## 169                                           code:aedecod-ORTHOSTATIC_HYPOTENSION
    ## 170                                                              code:aedecod-PAIN
    ## 171                                                 code:aedecod-PAIN_IN_EXTREMITY
    ## 172                                                      code:aedecod-PALPITATIONS
    ## 173                                                      code:aedecod-PARAESTHESIA
    ## 174                                                 code:aedecod-PARAESTHESIA_ORAL
    ## 175                                               code:aedecod-PARKINSON_S_DISEASE
    ## 176                                                          code:aedecod-PAROSMIA
    ## 177                    code:aedecod-PARTIAL_SEIZURES_WITH_SECONDARY_GENERALISATION
    ## 178                                                       code:aedecod-PELVIC_PAIN
    ## 179                                               code:aedecod-PHARYNGEAL_ERYTHEMA
    ## 180                                            code:aedecod-PHARYNGOLARYNGEAL_PAIN
    ## 181                                                         code:aedecod-PNEUMONIA
    ## 182                                                       code:aedecod-POLLAKIURIA
    ## 183                                                    code:aedecod-POSTNASAL_DRIP
    ## 184                                                  code:aedecod-PRODUCTIVE_COUGH
    ## 185                                                   code:aedecod-PROSTATE_CANCER
    ## 186                                                          code:aedecod-PRURITUS
    ## 187                                              code:aedecod-PRURITUS_GENERALISED
    ## 188                                         code:aedecod-PSYCHOMOTOR_HYPERACTIVITY
    ## 189                                                           code:aedecod-PYREXIA
    ## 190                                                             code:aedecod-RALES
    ## 191                                                              code:aedecod-RASH
    ## 192                                                 code:aedecod-RASH_ERYTHEMATOUS
    ## 193                                               code:aedecod-RASH_MACULO-PAPULAR
    ## 194                                                      code:aedecod-RASH_PAPULAR
    ## 195                                                     code:aedecod-RASH_PRURITIC
    ## 196                                                code:aedecod-RECTAL_HAEMORRHAGE
    ## 197                                      code:aedecod-RESPIRATORY_TRACT_CONGESTION
    ## 198                                                      code:aedecod-RESTLESSNESS
    ## 199                                                          code:aedecod-RHINITIS
    ## 200                                                       code:aedecod-RHINORRHOEA
    ## 201                                           code:aedecod-SALIVARY_HYPERSECRETION
    ## 202                                                  code:aedecod-SEASONAL_ALLERGY
    ## 203                                               code:aedecod-SECRETION_DISCHARGE
    ## 204                                                     code:aedecod-SHOULDER_PAIN
    ## 205                                                  code:aedecod-SINUS_ARRHYTHMIA
    ## 206                                                 code:aedecod-SINUS_BRADYCARDIA
    ## 207                                                  code:aedecod-SKIN_EXFOLIATION
    ## 208                                                   code:aedecod-SKIN_IRRITATION
    ## 209                                                   code:aedecod-SKIN_LACERATION
    ## 210                                              code:aedecod-SKIN_LESION_EXCISION
    ## 211                                               code:aedecod-SKIN_ODOUR_ABNORMAL
    ## 212                                                        code:aedecod-SKIN_ULCER
    ## 213                                                        code:aedecod-SOMNOLENCE
    ## 214                                                code:aedecod-STOMACH_DISCOMFORT
    ## 215                                                            code:aedecod-STUPOR
    ## 216                                                      code:aedecod-SUDDEN_DEATH
    ## 217                                    code:aedecod-SUPRAVENTRICULAR_EXTRASYSTOLES
    ## 218                                      code:aedecod-SUPRAVENTRICULAR_TACHYCARDIA
    ## 219                                                          code:aedecod-SWELLING
    ## 220                                                           code:aedecod-SYNCOPE
    ## 221                                                 code:aedecod-SYNCOPE_VASOVAGAL
    ## 222                                                       code:aedecod-TACHYCARDIA
    ## 223                                                          code:aedecod-TINNITUS
    ## 224                                        code:aedecod-TRANSIENT_ISCHAEMIC_ATTACK
    ## 225                                                             code:aedecod-ULCER
    ## 226                                 code:aedecod-UPPER_RESPIRATORY_TRACT_INFECTION
    ## 227                                           code:aedecod-URINARY_TRACT_INFECTION
    ## 228                                           code:aedecod-URINE_ANALYSIS_ABNORMAL
    ## 229                                                         code:aedecod-URTICARIA
    ## 230                                                   code:aedecod-VAGINAL_MYCOSIS
    ## 231                                         code:aedecod-VENTRICULAR_EXTRASYSTOLES
    ## 232                                           code:aedecod-VENTRICULAR_HYPERTROPHY
    ## 233                                         code:aedecod-VENTRICULAR_SEPTAL_DEFECT
    ## 234                                                           code:aedecod-VERTIGO
    ## 235                                                   code:aedecod-VIRAL_INFECTION
    ## 236                                                    code:aedecod-VISION_BLURRED
    ## 237                                                          code:aedecod-VOMITING
    ## 238                                                  code:aedecod-WEIGHT_DECREASED
    ## 239                                  code:aedecod-WHITE_BLOOD_CELL_COUNT_INCREASED
    ## 240                                    code:aedecod-WOLFF-PARKINSON-WHITE_SYNDROME
    ## 241                                                             code:aedecod-WOUND
    ## 242                                                 code:aedecod-WOUND_HAEMORRHAGE
    ## 243                                                             code:aedecod-_ALL_
    ## 244                                                         code:aedecod-_NONMISS_
    ## 245                                                   code:aesoc-CARDIAC_DISORDERS
    ## 246                          code:aesoc-CONGENITAL__FAMILIAL_AND_GENETIC_DISORDERS
    ## 247                                         code:aesoc-EAR_AND_LABYRINTH_DISORDERS
    ## 248                                                       code:aesoc-EYE_DISORDERS
    ## 249                                          code:aesoc-GASTROINTESTINAL_DISORDERS
    ## 250                code:aesoc-GENERAL_DISORDERS_AND_ADMINISTRATION_SITE_CONDITIONS
    ## 251                                             code:aesoc-HEPATOBILIARY_DISORDERS
    ## 252                                             code:aesoc-IMMUNE_SYSTEM_DISORDERS
    ## 253                                         code:aesoc-INFECTIONS_AND_INFESTATIONS
    ## 254                      code:aesoc-INJURY__POISONING_AND_PROCEDURAL_COMPLICATIONS
    ## 255                                                      code:aesoc-INVESTIGATIONS
    ## 256                                  code:aesoc-METABOLISM_AND_NUTRITION_DISORDERS
    ## 257                     code:aesoc-MUSCULOSKELETAL_AND_CONNECTIVE_TISSUE_DISORDERS
    ## 258 code:aesoc-NEOPLASMS_BENIGN__MALIGNANT_AND_UNSPECIFIED__INCL_CYSTS_AND_POLYPS_
    ## 259                                            code:aesoc-NERVOUS_SYSTEM_DISORDERS
    ## 260                                               code:aesoc-PSYCHIATRIC_DISORDERS
    ## 261                                         code:aesoc-RENAL_AND_URINARY_DISORDERS
    ## 262                            code:aesoc-REPRODUCTIVE_SYSTEM_AND_BREAST_DISORDERS
    ## 263                     code:aesoc-RESPIRATORY__THORACIC_AND_MEDIASTINAL_DISORDERS
    ## 264                              code:aesoc-SKIN_AND_SUBCUTANEOUS_TISSUE_DISORDERS
    ## 265                                                code:aesoc-SOCIAL_CIRCUMSTANCES
    ## 266                                     code:aesoc-SURGICAL_AND_MEDICAL_PROCEDURES
    ## 267                                                  code:aesoc-VASCULAR_DISORDERS
    ## 268                                                               code:aesoc-_ALL_
    ## 269                                                           code:aesoc-_NONMISS_
    ## 270                                                            code:factor-USUBJID
    ## 271                                                              code:factor-_ALL_
    ## 272                                                          code:factor-_NONMISS_
    ## 273                                                           code:factor-quantity
    ## 274                                                           code:procedure-count
    ## 275                                                   code:procedure-countdistinct
    ## 276                                                                   code:saffl-Y
    ## 277                                                               code:saffl-_ALL_
    ## 278                                                           code:saffl-_NONMISS_
    ## 279                                                              code:trta-Placebo
    ## 280                                                 code:trta-Xanomeline_High_Dose
    ## 281                                                  code:trta-Xanomeline_Low_Dose
    ## 282                                                                code:trta-_ALL_
    ## 283                                                            code:trta-_NONMISS_
    ##                                                             clprefLabel
    ## 1                                                  ABDOMINAL DISCOMFORT
    ## 2                                                        ABDOMINAL PAIN
    ## 3                                                  ACROCHORDON EXCISION
    ## 4                                                     ACTINIC KERATOSIS
    ## 5                                                             AGITATION
    ## 6                                                           ALCOHOL USE
    ## 7                                       ALLERGIC GRANULOMATOUS ANGIITIS
    ## 8                                                              ALOPECIA
    ## 9                                                               AMNESIA
    ## 10                                                              ANXIETY
    ## 11                                            APPLICATION SITE BLEEDING
    ## 12                                          APPLICATION SITE DERMATITIS
    ## 13                                        APPLICATION SITE DESQUAMATION
    ## 14                                           APPLICATION SITE DISCHARGE
    ## 15                                      APPLICATION SITE DISCOLOURATION
    ## 16                                            APPLICATION SITE ERYTHEMA
    ## 17                                          APPLICATION SITE INDURATION
    ## 18                                          APPLICATION SITE IRRITATION
    ## 19                                                APPLICATION SITE PAIN
    ## 20                                        APPLICATION SITE PERSPIRATION
    ## 21                                            APPLICATION SITE PRURITUS
    ## 22                                            APPLICATION SITE REACTION
    ## 23                                            APPLICATION SITE SWELLING
    ## 24                                           APPLICATION SITE URTICARIA
    ## 25                                            APPLICATION SITE VESICLES
    ## 26                                              APPLICATION SITE WARMTH
    ## 27                                                           ARTHRALGIA
    ## 28                                                            ARTHRITIS
    ## 29                                                             ASTHENIA
    ## 30                                                  ATRIAL FIBRILLATION
    ## 31                                                       ATRIAL FLUTTER
    ## 32                                                   ATRIAL HYPERTROPHY
    ## 33                                  ATRIOVENTRICULAR BLOCK FIRST DEGREE
    ## 34                                 ATRIOVENTRICULAR BLOCK SECOND DEGREE
    ## 35                                                            BACK PAIN
    ## 36                                                     BALANCE DISORDER
    ## 37                                         BENIGN PROSTATIC HYPERPLASIA
    ## 38                                                               BIOPSY
    ## 39                                                      BIOPSY PROSTATE
    ## 40                                                              BLISTER
    ## 41                                 BLOOD ALKALINE PHOSPHATASE INCREASED
    ## 42                                          BLOOD CHOLESTEROL INCREASED
    ## 43                               BLOOD CREATINE PHOSPHOKINASE INCREASED
    ## 44                                              BLOOD GLUCOSE INCREASED
    ## 45                                                  BLOOD URINE PRESENT
    ## 46                                           BODY TEMPERATURE INCREASED
    ## 47                                                          BRADYCARDIA
    ## 48                                                           BRONCHITIS
    ## 49                                             BUNDLE BRANCH BLOCK LEFT
    ## 50                                            BUNDLE BRANCH BLOCK RIGHT
    ## 51                                                    BURNING SENSATION
    ## 52                                                    CALCULUS URETHRAL
    ## 53                                                     CARDIAC DISORDER
    ## 54                                           CARDIAC FAILURE CONGESTIVE
    ## 55                                                   CATARACT OPERATION
    ## 56                                                           CELLULITIS
    ## 57                                                    CERUMEN IMPACTION
    ## 58                                                           CERVICITIS
    ## 59                                                     CHEST DISCOMFORT
    ## 60                                                           CHEST PAIN
    ## 61                                                               CHILLS
    ## 62                                                   COGNITIVE DISORDER
    ## 63                                                           COLD SWEAT
    ## 64                                                         COLON CANCER
    ## 65                                                    COMPLETED SUICIDE
    ## 66                                             COMPLEX PARTIAL SEIZURES
    ## 67                                                    CONFUSIONAL STATE
    ## 68                                             CONJUNCTIVAL HAEMORRHAGE
    ## 69                                                       CONJUNCTIVITIS
    ## 70                                                         CONSTIPATION
    ## 71                                                            CONTUSION
    ## 72                                                COORDINATION ABNORMAL
    ## 73                                                                COUGH
    ## 74                                                                 CYST
    ## 75                                                             CYSTITIS
    ## 76                                                           CYSTOSCOPY
    ## 77                                                   DECREASED APPETITE
    ## 78                                                          DEHYDRATION
    ## 79                                                             DELIRIUM
    ## 80                                                             DELUSION
    ## 81                                                       DEPRESSED MOOD
    ## 82                                                    DERMATITIS ATOPIC
    ## 83                                                   DERMATITIS CONTACT
    ## 84                                                    DIABETES MELLITUS
    ## 85                                                            DIARRHOEA
    ## 86                                                       DISORIENTATION
    ## 87                                                            DIZZINESS
    ## 88                                                        DRUG ERUPTION
    ## 89                                                            DYSPEPSIA
    ## 90                                                            DYSPHAGIA
    ## 91                                                            DYSPHONIA
    ## 92                                                             DYSPNOEA
    ## 93                                                              DYSURIA
    ## 94                                                        EAR INFECTION
    ## 95                                                             EAR PAIN
    ## 96                              ELECTROCARDIOGRAM ST SEGMENT DEPRESSION
    ## 97                         ELECTROCARDIOGRAM T WAVE AMPLITUDE DECREASED
    ## 98                                   ELECTROCARDIOGRAM T WAVE INVERSION
    ## 99                                                            EMPHYSEMA
    ## 100                                                            ENURESIS
    ## 101                                                           EPISTAXIS
    ## 102                                                            ERYTHEMA
    ## 103                                                         EXCORIATION
    ## 104                                                         EYE ALLERGY
    ## 105                                                   EYE LASER SURGERY
    ## 106                                                        EYE PRURITUS
    ## 107                                                        EYE SWELLING
    ## 108                                               FACIAL BONES FRACTURE
    ## 109                                                                FALL
    ## 110                                                             FATIGUE
    ## 111                                                    FEELING ABNORMAL
    ## 112                                                        FEELING COLD
    ## 113                                                          FLANK PAIN
    ## 114                                                          FLATULENCE
    ## 115                                                        FOOD CRAVING
    ## 116                                               GASTROENTERITIS VIRAL
    ## 117                                        GASTROINTESTINAL HAEMORRHAGE
    ## 118                                    GASTROOESOPHAGEAL REFLUX DISEASE
    ## 119                                                            GLAUCOMA
    ## 120                                                           GLOSSITIS
    ## 121                                                         HAEMOPTYSIS
    ## 122                                                       HALLUCINATION
    ## 123                                               HALLUCINATION, VISUAL
    ## 124                                                            HEADACHE
    ## 125                                                HEART RATE INCREASED
    ## 126                                                HEART RATE IRREGULAR
    ## 127                                               HEMIANOPIA HOMONYMOUS
    ## 128                                                       HIATUS HERNIA
    ## 129                                                        HIP FRACTURE
    ## 130                                                           HORDEOLUM
    ## 131                                                           HOT FLUSH
    ## 132                                                 HYPERBILIRUBINAEMIA
    ## 133                                               HYPERCHOLESTEROLAEMIA
    ## 134                                                       HYPERHIDROSIS
    ## 135                                                    HYPERSENSITIVITY
    ## 136                                                         HYPERSOMNIA
    ## 137                                                        HYPERTENSION
    ## 138                                                       HYPONATRAEMIA
    ## 139                                                         HYPOTENSION
    ## 140                                                        INCONTINENCE
    ## 141                                                  INCREASED APPETITE
    ## 142                                                        INFLAMMATION
    ## 143                                                           INFLUENZA
    ## 144                                                            INSOMNIA
    ## 145                                                        IRRITABILITY
    ## 146                                                   JOINT DISLOCATION
    ## 147                                                            LETHARGY
    ## 148                                                    LIBIDO DECREASED
    ## 149                                                            LISTLESS
    ## 150                                                 LOCALISED INFECTION
    ## 151                                   LOWER RESPIRATORY TRACT INFECTION
    ## 152                                                             MALAISE
    ## 153                                      MALIGNANT FIBROUS HISTIOCYTOMA
    ## 154                                                 MICTURITION URGENCY
    ## 155                                                       MUSCLE SPASMS
    ## 156                                                   MUSCULAR WEAKNESS
    ## 157                                                             MYALGIA
    ## 158                                               MYOCARDIAL INFARCTION
    ## 159                                                    NASAL CONGESTION
    ## 160                                                 NASAL MUCOSA BIOPSY
    ## 161                                                     NASOPHARYNGITIS
    ## 162                                                              NAUSEA
    ## 163                                                     NEPHROLITHIASIS
    ## 164                                          NEUTROPHIL COUNT INCREASED
    ## 165                                                           NIGHTMARE
    ## 166                                                              OEDEMA
    ## 167                                                   OEDEMA PERIPHERAL
    ## 168                                                       ONYCHOMYCOSIS
    ## 169                                             ORTHOSTATIC HYPOTENSION
    ## 170                                                                PAIN
    ## 171                                                   PAIN IN EXTREMITY
    ## 172                                                        PALPITATIONS
    ## 173                                                        PARAESTHESIA
    ## 174                                                   PARAESTHESIA ORAL
    ## 175                                                 PARKINSON'S DISEASE
    ## 176                                                            PAROSMIA
    ## 177                      PARTIAL SEIZURES WITH SECONDARY GENERALISATION
    ## 178                                                         PELVIC PAIN
    ## 179                                                 PHARYNGEAL ERYTHEMA
    ## 180                                              PHARYNGOLARYNGEAL PAIN
    ## 181                                                           PNEUMONIA
    ## 182                                                         POLLAKIURIA
    ## 183                                                      POSTNASAL DRIP
    ## 184                                                    PRODUCTIVE COUGH
    ## 185                                                     PROSTATE CANCER
    ## 186                                                            PRURITUS
    ## 187                                                PRURITUS GENERALISED
    ## 188                                           PSYCHOMOTOR HYPERACTIVITY
    ## 189                                                             PYREXIA
    ## 190                                                               RALES
    ## 191                                                                RASH
    ## 192                                                   RASH ERYTHEMATOUS
    ## 193                                                 RASH MACULO-PAPULAR
    ## 194                                                        RASH PAPULAR
    ## 195                                                       RASH PRURITIC
    ## 196                                                  RECTAL HAEMORRHAGE
    ## 197                                        RESPIRATORY TRACT CONGESTION
    ## 198                                                        RESTLESSNESS
    ## 199                                                            RHINITIS
    ## 200                                                         RHINORRHOEA
    ## 201                                             SALIVARY HYPERSECRETION
    ## 202                                                    SEASONAL ALLERGY
    ## 203                                                 SECRETION DISCHARGE
    ## 204                                                       SHOULDER PAIN
    ## 205                                                    SINUS ARRHYTHMIA
    ## 206                                                   SINUS BRADYCARDIA
    ## 207                                                    SKIN EXFOLIATION
    ## 208                                                     SKIN IRRITATION
    ## 209                                                     SKIN LACERATION
    ## 210                                                SKIN LESION EXCISION
    ## 211                                                 SKIN ODOUR ABNORMAL
    ## 212                                                          SKIN ULCER
    ## 213                                                          SOMNOLENCE
    ## 214                                                  STOMACH DISCOMFORT
    ## 215                                                              STUPOR
    ## 216                                                        SUDDEN DEATH
    ## 217                                      SUPRAVENTRICULAR EXTRASYSTOLES
    ## 218                                        SUPRAVENTRICULAR TACHYCARDIA
    ## 219                                                            SWELLING
    ## 220                                                             SYNCOPE
    ## 221                                                   SYNCOPE VASOVAGAL
    ## 222                                                         TACHYCARDIA
    ## 223                                                            TINNITUS
    ## 224                                          TRANSIENT ISCHAEMIC ATTACK
    ## 225                                                               ULCER
    ## 226                                   UPPER RESPIRATORY TRACT INFECTION
    ## 227                                             URINARY TRACT INFECTION
    ## 228                                             URINE ANALYSIS ABNORMAL
    ## 229                                                           URTICARIA
    ## 230                                                     VAGINAL MYCOSIS
    ## 231                                           VENTRICULAR EXTRASYSTOLES
    ## 232                                             VENTRICULAR HYPERTROPHY
    ## 233                                           VENTRICULAR SEPTAL DEFECT
    ## 234                                                             VERTIGO
    ## 235                                                     VIRAL INFECTION
    ## 236                                                      VISION BLURRED
    ## 237                                                            VOMITING
    ## 238                                                    WEIGHT DECREASED
    ## 239                                    WHITE BLOOD CELL COUNT INCREASED
    ## 240                                      WOLFF-PARKINSON-WHITE SYNDROME
    ## 241                                                               WOUND
    ## 242                                                   WOUND HAEMORRHAGE
    ## 243                                                               _ALL_
    ## 244                                                           _NONMISS_
    ## 245                                                   CARDIAC DISORDERS
    ## 246                          CONGENITAL, FAMILIAL AND GENETIC DISORDERS
    ## 247                                         EAR AND LABYRINTH DISORDERS
    ## 248                                                       EYE DISORDERS
    ## 249                                          GASTROINTESTINAL DISORDERS
    ## 250                GENERAL DISORDERS AND ADMINISTRATION SITE CONDITIONS
    ## 251                                             HEPATOBILIARY DISORDERS
    ## 252                                             IMMUNE SYSTEM DISORDERS
    ## 253                                         INFECTIONS AND INFESTATIONS
    ## 254                      INJURY, POISONING AND PROCEDURAL COMPLICATIONS
    ## 255                                                      INVESTIGATIONS
    ## 256                                  METABOLISM AND NUTRITION DISORDERS
    ## 257                     MUSCULOSKELETAL AND CONNECTIVE TISSUE DISORDERS
    ## 258 NEOPLASMS BENIGN, MALIGNANT AND UNSPECIFIED (INCL CYSTS AND POLYPS)
    ## 259                                            NERVOUS SYSTEM DISORDERS
    ## 260                                               PSYCHIATRIC DISORDERS
    ## 261                                         RENAL AND URINARY DISORDERS
    ## 262                            REPRODUCTIVE SYSTEM AND BREAST DISORDERS
    ## 263                     RESPIRATORY, THORACIC AND MEDIASTINAL DISORDERS
    ## 264                              SKIN AND SUBCUTANEOUS TISSUE DISORDERS
    ## 265                                                SOCIAL CIRCUMSTANCES
    ## 266                                     SURGICAL AND MEDICAL PROCEDURES
    ## 267                                                  VASCULAR DISORDERS
    ## 268                                                               _ALL_
    ## 269                                                           _NONMISS_
    ## 270                                                             USUBJID
    ## 271                                                               _ALL_
    ## 272                                                           _NONMISS_
    ## 273                                                            quantity
    ## 274                                                               count
    ## 275                                                       countdistinct
    ## 276                                                                   Y
    ## 277                                                               _ALL_
    ## 278                                                           _NONMISS_
    ## 279                                                             Placebo
    ## 280                                                Xanomeline High Dose
    ## 281                                                 Xanomeline Low Dose
    ## 282                                                               _ALL_
    ## 283                                                           _NONMISS_
    ##            vn  vct                     vnop
    ## 1     aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 2     aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 3     aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 4     aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 5     aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 6     aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 7     aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 8     aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 9     aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 10    aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 11    aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 12    aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 13    aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 14    aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 15    aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 16    aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 17    aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 18    aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 19    aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 20    aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 21    aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 22    aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 23    aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 24    aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 25    aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 26    aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 27    aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 28    aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 29    aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 30    aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 31    aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 32    aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 33    aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 34    aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 35    aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 36    aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 37    aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 38    aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 39    aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 40    aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 41    aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 42    aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 43    aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 44    aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 45    aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 46    aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 47    aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 48    aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 49    aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 50    aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 51    aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 52    aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 53    aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 54    aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 55    aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 56    aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 57    aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 58    aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 59    aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 60    aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 61    aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 62    aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 63    aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 64    aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 65    aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 66    aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 67    aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 68    aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 69    aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 70    aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 71    aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 72    aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 73    aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 74    aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 75    aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 76    aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 77    aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 78    aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 79    aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 80    aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 81    aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 82    aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 83    aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 84    aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 85    aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 86    aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 87    aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 88    aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 89    aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 90    aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 91    aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 92    aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 93    aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 94    aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 95    aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 96    aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 97    aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 98    aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 99    aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 100   aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 101   aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 102   aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 103   aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 104   aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 105   aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 106   aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 107   aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 108   aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 109   aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 110   aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 111   aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 112   aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 113   aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 114   aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 115   aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 116   aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 117   aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 118   aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 119   aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 120   aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 121   aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 122   aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 123   aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 124   aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 125   aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 126   aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 127   aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 128   aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 129   aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 130   aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 131   aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 132   aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 133   aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 134   aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 135   aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 136   aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 137   aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 138   aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 139   aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 140   aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 141   aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 142   aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 143   aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 144   aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 145   aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 146   aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 147   aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 148   aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 149   aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 150   aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 151   aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 152   aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 153   aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 154   aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 155   aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 156   aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 157   aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 158   aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 159   aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 160   aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 161   aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 162   aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 163   aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 164   aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 165   aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 166   aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 167   aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 168   aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 169   aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 170   aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 171   aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 172   aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 173   aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 174   aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 175   aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 176   aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 177   aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 178   aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 179   aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 180   aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 181   aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 182   aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 183   aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 184   aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 185   aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 186   aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 187   aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 188   aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 189   aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 190   aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 191   aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 192   aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 193   aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 194   aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 195   aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 196   aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 197   aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 198   aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 199   aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 200   aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 201   aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 202   aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 203   aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 204   aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 205   aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 206   aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 207   aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 208   aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 209   aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 210   aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 211   aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 212   aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 213   aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 214   aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 215   aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 216   aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 217   aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 218   aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 219   aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 220   aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 221   aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 222   aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 223   aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 224   aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 225   aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 226   aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 227   aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 228   aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 229   aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 230   aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 231   aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 232   aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 233   aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 234   aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 235   aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 236   aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 237   aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 238   aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 239   aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 240   aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 241   aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 242   aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 243   aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 244   aedecod DATA rrdfqbcrnd0:ADAE_AEDECOD
    ## 245     aesoc DATA   rrdfqbcrnd0:ADAE_AESOC
    ## 246     aesoc DATA   rrdfqbcrnd0:ADAE_AESOC
    ## 247     aesoc DATA   rrdfqbcrnd0:ADAE_AESOC
    ## 248     aesoc DATA   rrdfqbcrnd0:ADAE_AESOC
    ## 249     aesoc DATA   rrdfqbcrnd0:ADAE_AESOC
    ## 250     aesoc DATA   rrdfqbcrnd0:ADAE_AESOC
    ## 251     aesoc DATA   rrdfqbcrnd0:ADAE_AESOC
    ## 252     aesoc DATA   rrdfqbcrnd0:ADAE_AESOC
    ## 253     aesoc DATA   rrdfqbcrnd0:ADAE_AESOC
    ## 254     aesoc DATA   rrdfqbcrnd0:ADAE_AESOC
    ## 255     aesoc DATA   rrdfqbcrnd0:ADAE_AESOC
    ## 256     aesoc DATA   rrdfqbcrnd0:ADAE_AESOC
    ## 257     aesoc DATA   rrdfqbcrnd0:ADAE_AESOC
    ## 258     aesoc DATA   rrdfqbcrnd0:ADAE_AESOC
    ## 259     aesoc DATA   rrdfqbcrnd0:ADAE_AESOC
    ## 260     aesoc DATA   rrdfqbcrnd0:ADAE_AESOC
    ## 261     aesoc DATA   rrdfqbcrnd0:ADAE_AESOC
    ## 262     aesoc DATA   rrdfqbcrnd0:ADAE_AESOC
    ## 263     aesoc DATA   rrdfqbcrnd0:ADAE_AESOC
    ## 264     aesoc DATA   rrdfqbcrnd0:ADAE_AESOC
    ## 265     aesoc DATA   rrdfqbcrnd0:ADAE_AESOC
    ## 266     aesoc DATA   rrdfqbcrnd0:ADAE_AESOC
    ## 267     aesoc DATA   rrdfqbcrnd0:ADAE_AESOC
    ## 268     aesoc DATA   rrdfqbcrnd0:ADAE_AESOC
    ## 269     aesoc DATA   rrdfqbcrnd0:ADAE_AESOC
    ## 270    factor DATA                       ==
    ## 271    factor DATA                     <NA>
    ## 272    factor DATA                     <NA>
    ## 273    factor DATA                       ==
    ## 274 procedure DATA                       ==
    ## 275 procedure DATA                       ==
    ## 276     saffl DATA   rrdfqbcrnd0:ADAE_SAFFL
    ## 277     saffl DATA   rrdfqbcrnd0:ADAE_SAFFL
    ## 278     saffl DATA   rrdfqbcrnd0:ADAE_SAFFL
    ## 279      trta DATA    rrdfqbcrnd0:ADAE_TRTA
    ## 280      trta DATA    rrdfqbcrnd0:ADAE_TRTA
    ## 281      trta DATA    rrdfqbcrnd0:ADAE_TRTA
    ## 282      trta DATA    rrdfqbcrnd0:ADAE_TRTA
    ## 283      trta DATA    rrdfqbcrnd0:ADAE_TRTA
    ##                                                                   vnval
    ## 1                                                  ABDOMINAL DISCOMFORT
    ## 2                                                        ABDOMINAL PAIN
    ## 3                                                  ACROCHORDON EXCISION
    ## 4                                                     ACTINIC KERATOSIS
    ## 5                                                             AGITATION
    ## 6                                                           ALCOHOL USE
    ## 7                                       ALLERGIC GRANULOMATOUS ANGIITIS
    ## 8                                                              ALOPECIA
    ## 9                                                               AMNESIA
    ## 10                                                              ANXIETY
    ## 11                                            APPLICATION SITE BLEEDING
    ## 12                                          APPLICATION SITE DERMATITIS
    ## 13                                        APPLICATION SITE DESQUAMATION
    ## 14                                           APPLICATION SITE DISCHARGE
    ## 15                                      APPLICATION SITE DISCOLOURATION
    ## 16                                            APPLICATION SITE ERYTHEMA
    ## 17                                          APPLICATION SITE INDURATION
    ## 18                                          APPLICATION SITE IRRITATION
    ## 19                                                APPLICATION SITE PAIN
    ## 20                                        APPLICATION SITE PERSPIRATION
    ## 21                                            APPLICATION SITE PRURITUS
    ## 22                                            APPLICATION SITE REACTION
    ## 23                                            APPLICATION SITE SWELLING
    ## 24                                           APPLICATION SITE URTICARIA
    ## 25                                            APPLICATION SITE VESICLES
    ## 26                                              APPLICATION SITE WARMTH
    ## 27                                                           ARTHRALGIA
    ## 28                                                            ARTHRITIS
    ## 29                                                             ASTHENIA
    ## 30                                                  ATRIAL FIBRILLATION
    ## 31                                                       ATRIAL FLUTTER
    ## 32                                                   ATRIAL HYPERTROPHY
    ## 33                                  ATRIOVENTRICULAR BLOCK FIRST DEGREE
    ## 34                                 ATRIOVENTRICULAR BLOCK SECOND DEGREE
    ## 35                                                            BACK PAIN
    ## 36                                                     BALANCE DISORDER
    ## 37                                         BENIGN PROSTATIC HYPERPLASIA
    ## 38                                                               BIOPSY
    ## 39                                                      BIOPSY PROSTATE
    ## 40                                                              BLISTER
    ## 41                                 BLOOD ALKALINE PHOSPHATASE INCREASED
    ## 42                                          BLOOD CHOLESTEROL INCREASED
    ## 43                               BLOOD CREATINE PHOSPHOKINASE INCREASED
    ## 44                                              BLOOD GLUCOSE INCREASED
    ## 45                                                  BLOOD URINE PRESENT
    ## 46                                           BODY TEMPERATURE INCREASED
    ## 47                                                          BRADYCARDIA
    ## 48                                                           BRONCHITIS
    ## 49                                             BUNDLE BRANCH BLOCK LEFT
    ## 50                                            BUNDLE BRANCH BLOCK RIGHT
    ## 51                                                    BURNING SENSATION
    ## 52                                                    CALCULUS URETHRAL
    ## 53                                                     CARDIAC DISORDER
    ## 54                                           CARDIAC FAILURE CONGESTIVE
    ## 55                                                   CATARACT OPERATION
    ## 56                                                           CELLULITIS
    ## 57                                                    CERUMEN IMPACTION
    ## 58                                                           CERVICITIS
    ## 59                                                     CHEST DISCOMFORT
    ## 60                                                           CHEST PAIN
    ## 61                                                               CHILLS
    ## 62                                                   COGNITIVE DISORDER
    ## 63                                                           COLD SWEAT
    ## 64                                                         COLON CANCER
    ## 65                                                    COMPLETED SUICIDE
    ## 66                                             COMPLEX PARTIAL SEIZURES
    ## 67                                                    CONFUSIONAL STATE
    ## 68                                             CONJUNCTIVAL HAEMORRHAGE
    ## 69                                                       CONJUNCTIVITIS
    ## 70                                                         CONSTIPATION
    ## 71                                                            CONTUSION
    ## 72                                                COORDINATION ABNORMAL
    ## 73                                                                COUGH
    ## 74                                                                 CYST
    ## 75                                                             CYSTITIS
    ## 76                                                           CYSTOSCOPY
    ## 77                                                   DECREASED APPETITE
    ## 78                                                          DEHYDRATION
    ## 79                                                             DELIRIUM
    ## 80                                                             DELUSION
    ## 81                                                       DEPRESSED MOOD
    ## 82                                                    DERMATITIS ATOPIC
    ## 83                                                   DERMATITIS CONTACT
    ## 84                                                    DIABETES MELLITUS
    ## 85                                                            DIARRHOEA
    ## 86                                                       DISORIENTATION
    ## 87                                                            DIZZINESS
    ## 88                                                        DRUG ERUPTION
    ## 89                                                            DYSPEPSIA
    ## 90                                                            DYSPHAGIA
    ## 91                                                            DYSPHONIA
    ## 92                                                             DYSPNOEA
    ## 93                                                              DYSURIA
    ## 94                                                        EAR INFECTION
    ## 95                                                             EAR PAIN
    ## 96                              ELECTROCARDIOGRAM ST SEGMENT DEPRESSION
    ## 97                         ELECTROCARDIOGRAM T WAVE AMPLITUDE DECREASED
    ## 98                                   ELECTROCARDIOGRAM T WAVE INVERSION
    ## 99                                                            EMPHYSEMA
    ## 100                                                            ENURESIS
    ## 101                                                           EPISTAXIS
    ## 102                                                            ERYTHEMA
    ## 103                                                         EXCORIATION
    ## 104                                                         EYE ALLERGY
    ## 105                                                   EYE LASER SURGERY
    ## 106                                                        EYE PRURITUS
    ## 107                                                        EYE SWELLING
    ## 108                                               FACIAL BONES FRACTURE
    ## 109                                                                FALL
    ## 110                                                             FATIGUE
    ## 111                                                    FEELING ABNORMAL
    ## 112                                                        FEELING COLD
    ## 113                                                          FLANK PAIN
    ## 114                                                          FLATULENCE
    ## 115                                                        FOOD CRAVING
    ## 116                                               GASTROENTERITIS VIRAL
    ## 117                                        GASTROINTESTINAL HAEMORRHAGE
    ## 118                                    GASTROOESOPHAGEAL REFLUX DISEASE
    ## 119                                                            GLAUCOMA
    ## 120                                                           GLOSSITIS
    ## 121                                                         HAEMOPTYSIS
    ## 122                                                       HALLUCINATION
    ## 123                                               HALLUCINATION, VISUAL
    ## 124                                                            HEADACHE
    ## 125                                                HEART RATE INCREASED
    ## 126                                                HEART RATE IRREGULAR
    ## 127                                               HEMIANOPIA HOMONYMOUS
    ## 128                                                       HIATUS HERNIA
    ## 129                                                        HIP FRACTURE
    ## 130                                                           HORDEOLUM
    ## 131                                                           HOT FLUSH
    ## 132                                                 HYPERBILIRUBINAEMIA
    ## 133                                               HYPERCHOLESTEROLAEMIA
    ## 134                                                       HYPERHIDROSIS
    ## 135                                                    HYPERSENSITIVITY
    ## 136                                                         HYPERSOMNIA
    ## 137                                                        HYPERTENSION
    ## 138                                                       HYPONATRAEMIA
    ## 139                                                         HYPOTENSION
    ## 140                                                        INCONTINENCE
    ## 141                                                  INCREASED APPETITE
    ## 142                                                        INFLAMMATION
    ## 143                                                           INFLUENZA
    ## 144                                                            INSOMNIA
    ## 145                                                        IRRITABILITY
    ## 146                                                   JOINT DISLOCATION
    ## 147                                                            LETHARGY
    ## 148                                                    LIBIDO DECREASED
    ## 149                                                            LISTLESS
    ## 150                                                 LOCALISED INFECTION
    ## 151                                   LOWER RESPIRATORY TRACT INFECTION
    ## 152                                                             MALAISE
    ## 153                                      MALIGNANT FIBROUS HISTIOCYTOMA
    ## 154                                                 MICTURITION URGENCY
    ## 155                                                       MUSCLE SPASMS
    ## 156                                                   MUSCULAR WEAKNESS
    ## 157                                                             MYALGIA
    ## 158                                               MYOCARDIAL INFARCTION
    ## 159                                                    NASAL CONGESTION
    ## 160                                                 NASAL MUCOSA BIOPSY
    ## 161                                                     NASOPHARYNGITIS
    ## 162                                                              NAUSEA
    ## 163                                                     NEPHROLITHIASIS
    ## 164                                          NEUTROPHIL COUNT INCREASED
    ## 165                                                           NIGHTMARE
    ## 166                                                              OEDEMA
    ## 167                                                   OEDEMA PERIPHERAL
    ## 168                                                       ONYCHOMYCOSIS
    ## 169                                             ORTHOSTATIC HYPOTENSION
    ## 170                                                                PAIN
    ## 171                                                   PAIN IN EXTREMITY
    ## 172                                                        PALPITATIONS
    ## 173                                                        PARAESTHESIA
    ## 174                                                   PARAESTHESIA ORAL
    ## 175                                                 PARKINSON'S DISEASE
    ## 176                                                            PAROSMIA
    ## 177                      PARTIAL SEIZURES WITH SECONDARY GENERALISATION
    ## 178                                                         PELVIC PAIN
    ## 179                                                 PHARYNGEAL ERYTHEMA
    ## 180                                              PHARYNGOLARYNGEAL PAIN
    ## 181                                                           PNEUMONIA
    ## 182                                                         POLLAKIURIA
    ## 183                                                      POSTNASAL DRIP
    ## 184                                                    PRODUCTIVE COUGH
    ## 185                                                     PROSTATE CANCER
    ## 186                                                            PRURITUS
    ## 187                                                PRURITUS GENERALISED
    ## 188                                           PSYCHOMOTOR HYPERACTIVITY
    ## 189                                                             PYREXIA
    ## 190                                                               RALES
    ## 191                                                                RASH
    ## 192                                                   RASH ERYTHEMATOUS
    ## 193                                                 RASH MACULO-PAPULAR
    ## 194                                                        RASH PAPULAR
    ## 195                                                       RASH PRURITIC
    ## 196                                                  RECTAL HAEMORRHAGE
    ## 197                                        RESPIRATORY TRACT CONGESTION
    ## 198                                                        RESTLESSNESS
    ## 199                                                            RHINITIS
    ## 200                                                         RHINORRHOEA
    ## 201                                             SALIVARY HYPERSECRETION
    ## 202                                                    SEASONAL ALLERGY
    ## 203                                                 SECRETION DISCHARGE
    ## 204                                                       SHOULDER PAIN
    ## 205                                                    SINUS ARRHYTHMIA
    ## 206                                                   SINUS BRADYCARDIA
    ## 207                                                    SKIN EXFOLIATION
    ## 208                                                     SKIN IRRITATION
    ## 209                                                     SKIN LACERATION
    ## 210                                                SKIN LESION EXCISION
    ## 211                                                 SKIN ODOUR ABNORMAL
    ## 212                                                          SKIN ULCER
    ## 213                                                          SOMNOLENCE
    ## 214                                                  STOMACH DISCOMFORT
    ## 215                                                              STUPOR
    ## 216                                                        SUDDEN DEATH
    ## 217                                      SUPRAVENTRICULAR EXTRASYSTOLES
    ## 218                                        SUPRAVENTRICULAR TACHYCARDIA
    ## 219                                                            SWELLING
    ## 220                                                             SYNCOPE
    ## 221                                                   SYNCOPE VASOVAGAL
    ## 222                                                         TACHYCARDIA
    ## 223                                                            TINNITUS
    ## 224                                          TRANSIENT ISCHAEMIC ATTACK
    ## 225                                                               ULCER
    ## 226                                   UPPER RESPIRATORY TRACT INFECTION
    ## 227                                             URINARY TRACT INFECTION
    ## 228                                             URINE ANALYSIS ABNORMAL
    ## 229                                                           URTICARIA
    ## 230                                                     VAGINAL MYCOSIS
    ## 231                                           VENTRICULAR EXTRASYSTOLES
    ## 232                                             VENTRICULAR HYPERTROPHY
    ## 233                                           VENTRICULAR SEPTAL DEFECT
    ## 234                                                             VERTIGO
    ## 235                                                     VIRAL INFECTION
    ## 236                                                      VISION BLURRED
    ## 237                                                            VOMITING
    ## 238                                                    WEIGHT DECREASED
    ## 239                                    WHITE BLOOD CELL COUNT INCREASED
    ## 240                                      WOLFF-PARKINSON-WHITE SYNDROME
    ## 241                                                               WOUND
    ## 242                                                   WOUND HAEMORRHAGE
    ## 243                                                                <NA>
    ## 244                                                                <NA>
    ## 245                                                   CARDIAC DISORDERS
    ## 246                          CONGENITAL, FAMILIAL AND GENETIC DISORDERS
    ## 247                                         EAR AND LABYRINTH DISORDERS
    ## 248                                                       EYE DISORDERS
    ## 249                                          GASTROINTESTINAL DISORDERS
    ## 250                GENERAL DISORDERS AND ADMINISTRATION SITE CONDITIONS
    ## 251                                             HEPATOBILIARY DISORDERS
    ## 252                                             IMMUNE SYSTEM DISORDERS
    ## 253                                         INFECTIONS AND INFESTATIONS
    ## 254                      INJURY, POISONING AND PROCEDURAL COMPLICATIONS
    ## 255                                                      INVESTIGATIONS
    ## 256                                  METABOLISM AND NUTRITION DISORDERS
    ## 257                     MUSCULOSKELETAL AND CONNECTIVE TISSUE DISORDERS
    ## 258 NEOPLASMS BENIGN, MALIGNANT AND UNSPECIFIED (INCL CYSTS AND POLYPS)
    ## 259                                            NERVOUS SYSTEM DISORDERS
    ## 260                                               PSYCHIATRIC DISORDERS
    ## 261                                         RENAL AND URINARY DISORDERS
    ## 262                            REPRODUCTIVE SYSTEM AND BREAST DISORDERS
    ## 263                     RESPIRATORY, THORACIC AND MEDIASTINAL DISORDERS
    ## 264                              SKIN AND SUBCUTANEOUS TISSUE DISORDERS
    ## 265                                                SOCIAL CIRCUMSTANCES
    ## 266                                     SURGICAL AND MEDICAL PROCEDURES
    ## 267                                                  VASCULAR DISORDERS
    ## 268                                                                <NA>
    ## 269                                                                <NA>
    ## 270                                                             USUBJID
    ## 271                                                                <NA>
    ## 272                                                                <NA>
    ## 273                                                            quantity
    ## 274                                                               count
    ## 275                                                       countdistinct
    ## 276                                                                   Y
    ## 277                                                                <NA>
    ## 278                                                                <NA>
    ## 279                                                             Placebo
    ## 280                                                Xanomeline High Dose
    ## 281                                                 Xanomeline Low Dose
    ## 282                                                                <NA>
    ## 283                                                                <NA>
    ## crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aedecod crnd-dimension:aesoc crnd-dimension:aesoc crnd-dimension:aesoc crnd-dimension:aesoc crnd-dimension:aesoc crnd-dimension:aesoc crnd-dimension:aesoc crnd-dimension:aesoc crnd-dimension:aesoc crnd-dimension:aesoc crnd-dimension:aesoc crnd-dimension:aesoc crnd-dimension:aesoc crnd-dimension:aesoc crnd-dimension:aesoc crnd-dimension:aesoc crnd-dimension:aesoc crnd-dimension:aesoc crnd-dimension:aesoc crnd-dimension:aesoc crnd-dimension:aesoc crnd-dimension:aesoc crnd-dimension:aesoc crnd-dimension:aesoc crnd-dimension:aesoc crnd-dimension:factor crnd-dimension:factor crnd-dimension:factor crnd-dimension:factor crnd-dimension:procedure crnd-dimension:procedure crnd-dimension:saffl crnd-dimension:saffl crnd-dimension:saffl crnd-dimension:trta crnd-dimension:trta crnd-dimension:trta crnd-dimension:trta crnd-dimension:trta

``` r
cat("AE cube stored as ", ae.cube.fn, "\n")
```

    ## AE cube stored as  /tmp/RtmpTRtZfa/DC-AE-R-V-0-5-2.ttl

``` r
targetFile<- file.path(targetDir,"DC-AE-sample.ttl")
if (file.copy( ae.cube.fn, targetFile, overwrite=TRUE)) {
  cat("AE cube copied to ", normalizePath(targetFile), "\n")
}
```

    ## AE cube copied to  /home/ma/projects/rrdfqbcrnd0/rrdfqbcrndex/inst/extdata/sample-rdf/DC-AE-sample.ttl

RDF data cube in csv files
--------------------------

``` r
demoObsDataCsvFn<- system.file("extdata/sample-cfg", "demo.AR.csv", package="rrdfqbcrndex")
demoObsData <- read.csv(demoObsDataCsvFn,stringsAsFactors=FALSE)

##TODO add measurefmt; quick hack - affects vignettes/cube-from-workbook.Rmd and
##TODO inst/data-raw/create-qb-examples-as-ttl.Rmd
if (!( "measurefmt" %in% names(demoObsData))) {
demoObsData$measurefmt<- "%6.1f"
demoObsData$measurefmt[ demoObsData$procedure %in% c("n", "nmiss", "count") ]<- "%6.0f"
## sprintf( demoObsData$measurefmt, demoObsData$measure)
}

demoMetaDataCsvFn<- system.file("extdata/sample-cfg", "DEMO-Components.csv", package="rrdfqbcrndex")
demoMetaData <- read.csv(demoMetaDataCsvFn,stringsAsFactors=FALSE)

demo.cube.fn<- BuildCubeFromDataFrames(demoMetaData, demoObsData )
```

    ## [1] "prefix rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>\nprefix skos: <http://www.w3.org/2004/02/skos/core#>\nprefix prov: <http://www.w3.org/ns/prov#>\nprefix rdfs: <http://www.w3.org/2000/01/rdf-schema#>\nprefix dcat: <http://www.w3.org/ns/dcat#>\nprefix owl: <http://www.w3.org/2002/07/owl#>\nprefix xsd: <http://www.w3.org/2001/XMLSchema#>\nprefix pav: <http://purl.org/pav>\nprefix dc: <http://purl.org/dc/elements/1.1/>\nprefix dct: <http://purl.org/dc/terms/>\nprefix mms: <http://rdf.cdisc.org/mms#>\nprefix cts: <http://rdf.cdisc.org/ct/schema#>\nprefix cdiscs: <http://rdf.cdisc.org/std/schema#>\nprefix cdash-1-1: <http://rdf.cdisc.org/std/cdash-1-1#>\nprefix cdashct: <http://rdf.cdisc.org/cdash-terminology#>\nprefix sdtmct: <http://rdf.cdisc.org/sdtm-terminology#>\nprefix sdtm-1-2: <http://rdf.cdisc.org/std/sdtm-1-2#>\nprefix sdtm-1-3: <http://rdf.cdisc.org/std/sdtm-1-3#>\nprefix sdtms-1-3: <http://rdf.cdisc.org/sdtm-1-3/schema#>\nprefix sdtmig-3-1-2: <http://rdf.cdisc.org/std/sdtmig-3-1-2#>\nprefix sdtmig-3-1-3: <http://rdf.cdisc.org/std/sdtmig-3-1-3#>\nprefix sendct: <http://rdf.cdisc.org/send-terminology#>\nprefix sendig-3-0: <http://rdf.cdisc.org/std/sendig-3-0#>\nprefix adamct: <http://rdf.cdisc.org/adam-terminology#>\nprefix adam-2-1: <http://rdf.cdisc.org/std/adam-2-1#>\nprefix adamig-1-0: <http://rdf.cdisc.org/std/adamig-1-0#>\nprefix adamvr-1-2: <http://rdf.cdisc.org/std/adamvr-1-2#>\nprefix qb: <http://purl.org/linked-data/cube#>\nprefix rrdfqbcrnd0: <http://www.example.org/rrdfqbcrnd0/>\nprefix code: <http://www.example.org/dc/code/>\nprefix dccs: <http://www.example.org/dc/demo/dccs/>\nprefix ds: <http://www.example.org/dc/demo/ds/>\nprefix crnd-dimension: <http://www.example.org/dc/dimension#>\nprefix crnd-attribute: <http://www.example.org/dc/attribute#>\nprefix crnd-measure: <http://www.example.org/dc/measure#>\n \nselect distinct ?DataStructureDefinition ?dimension ?cprefLabel ?cl ?clprefLabel ?vn ?vct ?vnop ?vnval\nwhere {\n   ?DataStructureDefinition a qb:DataStructureDefinition ;\n        qb:component ?component .\n   ?component a qb:ComponentSpecification .\n   ?component qb:dimension ?dimension .\n\n   ?dimension qb:codeList ?c .\n   OPTIONAL { ?c skos:prefLabel ?cprefLabel .   }\n   OPTIONAL { ?c rrdfqbcrnd0:DataSetRefD2RQ ?vnop . }\n   OPTIONAL { ?c rrdfqbcrnd0:R-columnname ?vn . }\n   OPTIONAL { ?c rrdfqbcrnd0:codeType     ?vct .          }\n\n   ?c skos:hasTopConcept ?cl .\n   OPTIONAL { ?cl skos:prefLabel ?clprefLabel . }\n   OPTIONAL { ?cl rrdfqbcrnd0:R-selectionoperator ?vnop . }\n   OPTIONAL { ?cl rrdfqbcrnd0:R-selectionvalue ?vnval .   }\n values ( ?DataStructureDefinition ) {\n(ds:dsd-DEMO)\n} \n}\norder by ?dimension ?cl ?dimensionrefLabel\n"
    ##    DataStructureDefinition                dimension
    ## 1              ds:dsd-DEMO    crnd-dimension:agegr1
    ## 2              ds:dsd-DEMO    crnd-dimension:agegr1
    ## 3              ds:dsd-DEMO    crnd-dimension:agegr1
    ## 4              ds:dsd-DEMO    crnd-dimension:agegr1
    ## 5              ds:dsd-DEMO    crnd-dimension:agegr1
    ## 6              ds:dsd-DEMO    crnd-dimension:ethnic
    ## 7              ds:dsd-DEMO    crnd-dimension:ethnic
    ## 8              ds:dsd-DEMO    crnd-dimension:ethnic
    ## 9              ds:dsd-DEMO    crnd-dimension:ethnic
    ## 10             ds:dsd-DEMO    crnd-dimension:factor
    ## 11             ds:dsd-DEMO    crnd-dimension:factor
    ## 12             ds:dsd-DEMO    crnd-dimension:factor
    ## 13             ds:dsd-DEMO    crnd-dimension:factor
    ## 14             ds:dsd-DEMO    crnd-dimension:factor
    ## 15             ds:dsd-DEMO    crnd-dimension:factor
    ## 16             ds:dsd-DEMO crnd-dimension:procedure
    ## 17             ds:dsd-DEMO crnd-dimension:procedure
    ## 18             ds:dsd-DEMO crnd-dimension:procedure
    ## 19             ds:dsd-DEMO crnd-dimension:procedure
    ## 20             ds:dsd-DEMO crnd-dimension:procedure
    ## 21             ds:dsd-DEMO crnd-dimension:procedure
    ## 22             ds:dsd-DEMO crnd-dimension:procedure
    ## 23             ds:dsd-DEMO crnd-dimension:procedure
    ## 24             ds:dsd-DEMO crnd-dimension:procedure
    ## 25             ds:dsd-DEMO crnd-dimension:procedure
    ## 26             ds:dsd-DEMO      crnd-dimension:race
    ## 27             ds:dsd-DEMO      crnd-dimension:race
    ## 28             ds:dsd-DEMO      crnd-dimension:race
    ## 29             ds:dsd-DEMO      crnd-dimension:race
    ## 30             ds:dsd-DEMO      crnd-dimension:race
    ## 31             ds:dsd-DEMO      crnd-dimension:race
    ## 32             ds:dsd-DEMO      crnd-dimension:race
    ## 33             ds:dsd-DEMO       crnd-dimension:sex
    ## 34             ds:dsd-DEMO       crnd-dimension:sex
    ## 35             ds:dsd-DEMO       crnd-dimension:sex
    ## 36             ds:dsd-DEMO       crnd-dimension:sex
    ## 37             ds:dsd-DEMO       crnd-dimension:sex
    ## 38             ds:dsd-DEMO       crnd-dimension:sex
    ## 39             ds:dsd-DEMO    crnd-dimension:trt01a
    ## 40             ds:dsd-DEMO    crnd-dimension:trt01a
    ## 41             ds:dsd-DEMO    crnd-dimension:trt01a
    ## 42             ds:dsd-DEMO    crnd-dimension:trt01a
    ## 43             ds:dsd-DEMO    crnd-dimension:trt01a
    ##                    cprefLabel
    ## 1     Codelist scheme: agegr1
    ## 2     Codelist scheme: agegr1
    ## 3     Codelist scheme: agegr1
    ## 4     Codelist scheme: agegr1
    ## 5     Codelist scheme: agegr1
    ## 6     Codelist scheme: ethnic
    ## 7     Codelist scheme: ethnic
    ## 8     Codelist scheme: ethnic
    ## 9     Codelist scheme: ethnic
    ## 10    Codelist scheme: factor
    ## 11    Codelist scheme: factor
    ## 12    Codelist scheme: factor
    ## 13    Codelist scheme: factor
    ## 14    Codelist scheme: factor
    ## 15    Codelist scheme: factor
    ## 16 Codelist scheme: procedure
    ## 17 Codelist scheme: procedure
    ## 18 Codelist scheme: procedure
    ## 19 Codelist scheme: procedure
    ## 20 Codelist scheme: procedure
    ## 21 Codelist scheme: procedure
    ## 22 Codelist scheme: procedure
    ## 23 Codelist scheme: procedure
    ## 24 Codelist scheme: procedure
    ## 25 Codelist scheme: procedure
    ## 26      Codelist scheme: race
    ## 27      Codelist scheme: race
    ## 28      Codelist scheme: race
    ## 29      Codelist scheme: race
    ## 30      Codelist scheme: race
    ## 31      Codelist scheme: race
    ## 32      Codelist scheme: race
    ## 33       Codelist scheme: sex
    ## 34       Codelist scheme: sex
    ## 35       Codelist scheme: sex
    ## 36       Codelist scheme: sex
    ## 37       Codelist scheme: sex
    ## 38       Codelist scheme: sex
    ## 39    Codelist scheme: trt01a
    ## 40    Codelist scheme: trt01a
    ## 41    Codelist scheme: trt01a
    ## 42    Codelist scheme: trt01a
    ## 43    Codelist scheme: trt01a
    ##                                                     cl
    ## 1                                    code:agegr1-65-80
    ## 2                                      code:agegr1-_65
    ## 3                                      code:agegr1-_80
    ## 4                                    code:agegr1-_ALL_
    ## 5                                code:agegr1-_NONMISS_
    ## 6                       code:ethnic-HISPANIC_OR_LATINO
    ## 7                   code:ethnic-NOT_HISPANIC_OR_LATINO
    ## 8                                    code:ethnic-_ALL_
    ## 9                                code:ethnic-_NONMISS_
    ## 10                                   code:factor-_ALL_
    ## 11                               code:factor-_NONMISS_
    ## 12                                     code:factor-age
    ## 13                              code:factor-proportion
    ## 14                                code:factor-quantity
    ## 15                                code:factor-weightbl
    ## 16                                code:procedure-count
    ## 17                                  code:procedure-max
    ## 18                                 code:procedure-mean
    ## 19                               code:procedure-median
    ## 20                                  code:procedure-min
    ## 21                                    code:procedure-n
    ## 22                              code:procedure-percent
    ## 23                                   code:procedure-q1
    ## 24                                   code:procedure-q3
    ## 25                                  code:procedure-std
    ## 26          code:race-AMERICAN_INDIAN_OR_ALASKA_NATIVE
    ## 27                                     code:race-ASIAN
    ## 28                 code:race-BLACK_OR_AFRICAN_AMERICAN
    ## 29 code:race-NATIVE_HAWAIIAN_OR_OTHER_PACIFIC_ISLANDER
    ## 30                                     code:race-WHITE
    ## 31                                     code:race-_ALL_
    ## 32                                 code:race-_NONMISS_
    ## 33                                          code:sex-F
    ## 34                                          code:sex-M
    ## 35                                          code:sex-U
    ## 36                                         code:sex-UN
    ## 37                                      code:sex-_ALL_
    ## 38                                  code:sex-_NONMISS_
    ## 39                                 code:trt01a-Placebo
    ## 40                    code:trt01a-Xanomeline_High_Dose
    ## 41                     code:trt01a-Xanomeline_Low_Dose
    ## 42                                   code:trt01a-_ALL_
    ## 43                               code:trt01a-_NONMISS_
    ##                                  clprefLabel        vn  vct
    ## 1                                      65-80    agegr1 DATA
    ## 2                                        <65    agegr1 DATA
    ## 3                                        >80    agegr1 DATA
    ## 4                                      _ALL_    agegr1 DATA
    ## 5                                  _NONMISS_    agegr1 DATA
    ## 6                         HISPANIC OR LATINO    ethnic DATA
    ## 7                     NOT HISPANIC OR LATINO    ethnic DATA
    ## 8                                      _ALL_    ethnic DATA
    ## 9                                  _NONMISS_    ethnic DATA
    ## 10                                     _ALL_    factor DATA
    ## 11                                 _NONMISS_    factor DATA
    ## 12                                       age    factor DATA
    ## 13                                proportion    factor DATA
    ## 14                                  quantity    factor DATA
    ## 15                                  weightbl    factor DATA
    ## 16                                     count procedure DATA
    ## 17                                       max procedure DATA
    ## 18                                      mean procedure DATA
    ## 19                                    median procedure DATA
    ## 20                                       min procedure DATA
    ## 21                                         n procedure DATA
    ## 22                                   percent procedure DATA
    ## 23                                        q1 procedure DATA
    ## 24                                        q3 procedure DATA
    ## 25                                       std procedure DATA
    ## 26          AMERICAN INDIAN OR ALASKA NATIVE      race SDTM
    ## 27                                     ASIAN      race SDTM
    ## 28                 BLACK OR AFRICAN AMERICAN      race SDTM
    ## 29 NATIVE HAWAIIAN OR OTHER PACIFIC ISLANDER      race SDTM
    ## 30                                     WHITE      race SDTM
    ## 31                                     _ALL_      race SDTM
    ## 32                                 _NONMISS_      race SDTM
    ## 33                                         F       sex SDTM
    ## 34                                         M       sex SDTM
    ## 35                                         U       sex SDTM
    ## 36                                        UN       sex SDTM
    ## 37                                     _ALL_       sex SDTM
    ## 38                                 _NONMISS_       sex SDTM
    ## 39                                   Placebo    trt01a DATA
    ## 40                      Xanomeline High Dose    trt01a DATA
    ## 41                       Xanomeline Low Dose    trt01a DATA
    ## 42                                     _ALL_    trt01a DATA
    ## 43                                 _NONMISS_    trt01a DATA
    ##                       vnop                                     vnval
    ## 1  rrdfqbcrnd0:ADSL_AGEGR1                                     65-80
    ## 2  rrdfqbcrnd0:ADSL_AGEGR1                                       <65
    ## 3  rrdfqbcrnd0:ADSL_AGEGR1                                       >80
    ## 4  rrdfqbcrnd0:ADSL_AGEGR1                                      <NA>
    ## 5  rrdfqbcrnd0:ADSL_AGEGR1                                      <NA>
    ## 6  rrdfqbcrnd0:ADSL_ETHNIC                        HISPANIC OR LATINO
    ## 7  rrdfqbcrnd0:ADSL_ETHNIC                    NOT HISPANIC OR LATINO
    ## 8  rrdfqbcrnd0:ADSL_ETHNIC                                      <NA>
    ## 9  rrdfqbcrnd0:ADSL_ETHNIC                                      <NA>
    ## 10                    <NA>                                      <NA>
    ## 11                    <NA>                                      <NA>
    ## 12                      ==                                       age
    ## 13                      ==                                proportion
    ## 14                      ==                                  quantity
    ## 15                      ==                                  weightbl
    ## 16                      ==                                     count
    ## 17                      ==                                       max
    ## 18                      ==                                      mean
    ## 19                      ==                                    median
    ## 20                      ==                                       min
    ## 21                      ==                                         n
    ## 22                      ==                                   percent
    ## 23                      ==                                        q1
    ## 24                      ==                                        q3
    ## 25                      ==                                       std
    ## 26   rrdfqbcrnd0:ADSL_RACE          AMERICAN INDIAN OR ALASKA NATIVE
    ## 27   rrdfqbcrnd0:ADSL_RACE                                     ASIAN
    ## 28   rrdfqbcrnd0:ADSL_RACE                 BLACK OR AFRICAN AMERICAN
    ## 29   rrdfqbcrnd0:ADSL_RACE NATIVE HAWAIIAN OR OTHER PACIFIC ISLANDER
    ## 30   rrdfqbcrnd0:ADSL_RACE                                     WHITE
    ## 31   rrdfqbcrnd0:ADSL_RACE                                      <NA>
    ## 32   rrdfqbcrnd0:ADSL_RACE                                      <NA>
    ## 33    rrdfqbcrnd0:ADSL_SEX                                         F
    ## 34    rrdfqbcrnd0:ADSL_SEX                                         M
    ## 35    rrdfqbcrnd0:ADSL_SEX                                         U
    ## 36    rrdfqbcrnd0:ADSL_SEX                                        UN
    ## 37    rrdfqbcrnd0:ADSL_SEX                                      <NA>
    ## 38    rrdfqbcrnd0:ADSL_SEX                                      <NA>
    ## 39 rrdfqbcrnd0:ADSL_TRT01A                                   Placebo
    ## 40 rrdfqbcrnd0:ADSL_TRT01A                      Xanomeline High Dose
    ## 41 rrdfqbcrnd0:ADSL_TRT01A                       Xanomeline Low Dose
    ## 42 rrdfqbcrnd0:ADSL_TRT01A                                      <NA>
    ## 43 rrdfqbcrnd0:ADSL_TRT01A                                      <NA>
    ## crnd-dimension:agegr1 crnd-dimension:agegr1 crnd-dimension:agegr1 crnd-dimension:agegr1 crnd-dimension:agegr1 crnd-dimension:ethnic crnd-dimension:ethnic crnd-dimension:ethnic crnd-dimension:ethnic crnd-dimension:factor crnd-dimension:factor crnd-dimension:factor crnd-dimension:factor crnd-dimension:factor crnd-dimension:factor crnd-dimension:procedure crnd-dimension:procedure crnd-dimension:procedure crnd-dimension:procedure crnd-dimension:procedure crnd-dimension:procedure crnd-dimension:procedure crnd-dimension:procedure crnd-dimension:procedure crnd-dimension:procedure crnd-dimension:race crnd-dimension:race crnd-dimension:race crnd-dimension:race crnd-dimension:race crnd-dimension:race crnd-dimension:race crnd-dimension:sex crnd-dimension:sex crnd-dimension:sex crnd-dimension:sex crnd-dimension:sex crnd-dimension:sex crnd-dimension:trt01a crnd-dimension:trt01a crnd-dimension:trt01a crnd-dimension:trt01a crnd-dimension:trt01a

``` r
cat("DEMO cube stored as ", normalizePath(demo.cube.fn), "\n")
```

    ## DEMO cube stored as  /tmp/RtmpTRtZfa/DC-DEMO-R-V-0-5-2.ttl

``` r
targetFile<- file.path(targetDir,"DC-DEMO-sample.ttl")

if (file.copy( demo.cube.fn, targetFile, overwrite=TRUE)) {
   cat("DEMO cube copied to ", normalizePath(targetFile), "\n")
 }
```

    ## DEMO cube copied to  /home/ma/projects/rrdfqbcrnd0/rrdfqbcrndex/inst/extdata/sample-rdf/DC-DEMO-sample.ttl
