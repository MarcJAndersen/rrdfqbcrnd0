---
title: "SPARQL query using Shiny to build interface"
author: "PhuseSubTeamAnalysisResults@example.org"
date: "2016-03-01"
output: rmarkdown::html_vignette
vignette: >
  %\VignetteIndexEntry{SPARQL query using Shiny to build interface}
  %\VignetteEngine{knitr::rmarkdown}
  %\usepackage[utf8]{inputenc}
---


## Prelimnaries
write more here
Here should be more text.
## Code



```
## Loading required package: rJava
```

```
## Loading required package: methods
```

```
## Loading required package: rrdflibs
```

```
## Loading required package: xlsx
```

```
## Loading required package: xlsxjars
```

```
## Loading required package: RCurl
```

```
## Loading required package: bitops
```

```
## 
## Attaching package: 'RCurl'
```

```
## The following object is masked from 'package:rJava':
## 
##     clone
```

```
## Loading required package: rrdfancillary
```

```
## Loading required package: rrdfqb
```

```
## Loading required package: rrdfcdisc
```

```
## Loading required package: devtools
```

```
## 
## Attaching package: 'rrdfqbcrnd0'
```

```
## The following object is masked from 'package:rrdfcdisc':
## 
##     summarize.rdf.noprint
```

When creating vignettes the code hangs. Hence the code is disabled.

Use eval=TRUE to get it to run. Note that it the shiny app does not respond, try to run it in a browser.


```r
do_sparql("aa")
```
