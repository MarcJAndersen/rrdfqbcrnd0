---
title: "SPARQL scripts for RDF data cubes"
author: "PhuseSubTeamAnalysisResults@example.org"
date: "2016-03-01"
output: 
  html_document
  pdf_document
vignette: >
  %\VignetteIndexEntry{SPARQL scripts for RDF data cubes}
  %\VignetteEngine{knitr::knitr}
  %\usepackage[utf8]{inputenc}
  %\SweaveUTF8
---

# SPARQL scripts for the demographics cube (DC-DEMO-sample.ttl)


## Setup

First load the package.

```r
library(knitr)
library(rrdfqbcrnd0)
```

```
## Loading required package: xlsx
```

```
## Loading required package: rJava
```

```
## Loading required package: methods
```

```
## Loading required package: xlsxjars
```

```
## Loading required package: RCurl
```

```
## Loading required package: bitops
```

```
## 
## Attaching package: 'RCurl'
```

```
## The following object is masked from 'package:rJava':
## 
##     clone
```

```
## Loading required package: rrdf
```

```
## Loading required package: rrdflibs
```

```
## Loading required package: rrdfancillary
```

```
## Loading required package: rrdfqb
```

```
## Loading required package: rrdfcdisc
```

```
## Loading required package: devtools
```

```
## 
## Attaching package: 'rrdfqbcrnd0'
```

```
## The following object is masked from 'package:rrdfcdisc':
## 
##     summarize.rdf.noprint
```

## Internals

The display of SPARQL script in markdown is done by first creating a chunk, and then using the chunk with the highlight engine in knitr. The advantage of this approach is that all formatting is handled by external packages. To make the highlight output work in markdown two blanks has to be added at the end of line according to markdown syntax.

```r
mdwrite<- function( sparqlStatements, refname ) {
# fn<- file.path(tempdir(), paste0( refname, ".rq" ) )
fn<- file.path(system.file("extdata/sample-rdf", package="rrdfqbcrnd0"), paste0( refname, ".rq" ) )
cat( paste0("## @knitr ", refname), gsub("\\n", "  \n", sparqlStatements), sep="  \n", file=fn)
knitr::read_chunk( fn, from=c(1))
invisible(fn)
}
```



## SPARQL scripts

The rrdfqbcrnd0 package uses SPARQL scripts to access the RRDF triple
store.  This is implemented by having a function generating the SPARQL
script. The generated SPARQL scripts are shown here for the
demographics cube in DC-DEMO-sample.ttl.

The turtle file and the scrips are stored in

```r
system.file("extdata/sample-xpt", package="rrdfqbcrnd0")
```

```
## [1] "/home/ma/R/x86_64-redhat-linux-gnu-library/3.2/rrdfqbcrnd0/extdata/sample-xpt"
```

## Setup for generating SPARQL scripts for the demographics cube (DC-DEMO-sample.TTL)

The DEMO data exists as a turtle file in the sample-rdf directory.


```r
dataCubeFile<- system.file("extdata/sample-rdf", "DC-DEMO-sample.ttl", package="rrdfqbcrnd0")
store <- new.rdf()  # Initialize
cat("Loading ", dataCubeFile, "\n")
```

```
## Loading
```

```r
temp<-load.rdf(dataCubeFile, format="TURTLE", appendTo= store)
```

```
## Error in .jcall("com/github/egonw/rrdf/RJenaHelper", "Lcom/hp/hpl/jena/rdf/model/Model;", : java.io.FileNotFoundException:  (No such file or directory)
```

```r
summarize.rdf(store)
```

```
## [1] "Number of triples: 40"
```

For the functions in the package the datasets definition in the cube is needed.

```r
dsdName<- GetDsdNameFromCube( store )
```

```
## Error in tempstr[[1]]: subscript out of bounds
```

```r
domainName<- GetDomainNameFromCube( store )
```

```
## Error in tempstr[[1]]: subscript out of bounds
```

```r
forsparqlprefix<- GetForSparqlPrefix( domainName )
```

```
## Error in GetForSparqlPrefix.as.df(domainName = domainName, common.prefixes = common.prefixes, : object 'domainName' not found
```


## SPARQL query for dimensions in RDF data cube

The SPARQL query for the dimensions is made by the function GetDimensionsSparqlQuery.

```r
dimensionsRq <- GetDimensionsSparqlQuery( forsparqlprefix )
```

```
## Error in paste(forsparqlprefix, "\nselect * where\n{ [] qb:dimension ?p .  }\n", : object 'forsparqlprefix' not found
```

```r
mdwrite( dimensionsRq, "DEMOdimensions" )
```

```
## Error in gsub("\\n", "  \n", sparqlStatements): object 'dimensionsRq' not found
```

This does not work as of 07-dec-2015.
    {r DEMOdimensions, results='asis', engine='highlight', engine.opts='-S n3 --inline-css'}
    

Executing the SPARQL query gives:


```r
dimensions<- sparql.rdf(store, dimensionsRq)
```

```
## Error in .jcall("com/github/egonw/rrdf/RJenaHelper", "Lcom/github/egonw/rrdf/StringMatrix;", : object 'dimensionsRq' not found
```

```r
knitr::kable(dimensions)
```

```
## Error in inherits(x, "list"): object 'dimensions' not found
```


## SPARQL query for attributes in RDF data cube

The SPARQL query for the attributes is made by the function GetAttributesSparqlQuery.

```r
attributesRq<- GetAttributesSparqlQuery( forsparqlprefix )
```

```
## Error in paste(forsparqlprefix, "\nselect * where\n{ ?p a qb:AttributeProperty .  }\n", : object 'forsparqlprefix' not found
```

```r
mdwrite( attributesRq, "DEMOattributes" )
```

```
## Error in gsub("\\n", "  \n", sparqlStatements): object 'attributesRq' not found
```

This does not work as of 07-dec-2015.
    {r DEMOattributes, results='asis', engine='highlight', engine.opts='-S n3 --inline-css'}
    

Executing the SPARQL query gives:


```r
attributes<- sparql.rdf(store, attributesRq)
```

```
## Error in .jcall("com/github/egonw/rrdf/RJenaHelper", "Lcom/github/egonw/rrdf/StringMatrix;", : object 'attributesRq' not found
```

```r
knitr::kable(attributes)
```

```
## Error in as.data.frame.default(x): cannot coerce class ""function"" to a data.frame
```

## SPARQL query for observations from RDF data cube in workbook format

The SPARQL query for the attributes is made by the function
GetAttributesSparqlQuery, where the domainName, dimensions and
attributes for the cube is passed as parameters.


```r
observationsRq<- GetObservationsSparqlQuery( forsparqlprefix, domainName, dimensions, attributes )
```

```
## Error in paste(forsparqlprefix, "select * where {", "?s a qb:Observation  ;", : object 'forsparqlprefix' not found
```

```r
mdwrite( observationsRq, "DEMOobservations" )
```

```
## Error in gsub("\\n", "  \n", sparqlStatements): object 'observationsRq' not found
```

This does not work as of 07-dec-2015.
    {r DEMOobservations, results='asis', engine='highlight', engine.opts='-S n3 --inline-css'}
    

The first 2 rows of result of the query is:


```r
observations<- sparql.rdf(store, observationsRq)
```

```
## Error in .jcall("com/github/egonw/rrdf/RJenaHelper", "Lcom/github/egonw/rrdf/StringMatrix;", : object 'observationsRq' not found
```

```r
knitr::kable(head(observations,2))
```

```
## Error in head(observations, 2): error in evaluating the argument 'x' in selecting a method for function 'head': Error: object 'observations' not found
```

# TODO(mja): SPARQL scripts parametrised

This vignettes shows the contents of the scripts. Some of the scripts
are parametrised by one or more parameters. The parameter are shown
with as $p, $q etc, following the same convention as in the
(http://www.w3.org/TR/vocab-data-cube/#ic-20)[RDF Data Cube Vocabulary]. This
does not really work here, as some of the parameters in the R
functions are intended for vectors with more than one parameter.

# TODO(mja): Generating this output using the information in the documentation

TODO(mja): enter the commands here as example in each of the .Rd files.
Then the output here can be generated from the .Rd files.


