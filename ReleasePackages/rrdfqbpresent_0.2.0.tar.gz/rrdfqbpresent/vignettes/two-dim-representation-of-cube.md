---
title: "Two dimensional representation of RDF data cube"
author: "PhuseSubTeamAnalysisResults@example.org"
date: "2016-01-03"
vignette: >
  %\VignetteIndexEntry{Two dimensional representation of RDF data cube}
  %\VignetteEngine{knitr::knitr}
  %\usepackage[utf8]{inputenc}
  %\SweaveUTF8
---

# Setup

First load the package.

```r
library(rrdfqbcrnd0)
```

```
## Loading required package: xlsx
## Loading required package: rJava
## Loading required package: methods
## Loading required package: xlsxjars
## Loading required package: RCurl
## Loading required package: bitops
## 
## Attaching package: 'RCurl'
## 
## The following object is masked from 'package:rJava':
## 
##     clone
## 
## Loading required package: rrdf
## Loading required package: rrdflibs
```

```r
library(rrdfqbcrndex)
```

```
## Error in library(rrdfqbcrndex): there is no package called 'rrdfqbcrndex'
```


# Current - 08-may-2015

The following code is under development. It creates HTML files
under extdata/sample-cfg showing a two dimensional representation
of the RDF data cube.

Here are some the features that are evaluated
- drag and drop of measure - could be used for creating a new table from existing
- store RDF as RDFa - could be used to embed the whole cube in the file; looks like it gets to big

Pending: including the rest of the cube into the
html. Consider if in each cell only the observation and measure should
be referenced and not all properties and objects for the observation.


## Using with RDFa

The function `MakeHTMLfromQb` is used to create the HTML file. When invoked with `useRDFa=TRUE` the generated HTML will contain RDFa markup.

The HTML includes green-turtle
(https://github.com/alexmilowski/green-turtle), jquery
(http://jquery.com/) and jqueryUI (http://jqueryui.com/).

In my setup I store the project under packages, and can symlink to the
files from the extdata/sample-cfg directory.

    cd extdata/sample-cfg
    ln -s ~/packages/green-turtle/build/RDFa.min.1.4.0.js 
    ln -s ~/packages/green-turtle/build/RDFaProcessor.min.1.4.0.js 
    ln -s ~/packages/jquery-2.1.3.min/jquery-2.1.3.min.js .
    ln -s ~/packages/jquery-ui-1.11.3.custom .



```r
MakeTable<- function( dataCubeFile, htmlfile, rowdim, coldim, idrow, idcol ) {
    store <- new.rdf()  # Initialize
    cat("Loading ", dataCubeFile, "\n")
    temp<-load.rdf(dataCubeFile, format="TURTLE", appendTo= store)
    summarize.rdf(store)
    dsdName<- GetDsdNameFromCube( store )
    domainName<- GetDomainNameFromCube( store )
    forsparqlprefix<- GetForSparqlPrefix( domainName )

    dimensions<- sparql.rdf(store, GetDimensionsSparqlQuery( forsparqlprefix ) )
    attributesDf<- sparql.rdf(store, GetAttributesSparqlQuery( forsparqlprefix ))

    outhtmlfile<- MakeHTMLfromQb( store, forsparqlprefix, dsdName, domainName,
                                 dimensions, rowdim, coldim, idrow, idcol,
                                 htmlfile, useRDFa=FALSE, compactDimColumns=FALSE)

    outhtmlfile
}
```

## Create AE html example


```r
dataCubeFile<- system.file("extdata/sample-rdf", "DC-AE-sample.ttl", package="rrdfcrndex")
htmlfile<- file.path(system.file("extdata/sample-html", package="rrdfqbpresent"), "DC-AE-sample.html")
rowdim<- c("crnd-attribute:rowno", "crnd-dimension:aesoc", "crnd-dimension:aedecod" )
coldim<- c("crnd-attribute:colno", "crnd-attribute:cellpartno", "crnd-dimension:trta", "crnd-dimension:factor", "crnd-dimension:procedure" )
# idrow is a function of rowdim; writing it directly is easier for now
idrow<-  c( "aesocvalue", "aedecodvalue" )
idcol<-  c( "crnd-dimension:trta" )
resHtmlFile<- MakeTable( dataCubeFile, htmlfile, rowdim, coldim, idrow, idcol )
```

```
## Loading
```

```
## Error in .jcall("com/github/egonw/rrdf/RJenaHelper", "Lcom/hp/hpl/jena/rdf/model/Model;", : java.io.FileNotFoundException:  (No such file or directory)
```

```r
cat("HTML stored as: ", normalizePath(resHtmlFile), "\n")
```

```
## Error in path.expand(path): object 'resHtmlFile' not found
```

## Create DEMO html example


```r
dataCubeFile<- system.file("extdata/sample-rdf", "DC-DEMO-sample.ttl", package="rrdfqbcrndex")
htmlfile<- file.path(system.file("extdata/sample-cfg", package="rrdfqbcrnd0"), "DC-DEMO-sample.html")

coldim<- c("crnd-attribute:colno", "crnd-attribute:cellpartno", "crnd-dimension:trt01a", "crnd-dimension:factor", "crnd-dimension:procedure" )
rowdim<- c("crnd-attribute:rowno", "crnd-dimension:agegr1", "crnd-dimension:race", "crnd-dimension:ethnic", "crnd-dimension:sex" )
idrow<-  c( "agegr1value", "racevalue", "ethnicvalue", "sexvalue" )
idcol<-  c( "crnd-dimension:trt01a" )

resHtmlFile<- MakeTable( dataCubeFile, htmlfile, rowdim, coldim, idrow, idcol )
```

```
## Loading
```

```
## Error in .jcall("com/github/egonw/rrdf/RJenaHelper", "Lcom/hp/hpl/jena/rdf/model/Model;", : java.io.FileNotFoundException:  (No such file or directory)
```

```r
cat("HTML stored as: ", normalizePath(resHtmlFile), "\n")
```

```
## Error in path.expand(path): object 'resHtmlFile' not found
```

## For development

### Setup


```r
store <- new.rdf()  # Initialize
cat("Loading ", dataCubeFile, "\n")
```

```
## Loading
```

```r
temp<-load.rdf(dataCubeFile, format="TURTLE", appendTo= store)
```

```
## Error in .jcall("com/github/egonw/rrdf/RJenaHelper", "Lcom/hp/hpl/jena/rdf/model/Model;", : java.io.FileNotFoundException:  (No such file or directory)
```

```r
summarize.rdf(store)
```

```
## [1] "Number of triples: 40"
```

```r
dsdName<- GetDsdNameFromCube( store )
```

```
## Error in eval(expr, envir, enclos): could not find function "GetDsdNameFromCube"
```

```r
domainName<- GetDomainNameFromCube( store )
```

```
## Error in GetDomainNameFromCube(store): could not find function "GetDsdNameFromCube"
```

```r
forsparqlprefix<- GetForSparqlPrefix( domainName )
```

```
## Error in GetForSparqlPrefix(domainName): could not find function "Get.rq.prefix.df"
```

### Check GetTwoDimTableFromQb


```r
dataCubeFile<- system.file("extdata/sample-rdf", "DC-DEMO-sample.ttl", package="rrdfqbcrnd0")
store <- new.rdf()  # Initialize
cat("Loading ", dataCubeFile, "\n")
```

```
## Loading  /home/ma/R/x86_64-redhat-linux-gnu-library/3.2/rrdfqbcrnd0/extdata/sample-rdf/DC-DEMO-sample.ttl
```

```r
temp<-load.rdf(dataCubeFile, format="TURTLE", appendTo= store)
dsdName<- GetDsdNameFromCube( store )
```

```
## Error in eval(expr, envir, enclos): could not find function "GetDsdNameFromCube"
```

```r
domainName<- GetDomainNameFromCube( store )
```

```
## Error in GetDomainNameFromCube(store): could not find function "GetDsdNameFromCube"
```

```r
forsparqlprefix<- GetForSparqlPrefix( domainName )
```

```
## Error in GetForSparqlPrefix(domainName): could not find function "Get.rq.prefix.df"
```

```r
coldim<- c("crnd-attribute:colno", "crnd-attribute:cellpartno", "crnd-dimension:trt01a" )
rowdim<- c("crnd-attribute:rowno", "crnd-dimension:agegr1", "crnd-dimension:race",
           "crnd-dimension:ethnic", "crnd-dimension:sex", "crnd-dimension:procedure" )
xqbtest<- GetTwoDimTableFromQb( store, forsparqlprefix, domainName, rowdim, coldim )
```

```
## Error in eval(expr, envir, enclos): could not find function "GetTwoDimTableFromQb"
```

```r
dimensionsRq <- GetDimensionsSparqlQuery( forsparqlprefix )
```

```
## Error in eval(expr, envir, enclos): could not find function "GetDimensionsSparqlQuery"
```

```r
dimensions<- sparql.rdf(store, dimensionsRq)
```

```
## Error in .jcall("com/github/egonw/rrdf/RJenaHelper", "Lcom/github/egonw/rrdf/StringMatrix;", : object 'dimensionsRq' not found
```

```r
attributesRq<- GetAttributesSparqlQuery( forsparqlprefix )
```

```
## Error in eval(expr, envir, enclos): could not find function "GetAttributesSparqlQuery"
```

```r
attributes<- sparql.rdf(store, attributesRq)
```

```
## Error in .jcall("com/github/egonw/rrdf/RJenaHelper", "Lcom/github/egonw/rrdf/StringMatrix;", : object 'attributesRq' not found
```

```r
observationsDescriptionRq<- GetObservationsWithDescriptionSparqlQuery( forsparqlprefix, domainName, dimensions, attributes )
```

```
## Error in paste(forsparqlprefix, "select * where {", "\n", "?s a qb:Observation  ;", : object 'forsparqlprefix' not found
```

```r
observationsDesc<- as.data.frame(sparql.rdf(store, observationsDescriptionRq ), stringsAsFactors=FALSE)
```

```
## Error in .jcall("com/github/egonw/rrdf/RJenaHelper", "Lcom/github/egonw/rrdf/StringMatrix;", : object 'observationsDescriptionRq' not found
```

### View a specific observation.

The observation is specified in the values part of the SPARQL query.


```r
cube.observations.rq<-  paste( forsparqlprefix,
'
select *
where { 
?s a qb:Observation ; 
?p ?o .
values (?s) {
(ds:obs029)
}
}
',
"\n"                               
)
```

```
## Error in paste(forsparqlprefix, "\nselect *\nwhere { \n?s a qb:Observation ; \n?p ?o .\nvalues (?s) {\n(ds:obs029)\n}\n}\n", : object 'forsparqlprefix' not found
```

```r
cube.observations<- sparql.rdf(store, cube.observations.rq)
```

```
## Error in .jcall("com/github/egonw/rrdf/RJenaHelper", "Lcom/github/egonw/rrdf/StringMatrix;", : object 'cube.observations.rq' not found
```

```r
knitr::kable(cube.observations)
```

```
## Error in is.data.frame(x): object 'cube.observations' not found
```

### View formating of measure


```r
cube.measurefmt.rq<-  paste( forsparqlprefix,
'
select distinct ?procedure ?measurefmt
where { 
?s a qb:Observation ; 
crnd-dimension:procedure ?procedure ;
crnd-attribute:measurefmt ?measurefmt .
}
',
"\n"                               
)
```

```
## Error in paste(forsparqlprefix, "\nselect distinct ?procedure ?measurefmt\nwhere { \n?s a qb:Observation ; \ncrnd-dimension:procedure ?procedure ;\ncrnd-attribute:measurefmt ?measurefmt .\n}\n", : object 'forsparqlprefix' not found
```

```r
cube.measurefmt<- sparql.rdf(store, cube.measurefmt.rq)
```

```
## Error in .jcall("com/github/egonw/rrdf/RJenaHelper", "Lcom/github/egonw/rrdf/StringMatrix;", : object 'cube.measurefmt.rq' not found
```

```r
knitr::kable(cube.measurefmt)
```

```
## Error in is.data.frame(x): object 'cube.measurefmt' not found
```

### Columns

The contents of the 

```r
cols.rq<- GetRownoColnoCellpartnoSparqlQuery( forsparqlprefix )
```

```
## Error in eval(expr, envir, enclos): could not find function "GetRownoColnoCellpartnoSparqlQuery"
```

```r
cols<- data.frame(sparql.rdf(store, cols.rq))
```

```
## Error in .jcall("com/github/egonw/rrdf/RJenaHelper", "Lcom/github/egonw/rrdf/StringMatrix;", : object 'cols.rq' not found
```

```r
knitr::kable(cols)
```

```
## Error in is.data.frame(x): object 'cols' not found
```


# Session information

```r
sessionInfo()
```

```
## R version 3.2.3 (2015-12-10)
## Platform: x86_64-redhat-linux-gnu (64-bit)
## Running under: Fedora 23 (Workstation Edition)
## 
## locale:
##  [1] LC_CTYPE=en_GB.UTF-8          LC_NUMERIC=C                 
##  [3] LC_TIME=en_GB.UTF-8           LC_COLLATE=en_GB.UTF-8       
##  [5] LC_MONETARY=en_GB.UTF-8       LC_MESSAGES=en_GB.UTF-8      
##  [7] LC_PAPER=en_GB.UTF-8          LC_NAME=en_GB.UTF-8          
##  [9] LC_ADDRESS=en_GB.UTF-8        LC_TELEPHONE=en_GB.UTF-8     
## [11] LC_MEASUREMENT=en_GB.UTF-8    LC_IDENTIFICATION=en_GB.UTF-8
## 
## attached base packages:
## [1] methods   stats     graphics  grDevices utils     datasets  base     
## 
## other attached packages:
## [1] rrdfqbcrnd0_0.2.0 rrdf_2.1.2        rrdflibs_1.4.0    RCurl_1.95-4.7   
## [5] bitops_1.0-6      xlsx_0.5.7        xlsxjars_0.6.1    rJava_0.9-7      
## 
## loaded via a namespace (and not attached):
## [1] magrittr_1.5  formatR_1.2.1 tools_3.2.3   stringi_1.0-1 knitr_1.11   
## [6] stringr_1.0.0 evaluate_0.8
```

