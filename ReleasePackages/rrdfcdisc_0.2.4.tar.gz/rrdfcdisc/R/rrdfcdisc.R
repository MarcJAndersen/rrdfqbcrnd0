##' rrdfcdisc.
##'
##' @name rrdfcdisc
##' @docType package
## documentation for dataset - following ggplot2.r MJA 2014-11-16
NULL


##' Default PREFIXes for SPARQL queries
##'
##' 
##' @docType data
##' @keywords datasets
##' @name qbCDISCprefixes
##' @usage data(qbCDISCprefixes)
##' @format A list of PREFIXes for SPARQL queries
NULL



##' Package locale environment
##'
##' @docType data
##' @name env
NULL

