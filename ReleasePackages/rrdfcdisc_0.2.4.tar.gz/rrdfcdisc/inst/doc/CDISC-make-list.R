## ---- results='asis', eval=TRUE------------------------------------------
library(rrdfancillary)
require(rrdfcdisc)

## ---- results='asis', eval=TRUE------------------------------------------
cdisc.rdf<- Load.cdisc.standards()
message(".. total number of triples: ", summarize.rdf.noprint(cdisc.rdf) )

## ---- results='asis', eval=TRUE------------------------------------------
nciDomainValue<- "sdtmct:C66731"
query <- GetCDISCCodeListSparqlQuery( Get.rq.prefixlist.df(qbCDISCprefixes), nciDomainValue )
codeSource <- as.data.frame(sparql.rdf(cdisc.rdf, query),stringsAsFactors=FALSE)

knitr::kable(codeSource)

## ---- results='asis', eval=TRUE------------------------------------------
query.rq<-'
select *
where {
  ?column a <http://rdf.cdisc.org/mms#Column> .
  ?column <http://rdf.cdisc.org/mms#context> ?dataset .
  ?dataset a <http://rdf.cdisc.org/mms#Dataset>.
  optional { ?column <http://rdf.cdisc.org/mms#dataElementLabel> ?label }
  optional { ?column <http://rdf.cdisc.org/std/schema#controlledTermsOrFormat> ?controlledTermsOrFormat }
  optional { ?column <http://rdf.cdisc.org/std/schema#dataElementCompliance> ?dataElementCompliance }
  optional { ?column <http://rdf.cdisc.org/std/schema#dataElementRole> ?dataElementRole }
  optional { ?column <http://rdf.cdisc.org/std/schema#dataElementType> ?dataElementType }
  optional { ?column <http://rdf.cdisc.org/std/schema#references> ?references }
  optional { ?column <http://rdf.cdisc.org/mms#dataElement> ?dataElement }
  optional { ?column <http://rdf.cdisc.org/mms#dataElementDescription> ?dataElementDescription }
  optional { ?column <http://rdf.cdisc.org/mms#dataElementName> ?dataElementName }
  optional { ?column <http://rdf.cdisc.org/mms#dataElementValueDomain> ?dataElementValueDomain }
  optional { ?column <http://rdf.cdisc.org/mms#ordinal> ?ordinal }
  values (?dataset) {(<http://rdf.cdisc.org/std/sdtmig-3-1-3#Dataset.DM>)}
  }
  order by ?dataset ?ordinal 
'
datasetDef <- as.data.frame(sparql.rdf(cdisc.rdf, query.rq),stringsAsFactors=FALSE)

## ---- results='asis', eval=TRUE------------------------------------------
knitr::kable(datasetDef[,c("dataset", "ordinal", "dataElementName", "label")])

