## ---- eval=TRUE----------------------------------------------------------
library(rrdfqbcrnd0)

## ---- echo=TRUE----------------------------------------------------------
MakeTable<- function( dataCubeFile, htmlfile, rowdim, coldim, idrow, idcol ) {
    store <- new.rdf()  # Initialize
    cat("Loading ", dataCubeFile, "\n")
    load.rdf(dataCubeFile, format="TURTLE", appendTo= store)
    summarize.rdf(store)
    dsdName<- GetDsdNameFromCube( store )
    domainName<- GetDomainNameFromCube( store )
    forsparqlprefix<- GetForSparqlPrefix( domainName )

    dimensions<- sparql.rdf(store, GetDimensionsSparqlQuery( forsparqlprefix ) )
    attributesDf<- sparql.rdf(store, GetAttributesSparqlQuery( forsparqlprefix ))

    outhtmlfile<- MakeHTMLfromQb( store, forsparqlprefix, dsdName, domainName,
                                 dimensions, rowdim, coldim, idrow, idcol,
                                 htmlfile, useRDFa=FALSE, compactDimColumns=FALSE)

    outhtmlfile
}


