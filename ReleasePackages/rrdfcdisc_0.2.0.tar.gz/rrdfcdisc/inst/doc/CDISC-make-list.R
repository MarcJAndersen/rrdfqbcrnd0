## ---- results='asis', eval=TRUE------------------------------------------
require("rrdfcdisc")

## ---- results='asis', eval=TRUE------------------------------------------
cdisc.rdf<- Load.cdisc.standards()
message(".. total number of triples: ", summarize.rdf.noprint(cdisc.rdf) )

## ---- results='asis', eval=TRUE------------------------------------------
CDISCsparqlprefix<-'
prefix : <http://rdf.cdisc.org/sdtm-terminology#>
prefix cts:   <http://rdf.cdisc.org/ct/schema#>
prefix xsd:   <http://www.w3.org/2001/XMLSchema#>
prefix mms:   <http://rdf.cdisc.org/mms#>
'

nciDomainValue<- "C66731"
query <- GetCDISCCodeListSparqlQuery( CDISCsparqlprefix, nciDomainValue )
codeSource <- as.data.frame(sparql.rdf(cdisc.rdf, query))

knitr::kable(codeSource)

