##' rrdfqb.
##'
##' @name rrdfqb
##' @docType package
## documentation for dataset
NULL

##' 
##' Package locale environment
##'
##' @docType data
##' @name env
NULL

