---
title: "Create simple RDF data qube"
author: "PhuseSubTeamAnalysisResults@example.org"
date: "2016-04-20"
vignette: >
  %\VignetteIndexEntry{Create simple RDF data qube}
  %\VignetteEngine{knitr::rmarkdown}
  \usepackage[utf8]{inputenc}
---

## Introduction
This vignette shows how to 
- create a very simple RDF data cube from data and metadata  
- query the cube using SPARQL
- execute the RDF data cube integrity checks

# Setup

The next command is not needed if the package have been loaded throug devtools::load_all().

```r
library(rrdfcdisc)
```

```
## Loading required package: RCurl
```

```
## Loading required package: methods
```

```
## Loading required package: bitops
```

```
## Loading required package: rrdf
```

```
## Loading required package: rJava
```

```
## 
## Attaching package: 'rJava'
```

```
## The following object is masked from 'package:RCurl':
## 
##     clone
```

```
## Loading required package: rrdflibs
```

```
## Loading required package: devtools
```

```
## Loading required package: rrdfancillary
```

```r
library(rrdfqb)
```

```
## Loading required package: xlsx
```

```
## Loading required package: xlsxjars
```

```r
library(rrdfqbcrnd0)
```

# Create RDF data cube
The RDF data cube will be created from two data.frames containing data and metadata.

## Define data
The data are defined as data frame, and the data frame is displayed.

```r
obsData<- data.frame(
  category=c("AA-group", "BB-group"),
  procedure=c("count", "count" ),
  factor=c("quantity", "quantity" ),
  unit=c("subject", "subject" ),
  denominator=c(" ", " "),
  measure=c( 123, 456 ),
  stringsAsFactors=FALSE  )
knitr::kable(obsData)
```



|category |procedure |factor   |unit    |denominator | measure|
|:--------|:---------|:--------|:-------|:-----------|-------:|
|AA-group |count     |quantity |subject |            |     123|
|BB-group |count     |quantity |subject |            |     456|

## Define meta data
The metadata used for generating the RDF data cube are also defined as data frame and displayed.

```r
cubeMetadata<- data.frame(
  compType=c("dimension", "dimension", "dimension", "unit", "denominator", "measure", "metadata"),
  compName=c("category", "procedure", "factor", "attribute", "attribute", "measure", "domainName"),
  codeType=c("DATA", "DATA", "DATA", " ", " ", "<NA>","<NA>"),
  nciDomainValue=c(" "," "," "," ", " ", " "," "),
  compLabel=c("Category", "Statistical procedure", "Type of procedure", "Result", "Unit", "Denominator", "EXAMPLE"),
  Comment=c(" "," "," "," "," "," "," "),
  stringsAsFactors=FALSE  )
knitr::kable(cubeMetadata)
```



|compType    |compName   |codeType |nciDomainValue |compLabel             |Comment |
|:-----------|:----------|:--------|:--------------|:---------------------|:-------|
|dimension   |category   |DATA     |               |Category              |        |
|dimension   |procedure  |DATA     |               |Statistical procedure |        |
|dimension   |factor     |DATA     |               |Type of procedure     |        |
|unit        |attribute  |         |               |Result                |        |
|denominator |attribute  |         |               |Unit                  |        |
|measure     |measure    |<NA>     |               |Denominator           |        |
|metadata    |domainName |<NA>     |               |EXAMPLE               |        |

## Create RDF data cube

The RDF data cube for the data above is created using

```r
outcube<- BuildCubeFromDataFrames(cubeMetadata, obsData )
```

```
## [1] "prefix rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>\nprefix skos: <http://www.w3.org/2004/02/skos/core#>\nprefix prov: <http://www.w3.org/ns/prov#>\nprefix rdfs: <http://www.w3.org/2000/01/rdf-schema#>\nprefix dcat: <http://www.w3.org/ns/dcat#>\nprefix owl: <http://www.w3.org/2002/07/owl#>\nprefix xsd: <http://www.w3.org/2001/XMLSchema#>\nprefix pav: <http://purl.org/pav>\nprefix dc: <http://purl.org/dc/elements/1.1/>\nprefix dct: <http://purl.org/dc/terms/>\nprefix mms: <http://rdf.cdisc.org/mms#>\nprefix cts: <http://rdf.cdisc.org/ct/schema#>\nprefix cdiscs: <http://rdf.cdisc.org/std/schema#>\nprefix cdash-1-1: <http://rdf.cdisc.org/std/cdash-1-1#>\nprefix cdashct: <http://rdf.cdisc.org/cdash-terminology#>\nprefix sdtmct: <http://rdf.cdisc.org/sdtm-terminology#>\nprefix sdtm-1-2: <http://rdf.cdisc.org/std/sdtm-1-2#>\nprefix sdtm-1-3: <http://rdf.cdisc.org/std/sdtm-1-3#>\nprefix sdtms-1-3: <http://rdf.cdisc.org/sdtm-1-3/schema#>\nprefix sdtmig-3-1-2: <http://rdf.cdisc.org/std/sdtmig-3-1-2#>\nprefix sdtmig-3-1-3: <http://rdf.cdisc.org/std/sdtmig-3-1-3#>\nprefix sendct: <http://rdf.cdisc.org/send-terminology#>\nprefix sendig-3-0: <http://rdf.cdisc.org/std/sendig-3-0#>\nprefix adamct: <http://rdf.cdisc.org/adam-terminology#>\nprefix adam-2-1: <http://rdf.cdisc.org/std/adam-2-1#>\nprefix adamig-1-0: <http://rdf.cdisc.org/std/adamig-1-0#>\nprefix adamvr-1-2: <http://rdf.cdisc.org/std/adamvr-1-2#>\nprefix qb: <http://purl.org/linked-data/cube#>\nprefix rrdfqbcrnd0: <http://www.example.org/rrdfqbcrnd0/>\nprefix code: <http://www.example.org/dc/code/>\nprefix dccs: <http://www.example.org/dc/example/dccs/>\nprefix ds: <http://www.example.org/dc/example/ds/>\nprefix crnd-dimension: <http://www.example.org/dc/dimension#>\nprefix crnd-attribute: <http://www.example.org/dc/attribute#>\nprefix crnd-measure: <http://www.example.org/dc/measure#>\n \nselect distinct ?DataStructureDefinition ?dimension ?cprefLabel ?cl ?clprefLabel ?vn ?vct ?vnop ?vnval\nwhere {\n   ?DataStructureDefinition a qb:DataStructureDefinition ;\n        qb:component ?component .\n   ?component a qb:ComponentSpecification .\n   ?component qb:dimension ?dimension .\n\n   ?dimension qb:codeList ?c .\n   OPTIONAL { ?c skos:prefLabel ?cprefLabel .   }\n   OPTIONAL { ?c rrdfqbcrnd0:DataSetRefD2RQ ?vnop . }\n   OPTIONAL { ?c rrdfqbcrnd0:R-columnname ?vn . }\n   OPTIONAL { ?c rrdfqbcrnd0:codeType     ?vct .          }\n\n   ?c skos:hasTopConcept ?cl .\n   OPTIONAL { ?cl skos:prefLabel ?clprefLabel . }\n   OPTIONAL { ?cl rrdfqbcrnd0:R-selectionoperator ?vnop . }\n   OPTIONAL { ?cl rrdfqbcrnd0:R-selectionvalue ?vnval .   }\n values ( ?DataStructureDefinition ) {\n(ds:dsd-EXAMPLE)\n} \n}\norder by ?dimension ?cl ?dimensionrefLabel\n"
##   DataStructureDefinition                dimension
## 1          ds:dsd-EXAMPLE  crnd-dimension:category
## 2          ds:dsd-EXAMPLE  crnd-dimension:category
## 3          ds:dsd-EXAMPLE  crnd-dimension:category
## 4          ds:dsd-EXAMPLE  crnd-dimension:category
## 5          ds:dsd-EXAMPLE    crnd-dimension:factor
## 6          ds:dsd-EXAMPLE    crnd-dimension:factor
## 7          ds:dsd-EXAMPLE    crnd-dimension:factor
## 8          ds:dsd-EXAMPLE crnd-dimension:procedure
##                   cprefLabel                      cl clprefLabel        vn
## 1  Codelist scheme: category  code:category-AA-group    AA-group  category
## 2  Codelist scheme: category  code:category-BB-group    BB-group  category
## 3  Codelist scheme: category     code:category-_ALL_       _ALL_  category
## 4  Codelist scheme: category code:category-_NONMISS_   _NONMISS_  category
## 5    Codelist scheme: factor       code:factor-_ALL_       _ALL_    factor
## 6    Codelist scheme: factor   code:factor-_NONMISS_   _NONMISS_    factor
## 7    Codelist scheme: factor    code:factor-quantity    quantity    factor
## 8 Codelist scheme: procedure    code:procedure-count       count procedure
##    vct                          vnop    vnval
## 1 DATA rrdfqbcrnd0:NOTGIVEN_CATEGORY AA-group
## 2 DATA rrdfqbcrnd0:NOTGIVEN_CATEGORY BB-group
## 3 DATA rrdfqbcrnd0:NOTGIVEN_CATEGORY     <NA>
## 4 DATA rrdfqbcrnd0:NOTGIVEN_CATEGORY     <NA>
## 5 DATA                          <NA>     <NA>
## 6 DATA                          <NA>     <NA>
## 7 DATA                            == quantity
## 8 DATA                            ==    count
## crnd-dimension:category crnd-dimension:category crnd-dimension:category crnd-dimension:category crnd-dimension:factor crnd-dimension:factor crnd-dimension:factor crnd-dimension:procedure 
##   DataStructureDefinition dimension                cprefLabel
## 1          ds:dsd-EXAMPLE  category Codelist scheme: category
## 2          ds:dsd-EXAMPLE  category Codelist scheme: category
## 3          ds:dsd-EXAMPLE  category Codelist scheme: category
## 4          ds:dsd-EXAMPLE  category Codelist scheme: category
##                        cl clprefLabel       vn  vct
## 1  code:category-AA-group    AA-group category DATA
## 2  code:category-BB-group    BB-group category DATA
## 3     code:category-_ALL_       _ALL_ category DATA
## 4 code:category-_NONMISS_   _NONMISS_ category DATA
##                            vnop    vnval      vn1      vn2       clc
## 1 rrdfqbcrnd0:NOTGIVEN_CATEGORY AA-group category category  AA-group
## 2 rrdfqbcrnd0:NOTGIVEN_CATEGORY BB-group category category  BB-group
## 3 rrdfqbcrnd0:NOTGIVEN_CATEGORY     <NA> category category     _ALL_
## 4 rrdfqbcrnd0:NOTGIVEN_CATEGORY     <NA> category category _NONMISS_
## $`AA-group`
## [1] "AA-group"
## 
## $`BB-group`
## [1] "BB-group"
## 
## $`_ALL_`
## [1] "_ALL_"
## 
## $`_NONMISS_`
## [1] "_NONMISS_"
## 
##   DataStructureDefinition dimension              cprefLabel
## 5          ds:dsd-EXAMPLE    factor Codelist scheme: factor
## 6          ds:dsd-EXAMPLE    factor Codelist scheme: factor
## 7          ds:dsd-EXAMPLE    factor Codelist scheme: factor
##                      cl clprefLabel     vn  vct vnop    vnval    vn1
## 5     code:factor-_ALL_       _ALL_ factor DATA <NA>     <NA> factor
## 6 code:factor-_NONMISS_   _NONMISS_ factor DATA <NA>     <NA> factor
## 7  code:factor-quantity    quantity factor DATA   == quantity factor
##      vn2       clc
## 5 factor     _ALL_
## 6 factor _NONMISS_
## 7 factor  quantity
## $`_ALL_`
## [1] "_ALL_"
## 
## $`_NONMISS_`
## [1] "_NONMISS_"
## 
## $quantity
## [1] "quantity"
## 
##   DataStructureDefinition dimension                 cprefLabel
## 8          ds:dsd-EXAMPLE procedure Codelist scheme: procedure
##                     cl clprefLabel        vn  vct vnop vnval       vn1
## 8 code:procedure-count       count procedure DATA   == count procedure
##         vn2   clc
## 8 procedure count
## $count
## [1] "count"
```
This shows a simple use of the BuildCubeFromDataFrames function. 
The warning message from log4j can be ignored.

The RDF data cube is serialized in turtle format and stored as a text file in

```r
cat(normalizePath(outcube),"\n")
```

```
## /tmp/Rtmpdd2gGN/DC-EXAMPLE-R-V-0-0-0.ttl
```

# Query the cube using SPARQL

Now take a look at the generated cubes by loading the turle file.



```r
dataCubeFile<- outcube
```

The rest of the code only depends on the value of dataCubeFile.
The code demonstrates the use of the rrdf library.


```r
cube <- new.rdf()  # Initialize
temp<- load.rdf(dataCubeFile, format="TURTLE", appendTo= cube) # work around to not get it printed
summarize.rdf(cube)
```

```
## [1] "Number of triples: 223"
```

The next statements are needed for the current implementation of the cube, and may change in future versions.

```r
## TODO: reconsider the use of domain specific prefixes
dsdName<- GetDsdNameFromCube( cube )
domainName<- GetDomainNameFromCube( cube )
cat("dsdName ", dsdName, ", domainName ", domainName, "\n" )
```

```
## dsdName  dsd-EXAMPLE , domainName  EXAMPLE
```

```r
forsparqlprefix<- GetForSparqlPrefix( domainName )
cat(forsparqlprefix,"\n")
```

```
## prefix rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
## prefix skos: <http://www.w3.org/2004/02/skos/core#>
## prefix prov: <http://www.w3.org/ns/prov#>
## prefix rdfs: <http://www.w3.org/2000/01/rdf-schema#>
## prefix dcat: <http://www.w3.org/ns/dcat#>
## prefix owl: <http://www.w3.org/2002/07/owl#>
## prefix xsd: <http://www.w3.org/2001/XMLSchema#>
## prefix pav: <http://purl.org/pav>
## prefix dc: <http://purl.org/dc/elements/1.1/>
## prefix dct: <http://purl.org/dc/terms/>
## prefix mms: <http://rdf.cdisc.org/mms#>
## prefix cts: <http://rdf.cdisc.org/ct/schema#>
## prefix cdiscs: <http://rdf.cdisc.org/std/schema#>
## prefix cdash-1-1: <http://rdf.cdisc.org/std/cdash-1-1#>
## prefix cdashct: <http://rdf.cdisc.org/cdash-terminology#>
## prefix sdtmct: <http://rdf.cdisc.org/sdtm-terminology#>
## prefix sdtm-1-2: <http://rdf.cdisc.org/std/sdtm-1-2#>
## prefix sdtm-1-3: <http://rdf.cdisc.org/std/sdtm-1-3#>
## prefix sdtms-1-3: <http://rdf.cdisc.org/sdtm-1-3/schema#>
## prefix sdtmig-3-1-2: <http://rdf.cdisc.org/std/sdtmig-3-1-2#>
## prefix sdtmig-3-1-3: <http://rdf.cdisc.org/std/sdtmig-3-1-3#>
## prefix sendct: <http://rdf.cdisc.org/send-terminology#>
## prefix sendig-3-0: <http://rdf.cdisc.org/std/sendig-3-0#>
## prefix adamct: <http://rdf.cdisc.org/adam-terminology#>
## prefix adam-2-1: <http://rdf.cdisc.org/std/adam-2-1#>
## prefix adamig-1-0: <http://rdf.cdisc.org/std/adamig-1-0#>
## prefix adamvr-1-2: <http://rdf.cdisc.org/std/adamvr-1-2#>
## prefix qb: <http://purl.org/linked-data/cube#>
## prefix rrdfqbcrnd0: <http://www.example.org/rrdfqbcrnd0/>
## prefix code: <http://www.example.org/dc/code/>
## prefix dccs: <http://www.example.org/dc/example/dccs/>
## prefix ds: <http://www.example.org/dc/example/ds/>
## prefix crnd-dimension: <http://www.example.org/dc/dimension#>
## prefix crnd-attribute: <http://www.example.org/dc/attribute#>
## prefix crnd-measure: <http://www.example.org/dc/measure#>
## 
```

The variable forsparqlprefix contains the prefix statements applicable
for the present data cube. The use of prefixes makes the SPARQL query
shorter, and more readable. The present version of the package defines
namespaces dccs: and ds: where the domainname is included.
TODO: Consider other approach for including the domainname, or use other concept.

The next statement shows the first 10 triples in the cube. This will
most often not be of interest, as the RDF cube contain general
definition and not the specific cube triples.


|s             |p                  |o             |
|:-------------|:------------------|:-------------|
|rdf:rest      |rdf:type           |rdf:Property  |
|rdf:rest      |rdfs:domain        |rdf:List      |
|rdf:rest      |rdfs:range         |rdf:List      |
|rdf:rest      |rdfs:subPropertyOf |rdf:rest      |
|rdf:List      |rdf:type           |rdfs:Class    |
|rdf:List      |rdfs:subClassOf    |rdfs:Resource |
|code:Category |rdfs:subClassOf    |rdfs:Resource |
|rdf:predicate |rdf:type           |rdf:Property  |
|rdf:predicate |rdfs:domain        |rdf:Statement |
|rdf:predicate |rdfs:subPropertyOf |rdf:predicate |

The next statement gets the first 30 triples in the cube where 
the subject is a qb:Observation, and shows the first 15 triples.

```r
cube.observations2.rq<-  paste( forsparqlprefix,
'
select *
where { ?s a qb:Observation ; ?p ?o .}
limit 30
',
"\n"                               
)

cube.observations2<- sparql.rdf(cube, cube.observations2.rq)
knitr::kable(head(cube.observations2, 15))
```



|s       |p                        |o                                                                            |
|:-------|:------------------------|:----------------------------------------------------------------------------|
|ds:obs1 |crnd-measure:measure     |123                                                                          |
|ds:obs1 |crnd-dimension:procedure |code:count                                                                   |
|ds:obs1 |crnd-dimension:factor    |code:quantity                                                                |
|ds:obs1 |crnd-dimension:category  |code:AA-group                                                                |
|ds:obs1 |qb:dataSet               |ds:dataset-EXAMPLE                                                           |
|ds:obs1 |rdfs:label               |1                                                                            |
|ds:obs1 |rdfs:comment             |Statistic for number of records/Statistics for factor with the dimensions XX |
|ds:obs1 |rdf:type                 |qb:Observation                                                               |
|ds:obs2 |crnd-measure:measure     |456                                                                          |
|ds:obs2 |crnd-dimension:procedure |code:count                                                                   |
|ds:obs2 |crnd-dimension:factor    |code:quantity                                                                |
|ds:obs2 |crnd-dimension:category  |code:BB-group                                                                |
|ds:obs2 |qb:dataSet               |ds:dataset-EXAMPLE                                                           |
|ds:obs2 |rdfs:label               |2                                                                            |
|ds:obs2 |rdfs:comment             |Statistic for number of records/Statistics for factor with the dimensions XX |

The SPARQL query for codelists are shown in the next output.

```
## prefix rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
## prefix skos: <http://www.w3.org/2004/02/skos/core#>
## prefix prov: <http://www.w3.org/ns/prov#>
## prefix rdfs: <http://www.w3.org/2000/01/rdf-schema#>
## prefix dcat: <http://www.w3.org/ns/dcat#>
## prefix owl: <http://www.w3.org/2002/07/owl#>
## prefix xsd: <http://www.w3.org/2001/XMLSchema#>
## prefix pav: <http://purl.org/pav>
## prefix dc: <http://purl.org/dc/elements/1.1/>
## prefix dct: <http://purl.org/dc/terms/>
## prefix mms: <http://rdf.cdisc.org/mms#>
## prefix cts: <http://rdf.cdisc.org/ct/schema#>
## prefix cdiscs: <http://rdf.cdisc.org/std/schema#>
## prefix cdash-1-1: <http://rdf.cdisc.org/std/cdash-1-1#>
## prefix cdashct: <http://rdf.cdisc.org/cdash-terminology#>
## prefix sdtmct: <http://rdf.cdisc.org/sdtm-terminology#>
## prefix sdtm-1-2: <http://rdf.cdisc.org/std/sdtm-1-2#>
## prefix sdtm-1-3: <http://rdf.cdisc.org/std/sdtm-1-3#>
## prefix sdtms-1-3: <http://rdf.cdisc.org/sdtm-1-3/schema#>
## prefix sdtmig-3-1-2: <http://rdf.cdisc.org/std/sdtmig-3-1-2#>
## prefix sdtmig-3-1-3: <http://rdf.cdisc.org/std/sdtmig-3-1-3#>
## prefix sendct: <http://rdf.cdisc.org/send-terminology#>
## prefix sendig-3-0: <http://rdf.cdisc.org/std/sendig-3-0#>
## prefix adamct: <http://rdf.cdisc.org/adam-terminology#>
## prefix adam-2-1: <http://rdf.cdisc.org/std/adam-2-1#>
## prefix adamig-1-0: <http://rdf.cdisc.org/std/adamig-1-0#>
## prefix adamvr-1-2: <http://rdf.cdisc.org/std/adamvr-1-2#>
## prefix qb: <http://purl.org/linked-data/cube#>
## prefix rrdfqbcrnd0: <http://www.example.org/rrdfqbcrnd0/>
## prefix code: <http://www.example.org/dc/code/>
## prefix dccs: <http://www.example.org/dc/example/dccs/>
## prefix ds: <http://www.example.org/dc/example/ds/>
## prefix crnd-dimension: <http://www.example.org/dc/dimension#>
## prefix crnd-attribute: <http://www.example.org/dc/attribute#>
## prefix crnd-measure: <http://www.example.org/dc/measure#>
##  
## select distinct ?DataStructureDefinition ?dimension ?cprefLabel ?cl ?clprefLabel ?vn ?vct ?vnop ?vnval
## where {
##    ?DataStructureDefinition a qb:DataStructureDefinition ;
##         qb:component ?component .
##    ?component a qb:ComponentSpecification .
##    ?component qb:dimension ?dimension .
## 
##    ?dimension qb:codeList ?c .
##    OPTIONAL { ?c skos:prefLabel ?cprefLabel .   }
##    OPTIONAL { ?c rrdfqbcrnd0:DataSetRefD2RQ ?vnop . }
##    OPTIONAL { ?c rrdfqbcrnd0:R-columnname ?vn . }
##    OPTIONAL { ?c rrdfqbcrnd0:codeType     ?vct .          }
## 
##    ?c skos:hasTopConcept ?cl .
##    OPTIONAL { ?cl skos:prefLabel ?clprefLabel . }
##    OPTIONAL { ?cl rrdfqbcrnd0:R-selectionoperator ?vnop . }
##    OPTIONAL { ?cl rrdfqbcrnd0:R-selectionvalue ?vnval .   }
##  values ( ?DataStructureDefinition ) {
## (ds:dsd-EXAMPLE)
## } 
## }
## order by ?dimension ?cl ?dimensionrefLabel
```

Executing the SPARQL query gives the code list as a data frame.

```
## Error in `[.data.frame`(cube.codelists, , c("vn", "clc", "prefLabel")): undefined columns selected
```

The dimensions are shown in the next output.

```r
cube.dimensions.rq<- paste(forsparqlprefix,
'
select * where
{ [] qb:dimension ?p .  }
',
"\n"
)
cube.dimensions<- as.data.frame(sparql.rdf(cube, cube.dimensions.rq), stringsAsFactors=FALSE)
knitr::kable(cube.dimensions)
```



|p                        |
|:------------------------|
|crnd-dimension:factor    |
|crnd-dimension:procedure |
|crnd-dimension:category  |

And finally the SPARQL query for observations.


This is the query for getting the observations

```r
cat(cube.observations.rq)
```

```
## prefix rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
## prefix skos: <http://www.w3.org/2004/02/skos/core#>
## prefix prov: <http://www.w3.org/ns/prov#>
## prefix rdfs: <http://www.w3.org/2000/01/rdf-schema#>
## prefix dcat: <http://www.w3.org/ns/dcat#>
## prefix owl: <http://www.w3.org/2002/07/owl#>
## prefix xsd: <http://www.w3.org/2001/XMLSchema#>
## prefix pav: <http://purl.org/pav>
## prefix dc: <http://purl.org/dc/elements/1.1/>
## prefix dct: <http://purl.org/dc/terms/>
## prefix mms: <http://rdf.cdisc.org/mms#>
## prefix cts: <http://rdf.cdisc.org/ct/schema#>
## prefix cdiscs: <http://rdf.cdisc.org/std/schema#>
## prefix cdash-1-1: <http://rdf.cdisc.org/std/cdash-1-1#>
## prefix cdashct: <http://rdf.cdisc.org/cdash-terminology#>
## prefix sdtmct: <http://rdf.cdisc.org/sdtm-terminology#>
## prefix sdtm-1-2: <http://rdf.cdisc.org/std/sdtm-1-2#>
## prefix sdtm-1-3: <http://rdf.cdisc.org/std/sdtm-1-3#>
## prefix sdtms-1-3: <http://rdf.cdisc.org/sdtm-1-3/schema#>
## prefix sdtmig-3-1-2: <http://rdf.cdisc.org/std/sdtmig-3-1-2#>
## prefix sdtmig-3-1-3: <http://rdf.cdisc.org/std/sdtmig-3-1-3#>
## prefix sendct: <http://rdf.cdisc.org/send-terminology#>
## prefix sendig-3-0: <http://rdf.cdisc.org/std/sendig-3-0#>
## prefix adamct: <http://rdf.cdisc.org/adam-terminology#>
## prefix adam-2-1: <http://rdf.cdisc.org/std/adam-2-1#>
## prefix adamig-1-0: <http://rdf.cdisc.org/std/adamig-1-0#>
## prefix adamvr-1-2: <http://rdf.cdisc.org/std/adamvr-1-2#>
## prefix qb: <http://purl.org/linked-data/cube#>
## prefix rrdfqbcrnd0: <http://www.example.org/rrdfqbcrnd0/>
## prefix code: <http://www.example.org/dc/code/>
## prefix dccs: <http://www.example.org/dc/example/dccs/>
## prefix ds: <http://www.example.org/dc/example/ds/>
## prefix crnd-dimension: <http://www.example.org/dc/dimension#>
## prefix crnd-attribute: <http://www.example.org/dc/attribute#>
## prefix crnd-measure: <http://www.example.org/dc/measure#>
## 
## select * where {
##      ?s a qb:Observation  ;
##      qb:dataSet ds:dataset-EXAMPLE  ;
##      crnd-dimension:factor ?factor;
##      crnd-dimension:procedure ?procedure;
##      crnd-dimension:category ?category;
##      crnd-measure:measure      ?measure ;
##      optional{ ?factor skos:prefLabel ?factorvalue . }
##      optional{ ?procedure skos:prefLabel ?procedurevalue . }
##      optional{ ?category skos:prefLabel ?categoryvalue . }
## }
```

And finally the observations, which is expected be the same as the starting data set.

```r
cube.observations<- as.data.frame(sparql.rdf(cube, cube.observations.rq ), stringsAsFactors=FALSE)
knitr::kable(cube.observations[,c(paste0(sub("crnd-dimension:|crnd-attribute:|crnd-measure:", "", cube.dimensionsattr), "value"),"measure")])
```



|factorvalue |procedurevalue |categoryvalue |measure |
|:-----------|:--------------|:-------------|:-------|
|NA          |NA             |NA            |123     |
|NA          |NA             |NA            |456     |

# Evaluating RDF data cube integrity constraints 

The cube conformance with the integrity constraints can be checked
using the RunQbIC function. The integrity checks are SPARQL queries
are stored in the list qbIClist.  The checks uses the RDF data cube
vocabulary. Therefore the RDF model must contain the RDF data cube
vocabulary.


```r
cubeVocabularyFn<- system.file("extdata/cube-vocabulary-rdf","cube.ttl", package="rrdfqb")
cubeVocabulary<- load.rdf(cubeVocabularyFn,format="TURTLE")
cubeData<- combine.rdf( cubeVocabulary, cube)
```

Note, this is not very interesting, as the cube is small.
The evaluation of the integrity contraints takes a while.

```r
icres<- RunQbIC( cubeData, forsparqlprefix )
```

```
## Executing IC-1.  Unique DataSet
```

```
##  -- 0 rows returned (0 is pass, >0 fail)
```

```
## Executing IC-2. Unique DSD
```

```
##  -- 0 rows returned (0 is pass, >0 fail)
```

```
## Executing IC-3. DSD includes measure
```

```
##  -- 0 rows returned (0 is pass, >0 fail)
```

```
## Executing IC-4. Dimensions have range
```

```
##  -- 0 rows returned (0 is pass, >0 fail)
```

```
## Executing IC-5. Concept dimensions have code lists
```

```
##  -- 0 rows returned (0 is pass, >0 fail)
```

```
## Executing IC-6. Only attributes may be optional
```

```
##  -- 0 rows returned (0 is pass, >0 fail)
```

```
## Executing IC-7. Slice Keys must be declared
```

```
##  -- 0 rows returned (0 is pass, >0 fail)
```

```
## Executing IC-8. Slice Keys consistent with DSD
```

```
##  -- 0 rows returned (0 is pass, >0 fail)
```

```
## Executing IC-9. Unique slice structure
```

```
##  -- 0 rows returned (0 is pass, >0 fail)
```

```
## Executing IC-10. Slice dimensions complete
```

```
##  -- 0 rows returned (0 is pass, >0 fail)
```

```
## Executing IC-11. All dimensions required
```

```
##  -- 0 rows returned (0 is pass, >0 fail)
```

```
## Executing IC-12. No duplicate observations
```

```
##  -- 0 rows returned (0 is pass, >0 fail)
```

```
## Executing IC-13. Required attributes
```

```
##  -- 0 rows returned (0 is pass, >0 fail)
```

```
## Executing IC-14. All measures present
```

```
##  -- 0 rows returned (0 is pass, >0 fail)
```

```
## Executing IC-15. Measure dimension consistent
```

```
##  -- 0 rows returned (0 is pass, >0 fail)
```

```
## Executing IC-16. Single measure on measure dimension observation
```

```
##  -- 0 rows returned (0 is pass, >0 fail)
```

```
## Executing IC-17. All measures present in measures dimension cube
```

```
##  -- 0 rows returned (0 is pass, >0 fail)
```

```
## Executing IC-18. Consistent data set links
```

```
##  -- 0 rows returned (0 is pass, >0 fail)
```

```
## Executing IC-19a. Codes from code list
```

```
##  -- 6 rows returned (0 is pass, >0 fail)
```

```
## Executing IC-19b. Codes from code list
```

```
##  -- 0 rows returned (0 is pass, >0 fail)
```

```
## IC-20 and IC-21 are currently not implemented
```

```r
knitr::kable(icres)
```



|ictitle                                                | icfail|
|:------------------------------------------------------|------:|
|IC-1.  Unique DataSet                                  |      0|
|IC-2. Unique DSD                                       |      0|
|IC-3. DSD includes measure                             |      0|
|IC-4. Dimensions have range                            |      0|
|IC-5. Concept dimensions have code lists               |      0|
|IC-6. Only attributes may be optional                  |      0|
|IC-7. Slice Keys must be declared                      |      0|
|IC-8. Slice Keys consistent with DSD                   |      0|
|IC-9. Unique slice structure                           |      0|
|IC-10. Slice dimensions complete                       |      0|
|IC-11. All dimensions required                         |      0|
|IC-12. No duplicate observations                       |      0|
|IC-13. Required attributes                             |      0|
|IC-14. All measures present                            |      0|
|IC-15. Measure dimension consistent                    |      0|
|IC-16. Single measure on measure dimension observation |      0|
|IC-17. All measures present in measures dimension cube |      0|
|IC-18. Consistent data set links                       |      0|
|IC-19a. Codes from code list                           |      6|
|IC-19b. Codes from code list                           |      0|

Here we remove one of the dimensions from the cube in observationo
ds:obs1. Note: for the remove.triple function the components must be
given as the full qualified URI. The expected result is that IC-11
fails.


```r
remove.triple(cubeData,
  subject="http://www.example.org/dc/example/ds/obs1",
  predicate="http://www.example.org/dc/dimension#category",
  object="http://www.example.org/dc/code/category-AA-group")
icres<- RunQbIC( cubeData, forsparqlprefix )
```

```
## Executing IC-1.  Unique DataSet
```

```
##  -- 0 rows returned (0 is pass, >0 fail)
```

```
## Executing IC-2. Unique DSD
```

```
##  -- 0 rows returned (0 is pass, >0 fail)
```

```
## Executing IC-3. DSD includes measure
```

```
##  -- 0 rows returned (0 is pass, >0 fail)
```

```
## Executing IC-4. Dimensions have range
```

```
##  -- 0 rows returned (0 is pass, >0 fail)
```

```
## Executing IC-5. Concept dimensions have code lists
```

```
##  -- 0 rows returned (0 is pass, >0 fail)
```

```
## Executing IC-6. Only attributes may be optional
```

```
##  -- 0 rows returned (0 is pass, >0 fail)
```

```
## Executing IC-7. Slice Keys must be declared
```

```
##  -- 0 rows returned (0 is pass, >0 fail)
```

```
## Executing IC-8. Slice Keys consistent with DSD
```

```
##  -- 0 rows returned (0 is pass, >0 fail)
```

```
## Executing IC-9. Unique slice structure
```

```
##  -- 0 rows returned (0 is pass, >0 fail)
```

```
## Executing IC-10. Slice dimensions complete
```

```
##  -- 0 rows returned (0 is pass, >0 fail)
```

```
## Executing IC-11. All dimensions required
```

```
##  -- 0 rows returned (0 is pass, >0 fail)
```

```
## Executing IC-12. No duplicate observations
```

```
##  -- 0 rows returned (0 is pass, >0 fail)
```

```
## Executing IC-13. Required attributes
```

```
##  -- 0 rows returned (0 is pass, >0 fail)
```

```
## Executing IC-14. All measures present
```

```
##  -- 0 rows returned (0 is pass, >0 fail)
```

```
## Executing IC-15. Measure dimension consistent
```

```
##  -- 0 rows returned (0 is pass, >0 fail)
```

```
## Executing IC-16. Single measure on measure dimension observation
```

```
##  -- 0 rows returned (0 is pass, >0 fail)
```

```
## Executing IC-17. All measures present in measures dimension cube
```

```
##  -- 0 rows returned (0 is pass, >0 fail)
```

```
## Executing IC-18. Consistent data set links
```

```
##  -- 0 rows returned (0 is pass, >0 fail)
```

```
## Executing IC-19a. Codes from code list
```

```
##  -- 6 rows returned (0 is pass, >0 fail)
```

```
## Executing IC-19b. Codes from code list
```

```
##  -- 0 rows returned (0 is pass, >0 fail)
```

```
## IC-20 and IC-21 are currently not implemented
```

```r
knitr::kable(icres)
```



|ictitle                                                | icfail|
|:------------------------------------------------------|------:|
|IC-1.  Unique DataSet                                  |      0|
|IC-2. Unique DSD                                       |      0|
|IC-3. DSD includes measure                             |      0|
|IC-4. Dimensions have range                            |      0|
|IC-5. Concept dimensions have code lists               |      0|
|IC-6. Only attributes may be optional                  |      0|
|IC-7. Slice Keys must be declared                      |      0|
|IC-8. Slice Keys consistent with DSD                   |      0|
|IC-9. Unique slice structure                           |      0|
|IC-10. Slice dimensions complete                       |      0|
|IC-11. All dimensions required                         |      0|
|IC-12. No duplicate observations                       |      0|
|IC-13. Required attributes                             |      0|
|IC-14. All measures present                            |      0|
|IC-15. Measure dimension consistent                    |      0|
|IC-16. Single measure on measure dimension observation |      0|
|IC-17. All measures present in measures dimension cube |      0|
|IC-18. Consistent data set links                       |      0|
|IC-19a. Codes from code list                           |      6|
|IC-19b. Codes from code list                           |      0|

IC-12 also fails; examining the SPARQL query shows why.


```r
cat(qbIClist[["ic-12"]]$rq,"\n")
```

```
## ASK {
##   FILTER( ?allEqual )
##   {
##     # For each pair of observations test if all the dimension values are the same
##     SELECT (MIN(?equal) AS ?allEqual) WHERE {
##         ?obs1 qb:dataSet ?dataset .
##         ?obs2 qb:dataSet ?dataset .
##         FILTER (?obs1 != ?obs2)
##         ?dataset qb:structure/qb:component/qb:componentProperty ?dim .
##         ?dim a qb:DimensionProperty .
##         ?obs1 ?dim ?value1 .
##         ?obs2 ?dim ?value2 .
##         BIND( ?value1 = ?value2 AS ?equal)
##     } GROUP BY ?obs1 ?obs2
##   }
## }
## 
```

As RRDF does not support the ASK query, the IC queries are changed 
to a SELECT query returning the number of triples selected.
