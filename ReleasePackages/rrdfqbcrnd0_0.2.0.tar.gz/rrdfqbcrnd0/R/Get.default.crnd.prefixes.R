##' Get list of default prefixes
##'
##' @return List with default prefixes
##' @export
Get.default.crnd.prefixes<- function( ) {
  env[["qbCDISCprefixes"]]
}
  
