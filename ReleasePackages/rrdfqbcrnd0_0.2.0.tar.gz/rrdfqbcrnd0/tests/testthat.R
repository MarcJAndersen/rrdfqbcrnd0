library(testthat)
library(rrdfqbcrnd0)

test_check("rrdfqbcrnd0")
