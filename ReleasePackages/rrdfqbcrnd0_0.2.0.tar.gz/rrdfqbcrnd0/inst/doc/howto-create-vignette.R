## ---- eval=FALSE---------------------------------------------------------
#  library(devtools)
#  devtools::load_all()
#  
#  library(knitr)
#  knit("vignettes/cube-from-workbook.Rmd")

## ---- eval=FALSE---------------------------------------------------------
#  knitr::knit2html("vignettes/qube-from-workbook.Rmd")

## ---- eval=FALSE---------------------------------------------------------
#  knitr::knit2pdf("vignettes/qube-from-workbook.Rmd")

