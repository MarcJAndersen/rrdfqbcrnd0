##' rrdfqbcrnd0.
##'
##' @name rrdfqbcrnd0
##' @docType package
## documentation for dataset - following ggplot2.r MJA 2014-11-16
NULL



##' Package locale environment
##'
##' @docType data
##' @name env
NULL

