---
title: "Execute SPARQL integrity constraints on a crnd data cube"
author: "mja@statgroup.dk"
date: "`r Sys.Date()`"
vignette: >
  %\VignetteIndexEntry{Execute SPARQL integrity constraints on a crnd data cube}
  %\VignetteEngine{knitr::rmarkdown}
  \usepackage[utf8]{inputenc}
---

```{r, results='asis', eval=TRUE}
library(rrdfqbcrnd0)

qbfile<- system.file("extdata/sample-rdf", "DC-DM-sample.ttl", package="rrdfqbcrndex")
cube<- load.rdf( qbfile, format="TURTLE")

dsdName<- GetDsdNameFromCube( cube )
domainName<- GetDomainNameFromCube( cube )
forsparqlprefix<- GetForSparqlPrefix( domainName )

cdisc.rdf<- Load.cdisc.standards()

cubeData<- combine.rdf( cube, cdisc.rdf)


```

rrdf does not implement the ASK query. As a work around the query is
transformed to a `SELECT (COUNT(*) ...)` or `SELECT *` gitquery.

```{r, results='asis', eval=TRUE}
str(cubeData)
for (icall in qbIClist) {
#  print(names(icall))
  if (! icall$HasInstantiation ) {
    icSelectRq<- gsub("ASK \\{", "SELECT \\* WHERE \\{", icall$rq)
    print( icall$ittitle)
    print( icSelectRq)
    cube.ic<- sparql.rdf(cubeData, paste( forsparqlprefix, icSelectRq  )  )
    cat(paste0(icall$ictitle, ": ", nrow(cube.ic), "\n"))
   }
}

```

Here is the same code but wrapped into a function

```{r, results='asis', eval=TRUE}
icres<- RunQbIC( cubeData, forsparqlprefix )
knitr::kable(icres)
```
