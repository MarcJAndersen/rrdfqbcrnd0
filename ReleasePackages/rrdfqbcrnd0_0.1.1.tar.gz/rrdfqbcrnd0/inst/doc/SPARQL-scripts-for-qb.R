## ----, eval=TRUE---------------------------------------------------------
library(rrdfqbcrnd0)

## ----helperfunction------------------------------------------------------
mdwrite<- function( sparqlStatements, refname ) {
fn<- file.path(tempdir(), paste0( refname, ".txt" ) )
cat( paste0("## @knitr ", refname), gsub("\\n", "  \n", sparql.rq), sep="  \n", file=fn)
knitr::read_chunk( fn, from=c(1))
invisible(fn)
}

## ----, eval=FALSE, echo=FALSE--------------------------------------------
#  knitr::knit("vignettes/SPARQL-scripts-for-qb.Rmd")
#  markdown::markdownToHTML("SPARQL-scripts-for-qb.md",output="SPARQL-scripts-for-qb.html")
#  
#  # makes very large file, and does not # at end of < >.
#  rmarkdown::render("vignettes/SPARQL-scripts-for-qb.Rmd", rmarkdown::html_document())
#  # the > at end of lines are shown as latex commands
#  rmarkdown::render("vignettes/SPARQL-scripts-for-qb.Rmd", rmarkdown::pdf_document())
#  

## ------------------------------------------------------------------------
forsparqlprefix<- GetForSparqlPrefix( "$myQbName" )
sparql.rq<- GetAttributesSparqlQuery( forsparqlprefix )
mdwrite( sparql.rq, "sp1" )

## ------------------------------------------------------------------------
forsparqlprefix<- GetForSparqlPrefix( "$myQbName" )
sparql.rq<- GetObservationsSparqlQuery( forsparqlprefix, "$myQbName", c("$dimA", "$dimB", "$dimC"), c("$attr1"))
mdwrite( sparql.rq, "sp2" )

## ----, eval=FALSE, echo=FALSE--------------------------------------------
#  db <- Rd_db("rrdfqbcrnd0")
#  keywords <- lapply(db, tools:::.Rd_get_metadata, "keyword")
#  db$qbIClist.Rd
#  tools:::RdTags(db$qbIClist.Rd)
#  titles <- lapply(db, tools:::.Rd_get_metadata, "title")
#  arguments <- lapply(db, tools:::.Rd_get_metadata, "arguments")
#  names <- lapply(db, tools:::.Rd_get_metadata, "name")
#  dofor<-grep("sparql",titles,ignore.case=TRUE)
#  cbind(titles[dofor],arguments[dofor])

