## ----setup0, include=FALSE,echo=FALSE------------------------------------
library(rrdfqbcrnd0)

## ----setup00, include=FALSE,echo=FALSE,eval=FALSE------------------------
#  knitr::knit("vignettes/SPARQL-scripts-for-qb.Rnw")

## ----results='asis'------------------------------------------------------
forsparqlprefix<- GetForSparqlPrefix( "$myQbName" )
sparql.rq<- GetAttributesSparqlQuery( forsparqlprefix )
cat("\\begin{lstlisting}[language=SPARQL]",gsub("#", "\\\\#", sparql.rq),"\\end{lstlisting}",sep="\n")

