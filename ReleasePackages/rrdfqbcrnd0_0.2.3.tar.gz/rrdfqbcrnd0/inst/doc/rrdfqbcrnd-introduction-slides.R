## ----setup, include=FALSE,echo=FALSE-------------------------------------
library(knitr)
opts_chunk$set(fig.path='figure/beamer-',fig.align='center',fig.show='hold',size='footnotesize')

