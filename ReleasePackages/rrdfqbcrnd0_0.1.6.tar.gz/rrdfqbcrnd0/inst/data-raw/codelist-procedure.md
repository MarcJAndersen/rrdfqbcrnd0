---
title: "Show the procedure codelist"
author: "PhuseSubTeamAnalysisResults@example.org"
date: "2015-07-27"
vignette: >
  %\VignetteIndexEntry{Show the procedure codelist}
  %\VignetteEngine{knitr::rmarkdown}
  \usepackage[utf8]{inputenc}
---

## Introduction
This vignette shows
- the procedure codelist

# Setup

The next command is not needed if the package have been loaded throug devtools::load_all().

```r
library(rrdfqbcrnd0)
```

```
## Error in library(rrdfqbcrnd0): there is no package called 'rrdfqbcrnd0'
```

# Create RDF data cube
The RDF data cube will be created from two data.frames containing data and metadata.

## Define data
The data are defined as data frame, and the data frame is displayed.

```r
thisGetDescrStatProcedure<- GetDescrStatProcedure()
```

```
## Error in eval(expr, envir, enclos): could not find function "GetDescrStatProcedure"
```

```r
procedureName<- gsub( "code:procedure-", "", names(thisGetDescrStatProcedure))
```

```
## Error in gsub("code:procedure-", "", names(thisGetDescrStatProcedure)): object 'thisGetDescrStatProcedure' not found
```

```r
obsData<- data.frame(
  category=rep( "AA-group", length(procedureName)),
  procedure=procedureName,
  factor=rep( "VARA", length(procedureName)),
  unit=rep( "Not given", length(procedureName)),
  denominator=rep( " ", length(procedureName)),
  measure=seq(length(procedureName)),
  stringsAsFactors=FALSE  )
```

```
## Error in data.frame(category = rep("AA-group", length(procedureName)), : object 'procedureName' not found
```

```r
knitr::kable(obsData)
```

```
## Error in is.data.frame(x): object 'obsData' not found
```

## Define meta data
The metadata used for generating the RDF data cube are also defined as data frame and displayed.

```r
cubeMetadata<- data.frame(
  compType=c("dimension", "dimension", "dimension", "unit", "denominator", "measure", "metadata"),
  compName=c("category", "procedure", "factor", "attribute", "attribute", "measure", "domainName"),
  codeType=c("DATA", "DATA", "DATA", " ", " ", "<NA>","<NA>"),
  nciDomainValue=c(" "," "," "," ", " ", " "," "),
  compLabel=c("Category", "Statistical procedure", "Type of procedure", "Result", "Unit", "Denominator", "EXAMPLE"),
  Comment=c(" "," "," "," "," "," "," "),
  stringsAsFactors=FALSE  )
knitr::kable(cubeMetadata)
```



|compType    |compName   |codeType |nciDomainValue |compLabel             |Comment |
|:-----------|:----------|:--------|:--------------|:---------------------|:-------|
|dimension   |category   |DATA     |               |Category              |        |
|dimension   |procedure  |DATA     |               |Statistical procedure |        |
|dimension   |factor     |DATA     |               |Type of procedure     |        |
|unit        |attribute  |         |               |Result                |        |
|denominator |attribute  |         |               |Unit                  |        |
|measure     |measure    |<NA>     |               |Denominator           |        |
|metadata    |domainName |<NA>     |               |EXAMPLE               |        |

## Create RDF data cube

The RDF data cube for the data above is created using

```r
outcube<- BuildCubeFromDataFrames(cubeMetadata, obsData )
```

```
## Error in eval(expr, envir, enclos): could not find function "BuildCubeFromDataFrames"
```
This shows a simple use of the BuildCubeFromDataFrames function. 
The warning message from log4j can be ignored.

The RDF data cube is serialized in turtle format and stored as a text file in

```r
cat(normalizePath(outcube),"\n")
```

```
## Error in path.expand(path): object 'outcube' not found
```

# Query the cube using SPARQL

Now take a look at the generated cubes by loading the turle file.


```r
dataCubeFile<- outcube
```

```
## Error in eval(expr, envir, enclos): object 'outcube' not found
```

The rest of the code only depends on the value of dataCubeFile.
The code demonstrates the use of the rrdf library.


```r
cube <- new.rdf()  # Initialize
```

```
## Error in eval(expr, envir, enclos): could not find function "new.rdf"
```

```r
load.rdf(dataCubeFile, format="TURTLE", appendTo= cube)
```

```
## Error in eval(expr, envir, enclos): could not find function "load.rdf"
```

```r
summarize.rdf(cube)
```

```
## Error in eval(expr, envir, enclos): could not find function "summarize.rdf"
```

The next statements are needed for the current implementation of the cube, and may change in future versions.

```r
## TODO: reconsider the use of domain specific prefixes
dsdName<- GetDsdNameFromCube( cube )
```

```
## Error in eval(expr, envir, enclos): could not find function "GetDsdNameFromCube"
```

```r
domainName<- GetDomainNameFromCube( cube )
```

```
## Error in eval(expr, envir, enclos): could not find function "GetDomainNameFromCube"
```

```r
cat("dsdName ", dsdName, ", domainName ", domainName, "\n" )
```

```
## Error in cat("dsdName ", dsdName, ", domainName ", domainName, "\n"): object 'dsdName' not found
```

```r
forsparqlprefix<- GetForSparqlPrefix( domainName )
```

```
## Error in eval(expr, envir, enclos): could not find function "GetForSparqlPrefix"
```

```r
cat(forsparqlprefix,"\n")
```

```
## Error in cat(forsparqlprefix, "\n"): object 'forsparqlprefix' not found
```

The variable forsparqlprefix contains the prefix statements applicable
for the present data cube. The use of prefixes makes the SPARQL query
shorter, and more readable. The present version of the package defines
namespaces dccs: and ds: where the domainname is included.
TODO: Consider other approach for including the domainname, or use other concept.

## Codelist

The SPARQL query for codelists are shown in the next output.

```
## Error in eval(expr, envir, enclos): could not find function "GetCodeListSparqlQuery"
```

```
## Error in cat(codelists.rq): object 'codelists.rq' not found
```

Executing the SPARQL query gives the code list as a data frame.

```
## Error in as.data.frame(sparql.rdf(cube, codelists.rq), stringsAsFactors = FALSE): could not find function "sparql.rdf"
```

```
## Error in gsub("code:", "", cube.codelists$cl): object 'cube.codelists' not found
```

```
## Error in print(cube.codelists[, c("vn", "clc", "prefLabel")]): object 'cube.codelists' not found
```

## Procedure codelist


```
## Error in paste(forsparqlprefix, "\nselect ?s ?p ?o\nwhere { \n?s ?p ?o .\n?s a code:Procedure\n }    \n", : object 'forsparqlprefix' not found
```

```
## Error in cat(procedure.codelists.rq): object 'procedure.codelists.rq' not found
```

Executing the SPARQL query gives the code list as a data frame.

```
## Error in as.data.frame(sparql.rdf(cube, procedure.codelists.rq), stringsAsFactors = FALSE): could not find function "sparql.rdf"
```

```
## Error in print(cube.procedure.codelists): object 'cube.procedure.codelists' not found
```


```
## Error in paste(forsparqlprefix, "\nconstruct { ?s ?p ?o } \nwhere { \n{ ?s ?p ?o . ?s a code:Procedure. }\nunion\n{ ?s ?p ?o . values(?s) {(code:Procedure)} }\n }    \n", : object 'forsparqlprefix' not found
```

```
## Error in cat(construct.codelists.rq): object 'construct.codelists.rq' not found
```


```
## Error in eval(expr, envir, enclos): could not find function "construct.rdf"
```

```
## Error in eval(expr, envir, enclos): could not find function "save.rdf"
```

The RDF data cube is serialized in turtle format and stored as a text file in

```r
cat(normalizePath(outcodelist),"\n")
```

```
## Error in path.expand(path): object 'outcodelist' not found
```
