---
title: "Two dimensional representation of RDF data cube"
author: "PhuseSubTeamAnalysisResults@example.org"
date: "2016-01-16"
vignette: >
  %\VignetteIndexEntry{Two dimensional representation of RDF data cube}
  %\VignetteEngine{knitr::knitr}
  %\usepackage[utf8]{inputenc}
  %\SweaveUTF8
---

# Setup

First load the package.

```r
library(rrdf)
```

```
## Loading required package: rJava
```

```
## Loading required package: methods
```

```
## Loading required package: rrdflibs
```

```r
library(rrdfqb)
```

```
## Loading required package: xlsx
```

```
## Loading required package: xlsxjars
```

```
## Loading required package: RCurl
```

```
## Loading required package: bitops
```

```
## 
## Attaching package: 'RCurl'
```

```
## The following object is masked from 'package:rJava':
## 
##     clone
```

```r
library(rrdfqbcrnd0)
library(rrdfqbcrndex)
library(rrdfqbpresent)
```


# Current - 08-may-2015

The following code is under development. It creates HTML files
under extdata/sample-cfg showing a two dimensional representation
of the RDF data cube.

Here are some the features that are evaluated
- drag and drop of measure - could be used for creating a new table from existing
- store RDF as RDFa - could be used to embed the whole cube in the file; looks like it gets to big

Pending: including the rest of the cube into the
html. Consider if in each cell only the observation and measure should
be referenced and not all properties and objects for the observation.


## Using with RDFa

The function `MakeHTMLfromQb` is used to create the HTML file. When invoked with `useRDFa=TRUE` the generated HTML will contain RDFa markup.

The HTML includes green-turtle
(https://github.com/alexmilowski/green-turtle), jquery
(http://jquery.com/) and jqueryUI (http://jqueryui.com/).

In my setup I store the project under packages, and can symlink to the
files from the extdata/sample-cfg directory.

    cd extdata/sample-cfg
    ln -s ~/packages/green-turtle/build/RDFa.min.1.4.0.js 
    ln -s ~/packages/green-turtle/build/RDFaProcessor.min.1.4.0.js 
    ln -s ~/packages/jquery-2.1.3.min/jquery-2.1.3.min.js .
    ln -s ~/packages/jquery-ui-1.11.3.custom .



```r
MakeTable<- function( dataCubeFile, htmlfile, rowdim, coldim, idrow, idcol ) {
    store <- new.rdf()  # Initialize
    cat("Loading ", dataCubeFile, "\n")
    temp<-load.rdf(dataCubeFile, format="TURTLE", appendTo= store)
    summarize.rdf(store)
    dsdName<- GetDsdNameFromCube( store )
    domainName<- GetDomainNameFromCube( store )
    forsparqlprefix<- GetForSparqlPrefix( domainName )

    dimensions<- sparql.rdf(store, GetDimensionsSparqlQuery( forsparqlprefix ) )
    attributesDf<- sparql.rdf(store, GetAttributesSparqlQuery( forsparqlprefix ))

    outhtmlfile<- MakeHTMLfromQb( store, forsparqlprefix, dsdName, domainName,
                                 dimensions, rowdim, coldim, idrow, idcol,
                                 htmlfile, useRDFa=TRUE, compactDimColumns=FALSE)

    outhtmlfile
}
```

## Create AE html example


```r
dataCubeFile<- system.file("extdata/sample-rdf", "DC-AE-sample.ttl", package="rrdfqbcrndex")
htmlfile<- file.path(system.file("extdata/sample-html", package="rrdfqbpresent"), "DC-AE-sample.html")
rowdim<- c("crnd-attribute:rowno", "crnd-dimension:aesoc", "crnd-dimension:aedecod" )
coldim<- c("crnd-attribute:colno", "crnd-attribute:cellpartno", "crnd-dimension:trta",
           "crnd-dimension:factor", "crnd-dimension:procedure" )
# idrow is a function of rowdim; writing it directly is easier for now
idrow<-  c( "aesocvalue", "aedecodvalue" )
idcol<-  c( "crnd-dimension:trta" )
resHtmlFile<- MakeTable( dataCubeFile, htmlfile, rowdim, coldim, idrow, idcol )
```

```
## Loading  /home/ma/R/x86_64-redhat-linux-gnu-library/3.2/rrdfqbcrndex/extdata/sample-rdf/DC-AE-sample.ttl 
## [1] "Number of triples: 25292"
##   [1] "1"   "2"   "3"   "4"   "5"   "6"   "7"   "8"   "9"   "10"  "11" 
##  [12] "12"  "13"  "14"  "15"  "16"  "17"  "18"  "19"  "20"  "21"  "22" 
##  [23] "23"  "24"  "25"  "26"  "27"  "28"  "29"  "30"  "31"  "32"  "33" 
##  [34] "34"  "35"  "36"  "37"  "38"  "39"  "40"  "41"  "42"  "43"  "44" 
##  [45] "45"  "46"  "47"  "48"  "49"  "50"  "51"  "52"  "53"  "54"  "55" 
##  [56] "56"  "57"  "58"  "59"  "60"  "61"  "62"  "63"  "64"  "65"  "66" 
##  [67] "67"  "68"  "69"  "70"  "71"  "72"  "73"  "74"  "75"  "76"  "77" 
##  [78] "78"  "79"  "80"  "81"  "82"  "83"  "84"  "85"  "86"  "87"  "88" 
##  [89] "89"  "90"  "91"  "92"  "93"  "94"  "95"  "96"  "97"  "98"  "99" 
## [100] "100" "101" "102" "103" "104" "105" "106" "107" "108" "109" "110"
## [111] "111" "112" "113" "114" "115" "116" "117" "118" "119" "120" "121"
## [122] "122" "123" "124" "125" "126" "127" "128" "129" "130" "131" "132"
## [133] "133" "134" "135" "136" "137" "138" "139" "140" "141" "142" "143"
## [144] "144" "145" "146" "147" "148" "149" "150" "151" "152" "153" "154"
## [155] "155" "156" "157" "158" "159" "160" "161" "162" "163" "164" "165"
## [166] "166" "167" "168" "169" "170" "171" "172" "173" "174" "175" "176"
## [177] "177" "178" "179" "180" "181" "182" "183" "184" "185" "186" "187"
## [188] "188" "189" "190" "191" "192" "193" "194" "195" "196" "197" "198"
## [199] "199" "200" "201" "202" "203" "204" "205" "206" "207" "208" "209"
## [210] "210" "211" "212" "213" "214" "215" "216" "217" "218" "219" "220"
## [221] "221" "222" "223" "224" "225" "226" "227" "228" "229" "230" "231"
## [232] "232" "233" "234" "235" "236" "237" "238" "239" "240" "241" "242"
## [243] "243" "244" "245" "246" "247" "248" "249" "250" "251" "252" "253"
## [254] "254" "255" "256" "257" "258" "259" "260" "261" "262" "263" "264"
## [265] "265" "266"
## [1] "1" "2" "3" "4"
## [1] "1" "2"
##               s rowno colno cellpartno
## 1    ds:obs0001     1     1          1
## 2    ds:obs0001     1     1          1
## 3    ds:obs0001     1     1          1
## 4    ds:obs0001     1     1          1
## 5    ds:obs0002     1     1          2
## 6    ds:obs0002     1     1          2
## 7    ds:obs0002     1     1          2
## 8    ds:obs0002     1     1          2
## 9    ds:obs0281     1     2          1
## 10   ds:obs0281     1     2          1
## 11   ds:obs0281     1     2          1
## 12   ds:obs0281     1     2          1
## 13   ds:obs0282     1     2          2
## 14   ds:obs0282     1     2          2
## 15   ds:obs0282     1     2          2
## 16   ds:obs0282     1     2          2
## 17   ds:obs0585     1     3          1
## 18   ds:obs0585     1     3          1
## 19   ds:obs0585     1     3          1
## 20   ds:obs0585     1     3          1
## 21   ds:obs0586     1     3          2
## 22   ds:obs0586     1     3          2
## 23   ds:obs0586     1     3          2
## 24   ds:obs0586     1     3          2
## 25   ds:obs0875     1     4          1
## 26   ds:obs0875     1     4          1
## 27   ds:obs0875     1     4          1
## 28   ds:obs0875     1     4          1
## 29   ds:obs0875     1     4          1
## 30   ds:obs0875     1     4          1
## 31   ds:obs0875     1     4          1
## 32   ds:obs0875     1     4          1
## 33   ds:obs0876     1     4          2
## 34   ds:obs0876     1     4          2
## 35   ds:obs0876     1     4          2
## 36   ds:obs0876     1     4          2
## 37   ds:obs0876     1     4          2
## 38   ds:obs0876     1     4          2
## 39   ds:obs0876     1     4          2
## 40   ds:obs0876     1     4          2
## 1209 ds:obs0003     2     1          1
## 1210 ds:obs0003     2     1          1
## 1211 ds:obs0004     2     1          2
## 1212 ds:obs0004     2     1          2
## 1213 ds:obs0283     2     2          1
## 1214 ds:obs0283     2     2          1
## 1215 ds:obs0284     2     2          2
## 1216 ds:obs0284     2     2          2
## 1217 ds:obs0587     2     3          1
## 1218 ds:obs0587     2     3          1
## 1219 ds:obs0588     2     3          2
## 1220 ds:obs0588     2     3          2
## 1221 ds:obs0877     2     4          1
## 1222 ds:obs0877     2     4          1
## 1223 ds:obs0877     2     4          1
## 1224 ds:obs0877     2     4          1
## 1225 ds:obs0878     2     4          2
## 1226 ds:obs0878     2     4          2
## 1227 ds:obs0878     2     4          2
## 1228 ds:obs0878     2     4          2
## 2081 ds:obs0005     3     1          1
## 2082 ds:obs0006     3     1          2
## 2083 ds:obs0285     3     2          1
## 2084 ds:obs0286     3     2          2
## 2085 ds:obs0589     3     3          1
## 2086 ds:obs0590     3     3          2
## 2087 ds:obs0879     3     4          1
## 2088 ds:obs0879     3     4          1
## 2089 ds:obs0880     3     4          2
## 2090 ds:obs0880     3     4          2
## 2213 ds:obs0287     4     2          1
## 2214 ds:obs0288     4     2          2
## 2215 ds:obs0591     4     3          1
## 2216 ds:obs0592     4     3          2
## 2217 ds:obs0881     4     4          1
## 2218 ds:obs0881     4     4          1
## 2219 ds:obs0882     4     4          2
## 2220 ds:obs0882     4     4          2
## 2321 ds:obs0007     5     1          1
## 2322 ds:obs0008     5     1          2
## 2327 ds:obs0883     5     4          1
## 2328 ds:obs0883     5     4          1
## 2329 ds:obs0884     5     4          2
## 2330 ds:obs0884     5     4          2
## 2441 ds:obs0009     6     1          1
## 2442 ds:obs0010     6     1          2
## 2445 ds:obs0593     6     3          1
## 2446 ds:obs0594     6     3          2
## 2447 ds:obs0885     6     4          1
## 2448 ds:obs0885     6     4          1
## 2449 ds:obs0886     6     4          2
## 2450 ds:obs0886     6     4          2
## 2551 ds:obs0011     7     1          1
## 2552 ds:obs0012     7     1          2
## 2553 ds:obs0289     7     2          1
## 2554 ds:obs0290     7     2          2
## 2557 ds:obs0887     7     4          1
## 2558 ds:obs0887     7     4          1
## 2559 ds:obs0888     7     4          2
## 2560 ds:obs0888     7     4          2
## 2661 ds:obs0013     8     1          1
## 2662 ds:obs0014     8     1          2
## 2667 ds:obs0889     8     4          1
## 2668 ds:obs0889     8     4          1
## 2669 ds:obs0890     8     4          2
## 2670 ds:obs0890     8     4          2
## 2771 ds:obs0015     9     1          1
## 2772 ds:obs0016     9     1          2
## 2777 ds:obs0891     9     4          1
## 2778 ds:obs0891     9     4          1
## 2779 ds:obs0892     9     4          2
## 2780 ds:obs0892     9     4          2
## 41   ds:obs0017    10     1          1
## 42   ds:obs0018    10     1          2
## 45   ds:obs0595    10     3          1
## 46   ds:obs0596    10     3          2
## 47   ds:obs0893    10     4          1
## 48   ds:obs0893    10     4          1
## 49   ds:obs0894    10     4          2
## 50   ds:obs0894    10     4          2
## 153  ds:obs0291    11     2          1
## 154  ds:obs0292    11     2          2
## 157  ds:obs0895    11     4          1
## 158  ds:obs0895    11     4          1
## 159  ds:obs0896    11     4          2
## 160  ds:obs0896    11     4          2
## 271  ds:obs0019    12     1          1
## 272  ds:obs0020    12     1          2
## 277  ds:obs0897    12     4          1
## 278  ds:obs0897    12     4          1
## 279  ds:obs0898    12     4          2
## 280  ds:obs0898    12     4          2
## 391  ds:obs0021    13     1          1
## 392  ds:obs0022    13     1          2
## 393  ds:obs0293    13     2          1
## 394  ds:obs0294    13     2          2
## 395  ds:obs0597    13     3          1
## 396  ds:obs0598    13     3          2
## 397  ds:obs0899    13     4          1
## 398  ds:obs0899    13     4          1
## 399  ds:obs0900    13     4          2
## 400  ds:obs0900    13     4          2
## 505  ds:obs0599    14     3          1
## 506  ds:obs0600    14     3          2
## 507  ds:obs0901    14     4          1
## 508  ds:obs0901    14     4          1
## 509  ds:obs0902    14     4          2
## 510  ds:obs0902    14     4          2
## 621  ds:obs0023    15     1          1
## 622  ds:obs0024    15     1          2
## 627  ds:obs0903    15     4          1
## 628  ds:obs0903    15     4          1
## 629  ds:obs0904    15     4          2
## 630  ds:obs0904    15     4          2
## 741  ds:obs0025    16     1          1
## 742  ds:obs0026    16     1          2
## 743  ds:obs0295    16     2          1
## 744  ds:obs0296    16     2          2
## 745  ds:obs0601    16     3          1
## 746  ds:obs0602    16     3          2
## 747  ds:obs0905    16     4          1
## 748  ds:obs0905    16     4          1
## 749  ds:obs0906    16     4          2
## 750  ds:obs0906    16     4          2
## 869  ds:obs0027    17     1          1
## 870  ds:obs0028    17     1          2
## 871  ds:obs0297    17     2          1
## 872  ds:obs0298    17     2          2
## 873  ds:obs0603    17     3          1
## 874  ds:obs0604    17     3          2
## 875  ds:obs0907    17     4          1
## 876  ds:obs0907    17     4          1
## 877  ds:obs0908    17     4          2
## 878  ds:obs0908    17     4          2
## 983  ds:obs0605    18     3          1
## 984  ds:obs0606    18     3          2
## 985  ds:obs0909    18     4          1
## 986  ds:obs0909    18     4          1
## 987  ds:obs0910    18     4          2
## 988  ds:obs0910    18     4          2
## 1099 ds:obs0029    19     1          1
## 1100 ds:obs0030    19     1          2
## 1105 ds:obs0911    19     4          1
## 1106 ds:obs0911    19     4          1
## 1107 ds:obs0912    19     4          2
## 1108 ds:obs0912    19     4          2
## 1231 ds:obs0299    20     2          1
## 1232 ds:obs0300    20     2          2
## 1233 ds:obs0607    20     3          1
## 1234 ds:obs0608    20     3          2
## 1235 ds:obs0913    20     4          1
## 1236 ds:obs0913    20     4          1
## 1237 ds:obs0914    20     4          2
## 1238 ds:obs0914    20     4          2
## 1349 ds:obs0031    21     1          1
## 1350 ds:obs0032    21     1          2
## 1355 ds:obs0915    21     4          1
## 1356 ds:obs0915    21     4          1
## 1357 ds:obs0916    21     4          2
## 1358 ds:obs0916    21     4          2
## 1481 ds:obs0609    22     3          1
## 1482 ds:obs0610    22     3          2
## 1483 ds:obs0917    22     4          1
## 1484 ds:obs0917    22     4          1
## 1485 ds:obs0918    22     4          2
## 1486 ds:obs0918    22     4          2
## 1589 ds:obs0301    23     2          1
## 1590 ds:obs0301    23     2          1
## 1591 ds:obs0302    23     2          2
## 1592 ds:obs0302    23     2          2
## 1593 ds:obs0611    23     3          1
## 1594 ds:obs0611    23     3          1
## 1595 ds:obs0612    23     3          2
## 1596 ds:obs0612    23     3          2
## 1597 ds:obs0919    23     4          1
## 1598 ds:obs0919    23     4          1
## 1599 ds:obs0919    23     4          1
## 1600 ds:obs0919    23     4          1
## 1601 ds:obs0920    23     4          2
## 1602 ds:obs0920    23     4          2
## 1603 ds:obs0920    23     4          2
## 1604 ds:obs0920    23     4          2
## 1717 ds:obs0303    24     2          1
## 1718 ds:obs0304    24     2          2
## 1719 ds:obs0613    24     3          1
## 1720 ds:obs0614    24     3          2
## 1721 ds:obs0921    24     4          1
## 1722 ds:obs0921    24     4          1
## 1723 ds:obs0922    24     4          2
## 1724 ds:obs0922    24     4          2
## 1825 ds:obs0033    25     1          1
## 1826 ds:obs0033    25     1          1
## 1827 ds:obs0034    25     1          2
## 1828 ds:obs0034    25     1          2
## 1829 ds:obs0305    25     2          1
## 1830 ds:obs0305    25     2          1
## 1831 ds:obs0306    25     2          2
## 1832 ds:obs0306    25     2          2
## 1833 ds:obs0615    25     3          1
## 1834 ds:obs0615    25     3          1
## 1835 ds:obs0616    25     3          2
## 1836 ds:obs0616    25     3          2
## 1837 ds:obs0923    25     4          1
## 1838 ds:obs0923    25     4          1
## 1839 ds:obs0923    25     4          1
## 1840 ds:obs0923    25     4          1
## 1841 ds:obs0924    25     4          2
## 1842 ds:obs0924    25     4          2
## 1843 ds:obs0924    25     4          2
## 1844 ds:obs0924    25     4          2
## 1965 ds:obs0617    26     3          1
## 1966 ds:obs0618    26     3          2
## 1967 ds:obs0925    26     4          1
## 1968 ds:obs0925    26     4          1
## 1969 ds:obs0926    26     4          2
## 1970 ds:obs0926    26     4          2
## 2051 ds:obs0035    27     1          1
## 2052 ds:obs0036    27     1          2
## 2057 ds:obs0927    27     4          1
## 2058 ds:obs0927    27     4          1
## 2059 ds:obs0928    27     4          2
## 2060 ds:obs0928    27     4          2
## 2065 ds:obs0619    28     3          1
## 2066 ds:obs0620    28     3          2
## 2067 ds:obs0929    28     4          1
## 2068 ds:obs0929    28     4          1
## 2069 ds:obs0930    28     4          2
## 2070 ds:obs0930    28     4          2
## 2073 ds:obs0307    29     2          1
## 2074 ds:obs0308    29     2          2
## 2075 ds:obs0621    29     3          1
## 2076 ds:obs0622    29     3          2
## 2077 ds:obs0931    29     4          1
## 2078 ds:obs0931    29     4          1
## 2079 ds:obs0932    29     4          2
## 2080 ds:obs0932    29     4          2
## 2091 ds:obs0037    30     1          1
## 2092 ds:obs0037    30     1          1
## 2093 ds:obs0038    30     1          2
## 2094 ds:obs0038    30     1          2
## 2095 ds:obs0309    30     2          1
## 2096 ds:obs0309    30     2          1
## 2097 ds:obs0310    30     2          2
## 2098 ds:obs0310    30     2          2
## 2099 ds:obs0623    30     3          1
## 2100 ds:obs0623    30     3          1
## 2101 ds:obs0624    30     3          2
## 2102 ds:obs0624    30     3          2
## 2103 ds:obs0933    30     4          1
## 2104 ds:obs0933    30     4          1
## 2105 ds:obs0933    30     4          1
## 2106 ds:obs0933    30     4          1
## 2107 ds:obs0934    30     4          2
## 2108 ds:obs0934    30     4          2
## 2109 ds:obs0934    30     4          2
## 2110 ds:obs0934    30     4          2
## 2115 ds:obs0625    31     3          1
## 2116 ds:obs0626    31     3          2
## 2117 ds:obs0935    31     4          1
## 2118 ds:obs0935    31     4          1
## 2119 ds:obs0936    31     4          2
## 2120 ds:obs0936    31     4          2
## 2121 ds:obs0039    32     1          1
## 2122 ds:obs0040    32     1          2
## 2127 ds:obs0937    32     4          1
## 2128 ds:obs0937    32     4          1
## 2129 ds:obs0938    32     4          2
## 2130 ds:obs0938    32     4          2
## 2131 ds:obs0041    33     1          1
## 2132 ds:obs0042    33     1          2
## 2137 ds:obs0939    33     4          1
## 2138 ds:obs0939    33     4          1
## 2139 ds:obs0940    33     4          2
## 2140 ds:obs0940    33     4          2
## 2141 ds:obs0043    34     1          1
## 2142 ds:obs0044    34     1          2
## 2147 ds:obs0941    34     4          1
## 2148 ds:obs0941    34     4          1
## 2149 ds:obs0942    34     4          2
## 2150 ds:obs0942    34     4          2
## 2151 ds:obs0045    35     1          1
## 2152 ds:obs0046    35     1          2
## 2157 ds:obs0943    35     4          1
## 2158 ds:obs0943    35     4          1
## 2159 ds:obs0944    35     4          2
## 2160 ds:obs0944    35     4          2
## 2161 ds:obs0047    36     1          1
## 2162 ds:obs0048    36     1          2
## 2167 ds:obs0945    36     4          1
## 2168 ds:obs0945    36     4          1
## 2169 ds:obs0946    36     4          2
## 2170 ds:obs0946    36     4          2
## 2173 ds:obs0311    37     2          1
## 2174 ds:obs0312    37     2          2
## 2175 ds:obs0627    37     3          1
## 2176 ds:obs0628    37     3          2
## 2177 ds:obs0947    37     4          1
## 2178 ds:obs0947    37     4          1
## 2179 ds:obs0948    37     4          2
## 2180 ds:obs0948    37     4          2
## 2181 ds:obs0049    38     1          1
## 2182 ds:obs0049    38     1          1
## 2183 ds:obs0050    38     1          2
## 2184 ds:obs0050    38     1          2
## 2185 ds:obs0313    38     2          1
## 2186 ds:obs0313    38     2          1
## 2187 ds:obs0314    38     2          2
## 2188 ds:obs0314    38     2          2
## 2189 ds:obs0629    38     3          1
## 2190 ds:obs0629    38     3          1
## 2191 ds:obs0630    38     3          2
## 2192 ds:obs0630    38     3          2
## 2193 ds:obs0949    38     4          1
## 2194 ds:obs0949    38     4          1
## 2195 ds:obs0949    38     4          1
## 2196 ds:obs0949    38     4          1
## 2197 ds:obs0950    38     4          2
## 2198 ds:obs0950    38     4          2
## 2199 ds:obs0950    38     4          2
## 2200 ds:obs0950    38     4          2
## 2203 ds:obs0315    39     2          1
## 2204 ds:obs0316    39     2          2
## 2207 ds:obs0951    39     4          1
## 2208 ds:obs0951    39     4          1
## 2209 ds:obs0952    39     4          2
## 2210 ds:obs0952    39     4          2
## 2221 ds:obs0051    40     1          1
## 2222 ds:obs0052    40     1          2
## 2223 ds:obs0317    40     2          1
## 2224 ds:obs0318    40     2          2
## 2225 ds:obs0631    40     3          1
## 2226 ds:obs0632    40     3          2
## 2227 ds:obs0953    40     4          1
## 2228 ds:obs0953    40     4          1
## 2229 ds:obs0954    40     4          2
## 2230 ds:obs0954    40     4          2
## 2231 ds:obs0053    41     1          1
## 2232 ds:obs0054    41     1          2
## 2237 ds:obs0955    41     4          1
## 2238 ds:obs0955    41     4          1
## 2239 ds:obs0956    41     4          2
## 2240 ds:obs0956    41     4          2
## 2241 ds:obs0055    42     1          1
## 2242 ds:obs0056    42     1          2
## 2243 ds:obs0319    42     2          1
## 2244 ds:obs0320    42     2          2
## 2245 ds:obs0633    42     3          1
## 2246 ds:obs0634    42     3          2
## 2247 ds:obs0957    42     4          1
## 2248 ds:obs0957    42     4          1
## 2249 ds:obs0958    42     4          2
## 2250 ds:obs0958    42     4          2
## 2251 ds:obs0057    43     1          1
## 2252 ds:obs0058    43     1          2
## 2253 ds:obs0321    43     2          1
## 2254 ds:obs0322    43     2          2
## 2255 ds:obs0635    43     3          1
## 2256 ds:obs0636    43     3          2
## 2257 ds:obs0959    43     4          1
## 2258 ds:obs0959    43     4          1
## 2259 ds:obs0960    43     4          2
## 2260 ds:obs0960    43     4          2
## 2265 ds:obs0637    44     3          1
## 2266 ds:obs0638    44     3          2
## 2267 ds:obs0961    44     4          1
## 2268 ds:obs0961    44     4          1
## 2269 ds:obs0962    44     4          2
## 2270 ds:obs0962    44     4          2
## 2271 ds:obs0059    45     1          1
## 2272 ds:obs0060    45     1          2
## 2277 ds:obs0963    45     4          1
## 2278 ds:obs0963    45     4          1
## 2279 ds:obs0964    45     4          2
## 2280 ds:obs0964    45     4          2
## 2283 ds:obs0323    46     2          1
## 2284 ds:obs0324    46     2          2
## 2287 ds:obs0965    46     4          1
## 2288 ds:obs0965    46     4          1
## 2289 ds:obs0966    46     4          2
## 2290 ds:obs0966    46     4          2
## 2291 ds:obs0061    47     1          1
## 2292 ds:obs0062    47     1          2
## 2297 ds:obs0967    47     4          1
## 2298 ds:obs0967    47     4          1
## 2299 ds:obs0968    47     4          2
## 2300 ds:obs0968    47     4          2
## 2301 ds:obs0063    48     1          1
## 2302 ds:obs0064    48     1          2
## 2307 ds:obs0969    48     4          1
## 2308 ds:obs0969    48     4          1
## 2309 ds:obs0970    48     4          2
## 2310 ds:obs0970    48     4          2
## 2311 ds:obs0065    49     1          1
## 2312 ds:obs0066    49     1          2
## 2317 ds:obs0971    49     4          1
## 2318 ds:obs0971    49     4          1
## 2319 ds:obs0972    49     4          2
## 2320 ds:obs0972    49     4          2
## 2331 ds:obs0067    50     1          1
## 2332 ds:obs0068    50     1          2
## 2333 ds:obs0325    50     2          1
## 2334 ds:obs0326    50     2          2
## 2335 ds:obs0639    50     3          1
## 2336 ds:obs0640    50     3          2
## 2337 ds:obs0973    50     4          1
## 2338 ds:obs0973    50     4          1
## 2339 ds:obs0974    50     4          2
## 2340 ds:obs0974    50     4          2
## 2345 ds:obs0641    51     3          1
## 2346 ds:obs0642    51     3          2
## 2347 ds:obs0975    51     4          1
## 2348 ds:obs0975    51     4          1
## 2349 ds:obs0976    51     4          2
## 2350 ds:obs0976    51     4          2
## 2353 ds:obs0327    52     2          1
## 2354 ds:obs0328    52     2          2
## 2357 ds:obs0977    52     4          1
## 2358 ds:obs0977    52     4          1
## 2359 ds:obs0978    52     4          2
## 2360 ds:obs0978    52     4          2
## 2363 ds:obs0329    53     2          1
## 2364 ds:obs0330    53     2          2
## 2367 ds:obs0979    53     4          1
## 2368 ds:obs0979    53     4          1
## 2369 ds:obs0980    53     4          2
## 2370 ds:obs0980    53     4          2
## 2371 ds:obs0069    54     1          1
## 2372 ds:obs0070    54     1          2
## 2373 ds:obs0331    54     2          1
## 2374 ds:obs0332    54     2          2
## 2375 ds:obs0643    54     3          1
## 2376 ds:obs0644    54     3          2
## 2377 ds:obs0981    54     4          1
## 2378 ds:obs0981    54     4          1
## 2379 ds:obs0982    54     4          2
## 2380 ds:obs0982    54     4          2
## 2381 ds:obs0071    55     1          1
## 2382 ds:obs0071    55     1          1
## 2383 ds:obs0072    55     1          2
## 2384 ds:obs0072    55     1          2
## 2385 ds:obs0333    55     2          1
## 2386 ds:obs0333    55     2          1
## 2387 ds:obs0334    55     2          2
## 2388 ds:obs0334    55     2          2
## 2389 ds:obs0645    55     3          1
## 2390 ds:obs0645    55     3          1
## 2391 ds:obs0646    55     3          2
## 2392 ds:obs0646    55     3          2
## 2393 ds:obs0983    55     4          1
## 2394 ds:obs0983    55     4          1
## 2395 ds:obs0983    55     4          1
## 2396 ds:obs0983    55     4          1
## 2397 ds:obs0984    55     4          2
## 2398 ds:obs0984    55     4          2
## 2399 ds:obs0984    55     4          2
## 2400 ds:obs0984    55     4          2
## 2405 ds:obs0647    56     3          1
## 2406 ds:obs0648    56     3          2
## 2407 ds:obs0985    56     4          1
## 2408 ds:obs0985    56     4          1
## 2409 ds:obs0986    56     4          2
## 2410 ds:obs0986    56     4          2
## 2411 ds:obs0073    57     1          1
## 2412 ds:obs0074    57     1          2
## 2413 ds:obs0335    57     2          1
## 2414 ds:obs0336    57     2          2
## 2415 ds:obs0649    57     3          1
## 2416 ds:obs0650    57     3          2
## 2417 ds:obs0987    57     4          1
## 2418 ds:obs0987    57     4          1
## 2419 ds:obs0988    57     4          2
## 2420 ds:obs0988    57     4          2
## 2425 ds:obs0651    58     3          1
## 2426 ds:obs0652    58     3          2
## 2427 ds:obs0989    58     4          1
## 2428 ds:obs0989    58     4          1
## 2429 ds:obs0990    58     4          2
## 2430 ds:obs0990    58     4          2
## 2433 ds:obs0337    59     2          1
## 2434 ds:obs0338    59     2          2
## 2437 ds:obs0991    59     4          1
## 2438 ds:obs0991    59     4          1
## 2439 ds:obs0992    59     4          2
## 2440 ds:obs0992    59     4          2
## 2455 ds:obs0653    60     3          1
## 2456 ds:obs0654    60     3          2
## 2457 ds:obs0993    60     4          1
## 2458 ds:obs0993    60     4          1
## 2459 ds:obs0994    60     4          2
## 2460 ds:obs0994    60     4          2
## 2461 ds:obs0075    61     1          1
## 2462 ds:obs0076    61     1          2
## 2463 ds:obs0339    61     2          1
## 2464 ds:obs0340    61     2          2
## 2465 ds:obs0655    61     3          1
## 2466 ds:obs0656    61     3          2
## 2467 ds:obs0995    61     4          1
## 2468 ds:obs0995    61     4          1
## 2469 ds:obs0996    61     4          2
## 2470 ds:obs0996    61     4          2
## 2471 ds:obs0077    62     1          1
## 2472 ds:obs0078    62     1          2
## 2477 ds:obs0997    62     4          1
## 2478 ds:obs0997    62     4          1
## 2479 ds:obs0998    62     4          2
## 2480 ds:obs0998    62     4          2
## 2481 ds:obs0079    63     1          1
## 2482 ds:obs0080    63     1          2
## 2483 ds:obs0341    63     2          1
## 2484 ds:obs0342    63     2          2
## 2485 ds:obs0657    63     3          1
## 2486 ds:obs0658    63     3          2
## 2487 ds:obs0999    63     4          1
## 2488 ds:obs0999    63     4          1
## 2489 ds:obs1000    63     4          2
## 2490 ds:obs1000    63     4          2
## 2493 ds:obs0343    64     2          1
## 2494 ds:obs0344    64     2          2
## 2497 ds:obs1001    64     4          1
## 2498 ds:obs1001    64     4          1
## 2499 ds:obs1002    64     4          2
## 2500 ds:obs1002    64     4          2
## 2503 ds:obs0345    65     2          1
## 2504 ds:obs0346    65     2          2
## 2507 ds:obs1003    65     4          1
## 2508 ds:obs1003    65     4          1
## 2509 ds:obs1004    65     4          2
## 2510 ds:obs1004    65     4          2
## 2511 ds:obs0081    66     1          1
## 2512 ds:obs0082    66     1          2
## 2513 ds:obs0347    66     2          1
## 2514 ds:obs0348    66     2          2
## 2515 ds:obs0659    66     3          1
## 2516 ds:obs0660    66     3          2
## 2517 ds:obs1005    66     4          1
## 2518 ds:obs1005    66     4          1
## 2519 ds:obs1006    66     4          2
## 2520 ds:obs1006    66     4          2
## 2521 ds:obs0083    67     1          1
## 2522 ds:obs0084    67     1          2
## 2523 ds:obs0349    67     2          1
## 2524 ds:obs0350    67     2          2
## 2527 ds:obs1007    67     4          1
## 2528 ds:obs1007    67     4          1
## 2529 ds:obs1008    67     4          2
## 2530 ds:obs1008    67     4          2
## 2533 ds:obs0351    68     2          1
## 2534 ds:obs0352    68     2          2
## 2535 ds:obs0661    68     3          1
## 2536 ds:obs0662    68     3          2
## 2537 ds:obs1009    68     4          1
## 2538 ds:obs1009    68     4          1
## 2539 ds:obs1010    68     4          2
## 2540 ds:obs1010    68     4          2
## 2543 ds:obs0353    69     2          1
## 2544 ds:obs0354    69     2          2
## 2545 ds:obs0663    69     3          1
## 2546 ds:obs0664    69     3          2
## 2547 ds:obs1011    69     4          1
## 2548 ds:obs1011    69     4          1
## 2549 ds:obs1012    69     4          2
## 2550 ds:obs1012    69     4          2
## 2561 ds:obs0085    70     1          1
## 2562 ds:obs0086    70     1          2
## 2563 ds:obs0355    70     2          1
## 2564 ds:obs0356    70     2          2
## 2565 ds:obs0665    70     3          1
## 2566 ds:obs0666    70     3          2
## 2567 ds:obs1013    70     4          1
## 2568 ds:obs1013    70     4          1
## 2569 ds:obs1014    70     4          2
## 2570 ds:obs1014    70     4          2
## 2575 ds:obs0667    71     3          1
## 2576 ds:obs0668    71     3          2
## 2577 ds:obs1015    71     4          1
## 2578 ds:obs1015    71     4          1
## 2579 ds:obs1016    71     4          2
## 2580 ds:obs1016    71     4          2
## 2581 ds:obs0087    72     1          1
## 2582 ds:obs0088    72     1          2
## 2583 ds:obs0357    72     2          1
## 2584 ds:obs0358    72     2          2
## 2587 ds:obs1017    72     4          1
## 2588 ds:obs1017    72     4          1
## 2589 ds:obs1018    72     4          2
## 2590 ds:obs1018    72     4          2
## 2593 ds:obs0359    73     2          1
## 2594 ds:obs0360    73     2          2
## 2597 ds:obs1019    73     4          1
## 2598 ds:obs1019    73     4          1
## 2599 ds:obs1020    73     4          2
## 2600 ds:obs1020    73     4          2
## 2603 ds:obs0361    74     2          1
## 2604 ds:obs0362    74     2          2
## 2607 ds:obs1021    74     4          1
## 2608 ds:obs1021    74     4          1
## 2609 ds:obs1022    74     4          2
## 2610 ds:obs1022    74     4          2
## 2611 ds:obs0089    75     1          1
## 2612 ds:obs0090    75     1          2
## 2613 ds:obs0363    75     2          1
## 2614 ds:obs0364    75     2          2
## 2615 ds:obs0669    75     3          1
## 2616 ds:obs0670    75     3          2
## 2617 ds:obs1023    75     4          1
## 2618 ds:obs1023    75     4          1
## 2619 ds:obs1024    75     4          2
## 2620 ds:obs1024    75     4          2
## 2625 ds:obs0671    76     3          1
## 2626 ds:obs0672    76     3          2
## 2627 ds:obs1025    76     4          1
## 2628 ds:obs1025    76     4          1
## 2629 ds:obs1026    76     4          2
## 2630 ds:obs1026    76     4          2
## 2631 ds:obs0091    77     1          1
## 2632 ds:obs0092    77     1          2
## 2633 ds:obs0365    77     2          1
## 2634 ds:obs0366    77     2          2
## 2635 ds:obs0673    77     3          1
## 2636 ds:obs0674    77     3          2
## 2637 ds:obs1027    77     4          1
## 2638 ds:obs1027    77     4          1
## 2639 ds:obs1028    77     4          2
## 2640 ds:obs1028    77     4          2
## 2643 ds:obs0367    78     2          1
## 2644 ds:obs0368    78     2          2
## 2647 ds:obs1029    78     4          1
## 2648 ds:obs1029    78     4          1
## 2649 ds:obs1030    78     4          2
## 2650 ds:obs1030    78     4          2
## 2653 ds:obs0369    79     2          1
## 2654 ds:obs0370    79     2          2
## 2657 ds:obs1031    79     4          1
## 2658 ds:obs1031    79     4          1
## 2659 ds:obs1032    79     4          2
## 2660 ds:obs1032    79     4          2
## 2675 ds:obs0675    80     3          1
## 2676 ds:obs0676    80     3          2
## 2677 ds:obs1033    80     4          1
## 2678 ds:obs1033    80     4          1
## 2679 ds:obs1034    80     4          2
## 2680 ds:obs1034    80     4          2
## 2683 ds:obs0371    81     2          1
## 2684 ds:obs0372    81     2          2
## 2685 ds:obs0677    81     3          1
## 2686 ds:obs0678    81     3          2
## 2687 ds:obs1035    81     4          1
## 2688 ds:obs1035    81     4          1
## 2689 ds:obs1036    81     4          2
## 2690 ds:obs1036    81     4          2
## 2695 ds:obs0679    82     3          1
## 2696 ds:obs0680    82     3          2
## 2697 ds:obs1037    82     4          1
## 2698 ds:obs1037    82     4          1
## 2699 ds:obs1038    82     4          2
## 2700 ds:obs1038    82     4          2
## 2701 ds:obs0093    83     1          1
## 2702 ds:obs0094    83     1          2
## 2703 ds:obs0373    83     2          1
## 2704 ds:obs0374    83     2          2
## 2705 ds:obs0681    83     3          1
## 2706 ds:obs0682    83     3          2
## 2707 ds:obs1039    83     4          1
## 2708 ds:obs1039    83     4          1
## 2709 ds:obs1040    83     4          2
## 2710 ds:obs1040    83     4          2
## 2713 ds:obs0375    84     2          1
## 2714 ds:obs0376    84     2          2
## 2715 ds:obs0683    84     3          1
## 2716 ds:obs0684    84     3          2
## 2717 ds:obs1041    84     4          1
## 2718 ds:obs1041    84     4          1
## 2719 ds:obs1042    84     4          2
## 2720 ds:obs1042    84     4          2
## 2721 ds:obs0095    85     1          1
## 2722 ds:obs0096    85     1          2
## 2723 ds:obs0377    85     2          1
## 2724 ds:obs0378    85     2          2
## 2727 ds:obs1043    85     4          1
## 2728 ds:obs1043    85     4          1
## 2729 ds:obs1044    85     4          2
## 2730 ds:obs1044    85     4          2
## 2735 ds:obs0685    86     3          1
## 2736 ds:obs0686    86     3          2
## 2737 ds:obs1045    86     4          1
## 2738 ds:obs1045    86     4          1
## 2739 ds:obs1046    86     4          2
## 2740 ds:obs1046    86     4          2
## 2745 ds:obs0687    87     3          1
## 2746 ds:obs0688    87     3          2
## 2747 ds:obs1047    87     4          1
## 2748 ds:obs1047    87     4          1
## 2749 ds:obs1048    87     4          2
## 2750 ds:obs1048    87     4          2
## 2755 ds:obs0689    88     3          1
## 2756 ds:obs0690    88     3          2
## 2757 ds:obs1049    88     4          1
## 2758 ds:obs1049    88     4          1
## 2759 ds:obs1050    88     4          2
## 2760 ds:obs1050    88     4          2
## 2765 ds:obs0691    89     3          1
## 2766 ds:obs0692    89     3          2
## 2767 ds:obs1051    89     4          1
## 2768 ds:obs1051    89     4          1
## 2769 ds:obs1052    89     4          2
## 2770 ds:obs1052    89     4          2
## 2781 ds:obs0097    90     1          1
## 2782 ds:obs0097    90     1          1
## 2783 ds:obs0098    90     1          2
## 2784 ds:obs0098    90     1          2
## 2789 ds:obs1053    90     4          1
## 2790 ds:obs1053    90     4          1
## 2791 ds:obs1053    90     4          1
## 2792 ds:obs1053    90     4          1
## 2793 ds:obs1054    90     4          2
## 2794 ds:obs1054    90     4          2
## 2795 ds:obs1054    90     4          2
## 2796 ds:obs1054    90     4          2
## 2797 ds:obs0099    91     1          1
## 2798 ds:obs0100    91     1          2
## 2803 ds:obs1055    91     4          1
## 2804 ds:obs1055    91     4          1
## 2805 ds:obs1056    91     4          2
## 2806 ds:obs1056    91     4          2
## 2809 ds:obs0379    92     2          1
## 2810 ds:obs0379    92     2          1
## 2811 ds:obs0380    92     2          2
## 2812 ds:obs0380    92     2          2
## 2813 ds:obs0693    92     3          1
## 2814 ds:obs0693    92     3          1
## 2815 ds:obs0694    92     3          2
## 2816 ds:obs0694    92     3          2
## 2817 ds:obs1057    92     4          1
## 2818 ds:obs1057    92     4          1
## 2819 ds:obs1057    92     4          1
## 2820 ds:obs1057    92     4          1
## 2821 ds:obs1058    92     4          2
## 2822 ds:obs1058    92     4          2
## 2823 ds:obs1058    92     4          2
## 2824 ds:obs1058    92     4          2
## 2829 ds:obs0695    93     3          1
## 2830 ds:obs0696    93     3          2
## 2831 ds:obs1059    93     4          1
## 2832 ds:obs1059    93     4          1
## 2833 ds:obs1060    93     4          2
## 2834 ds:obs1060    93     4          2
## 2837 ds:obs0381    94     2          1
## 2838 ds:obs0382    94     2          2
## 2841 ds:obs1061    94     4          1
## 2842 ds:obs1061    94     4          1
## 2843 ds:obs1062    94     4          2
## 2844 ds:obs1062    94     4          2
## 2845 ds:obs0101    95     1          1
## 2846 ds:obs0101    95     1          1
## 2847 ds:obs0102    95     1          2
## 2848 ds:obs0102    95     1          2
## 2849 ds:obs0383    95     2          1
## 2850 ds:obs0383    95     2          1
## 2851 ds:obs0384    95     2          2
## 2852 ds:obs0384    95     2          2
## 2853 ds:obs0697    95     3          1
## 2854 ds:obs0697    95     3          1
## 2855 ds:obs0698    95     3          2
## 2856 ds:obs0698    95     3          2
## 2857 ds:obs1063    95     4          1
## 2858 ds:obs1063    95     4          1
## 2859 ds:obs1063    95     4          1
## 2860 ds:obs1063    95     4          1
## 2861 ds:obs1064    95     4          2
## 2862 ds:obs1064    95     4          2
## 2863 ds:obs1064    95     4          2
## 2864 ds:obs1064    95     4          2
## 2865 ds:obs0103    96     1          1
## 2866 ds:obs0104    96     1          2
## 2871 ds:obs1065    96     4          1
## 2872 ds:obs1065    96     4          1
## 2873 ds:obs1066    96     4          2
## 2874 ds:obs1066    96     4          2
## 2879 ds:obs0699    97     3          1
## 2880 ds:obs0700    97     3          2
## 2881 ds:obs1067    97     4          1
## 2882 ds:obs1067    97     4          1
## 2883 ds:obs1068    97     4          2
## 2884 ds:obs1068    97     4          2
## 2885 ds:obs0105    98     1          1
## 2886 ds:obs0106    98     1          2
## 2891 ds:obs1069    98     4          1
## 2892 ds:obs1069    98     4          1
## 2893 ds:obs1070    98     4          2
## 2894 ds:obs1070    98     4          2
## 2895 ds:obs0107    99     1          1
## 2896 ds:obs0108    99     1          2
## 2897 ds:obs0385    99     2          1
## 2898 ds:obs0386    99     2          2
## 2901 ds:obs1071    99     4          1
## 2902 ds:obs1071    99     4          1
## 2903 ds:obs1072    99     4          2
## 2904 ds:obs1072    99     4          2
## 51   ds:obs0109   100     1          1
## 52   ds:obs0110   100     1          2
## 57   ds:obs1073   100     4          1
## 58   ds:obs1073   100     4          1
## 59   ds:obs1074   100     4          2
## 60   ds:obs1074   100     4          2
## 61   ds:obs0111   101     1          1
## 62   ds:obs0112   101     1          2
## 67   ds:obs1075   101     4          1
## 68   ds:obs1075   101     4          1
## 69   ds:obs1076   101     4          2
## 70   ds:obs1076   101     4          2
## 73   ds:obs0387   102     2          1
## 74   ds:obs0388   102     2          2
## 77   ds:obs1077   102     4          1
## 78   ds:obs1077   102     4          1
## 79   ds:obs1078   102     4          2
## 80   ds:obs1078   102     4          2
## 81   ds:obs0113   103     1          1
## 82   ds:obs0114   103     1          2
## 83   ds:obs0389   103     2          1
## 84   ds:obs0390   103     2          2
## 85   ds:obs0701   103     3          1
## 86   ds:obs0702   103     3          2
## 87   ds:obs1079   103     4          1
## 88   ds:obs1079   103     4          1
## 89   ds:obs1080   103     4          2
## 90   ds:obs1080   103     4          2
## 91   ds:obs0115   104     1          1
## 92   ds:obs0116   104     1          2
## 95   ds:obs0703   104     3          1
## 96   ds:obs0704   104     3          2
## 97   ds:obs1081   104     4          1
## 98   ds:obs1081   104     4          1
## 99   ds:obs1082   104     4          2
## 100  ds:obs1082   104     4          2
## 103  ds:obs0391   105     2          1
## 104  ds:obs0392   105     2          2
## 107  ds:obs1083   105     4          1
## 108  ds:obs1083   105     4          1
## 109  ds:obs1084   105     4          2
## 110  ds:obs1084   105     4          2
## 111  ds:obs0117   106     1          1
## 112  ds:obs0118   106     1          2
## 113  ds:obs0393   106     2          1
## 114  ds:obs0394   106     2          2
## 115  ds:obs0705   106     3          1
## 116  ds:obs0706   106     3          2
## 117  ds:obs1085   106     4          1
## 118  ds:obs1085   106     4          1
## 119  ds:obs1086   106     4          2
## 120  ds:obs1086   106     4          2
## 125  ds:obs0707   107     3          1
## 126  ds:obs0708   107     3          2
## 127  ds:obs1087   107     4          1
## 128  ds:obs1087   107     4          1
## 129  ds:obs1088   107     4          2
## 130  ds:obs1088   107     4          2
## 135  ds:obs0709   108     3          1
## 136  ds:obs0710   108     3          2
## 137  ds:obs1089   108     4          1
## 138  ds:obs1089   108     4          1
## 139  ds:obs1090   108     4          2
## 140  ds:obs1090   108     4          2
## 143  ds:obs0395   109     2          1
## 144  ds:obs0396   109     2          2
## 147  ds:obs1091   109     4          1
## 148  ds:obs1091   109     4          1
## 149  ds:obs1092   109     4          2
## 150  ds:obs1092   109     4          2
## 161  ds:obs0119   110     1          1
## 162  ds:obs0120   110     1          2
## 163  ds:obs0397   110     2          1
## 164  ds:obs0398   110     2          2
## 165  ds:obs0711   110     3          1
## 166  ds:obs0712   110     3          2
## 167  ds:obs1093   110     4          1
## 168  ds:obs1093   110     4          1
## 169  ds:obs1094   110     4          2
## 170  ds:obs1094   110     4          2
## 171  ds:obs0121   111     1          1
## 172  ds:obs0122   111     1          2
## 173  ds:obs0399   111     2          1
## 174  ds:obs0400   111     2          2
## 177  ds:obs1095   111     4          1
## 178  ds:obs1095   111     4          1
## 179  ds:obs1096   111     4          2
## 180  ds:obs1096   111     4          2
## 181  ds:obs0123   112     1          1
## 182  ds:obs0124   112     1          2
## 187  ds:obs1097   112     4          1
## 188  ds:obs1097   112     4          1
## 189  ds:obs1098   112     4          2
## 190  ds:obs1098   112     4          2
## 195  ds:obs0713   113     3          1
## 196  ds:obs0714   113     3          2
## 197  ds:obs1099   113     4          1
## 198  ds:obs1099   113     4          1
## 199  ds:obs1100   113     4          2
## 200  ds:obs1100   113     4          2
## 201  ds:obs0125   114     1          1
## 202  ds:obs0125   114     1          1
## 203  ds:obs0126   114     1          2
## 204  ds:obs0126   114     1          2
## 205  ds:obs0401   114     2          1
## 206  ds:obs0401   114     2          1
## 207  ds:obs0402   114     2          2
## 208  ds:obs0402   114     2          2
## 209  ds:obs0715   114     3          1
## 210  ds:obs0715   114     3          1
## 211  ds:obs0716   114     3          2
## 212  ds:obs0716   114     3          2
## 213  ds:obs1101   114     4          1
## 214  ds:obs1101   114     4          1
## 215  ds:obs1101   114     4          1
## 216  ds:obs1101   114     4          1
## 217  ds:obs1102   114     4          2
## 218  ds:obs1102   114     4          2
## 219  ds:obs1102   114     4          2
## 220  ds:obs1102   114     4          2
## 221  ds:obs0127   115     1          1
## 222  ds:obs0128   115     1          2
## 223  ds:obs0403   115     2          1
## 224  ds:obs0404   115     2          2
## 225  ds:obs0717   115     3          1
## 226  ds:obs0718   115     3          2
## 227  ds:obs1103   115     4          1
## 228  ds:obs1103   115     4          1
## 229  ds:obs1104   115     4          2
## 230  ds:obs1104   115     4          2
## 231  ds:obs0129   116     1          1
## 232  ds:obs0130   116     1          2
## 233  ds:obs0405   116     2          1
## 234  ds:obs0406   116     2          2
## 235  ds:obs0719   116     3          1
## 236  ds:obs0720   116     3          2
## 237  ds:obs1105   116     4          1
## 238  ds:obs1105   116     4          1
## 239  ds:obs1106   116     4          2
## 240  ds:obs1106   116     4          2
## 243  ds:obs0407   117     2          1
## 244  ds:obs0408   117     2          2
## 247  ds:obs1107   117     4          1
## 248  ds:obs1107   117     4          1
## 249  ds:obs1108   117     4          2
## 250  ds:obs1108   117     4          2
## 251  ds:obs0131   118     1          1
## 252  ds:obs0132   118     1          2
## 253  ds:obs0409   118     2          1
## 254  ds:obs0410   118     2          2
## 255  ds:obs0721   118     3          1
## 256  ds:obs0722   118     3          2
## 257  ds:obs1109   118     4          1
## 258  ds:obs1109   118     4          1
## 259  ds:obs1110   118     4          2
## 260  ds:obs1110   118     4          2
## 261  ds:obs0133   119     1          1
## 262  ds:obs0134   119     1          2
## 263  ds:obs0411   119     2          1
## 264  ds:obs0412   119     2          2
## 267  ds:obs1111   119     4          1
## 268  ds:obs1111   119     4          1
## 269  ds:obs1112   119     4          2
## 270  ds:obs1112   119     4          2
## 285  ds:obs0723   120     3          1
## 286  ds:obs0724   120     3          2
## 287  ds:obs1113   120     4          1
## 288  ds:obs1113   120     4          1
## 289  ds:obs1114   120     4          2
## 290  ds:obs1114   120     4          2
## 291  ds:obs0135   121     1          1
## 292  ds:obs0136   121     1          2
## 295  ds:obs0725   121     3          1
## 296  ds:obs0726   121     3          2
## 297  ds:obs1115   121     4          1
## 298  ds:obs1115   121     4          1
## 299  ds:obs1116   121     4          2
## 300  ds:obs1116   121     4          2
## 305  ds:obs0727   122     3          1
## 306  ds:obs0728   122     3          2
## 307  ds:obs1117   122     4          1
## 308  ds:obs1117   122     4          1
## 309  ds:obs1118   122     4          2
## 310  ds:obs1118   122     4          2
## 311  ds:obs0137   123     1          1
## 312  ds:obs0137   123     1          1
## 313  ds:obs0138   123     1          2
## 314  ds:obs0138   123     1          2
## 315  ds:obs0413   123     2          1
## 316  ds:obs0413   123     2          1
## 317  ds:obs0414   123     2          2
## 318  ds:obs0414   123     2          2
## 319  ds:obs0729   123     3          1
## 320  ds:obs0729   123     3          1
## 321  ds:obs0730   123     3          2
## 322  ds:obs0730   123     3          2
## 323  ds:obs1119   123     4          1
## 324  ds:obs1119   123     4          1
## 325  ds:obs1119   123     4          1
## 326  ds:obs1119   123     4          1
## 327  ds:obs1120   123     4          2
## 328  ds:obs1120   123     4          2
## 329  ds:obs1120   123     4          2
## 330  ds:obs1120   123     4          2
## 333  ds:obs0415   124     2          1
## 334  ds:obs0416   124     2          2
## 337  ds:obs1121   124     4          1
## 338  ds:obs1121   124     4          1
## 339  ds:obs1122   124     4          2
## 340  ds:obs1122   124     4          2
## 343  ds:obs0417   125     2          1
## 344  ds:obs0418   125     2          2
## 347  ds:obs1123   125     4          1
## 348  ds:obs1123   125     4          1
## 349  ds:obs1124   125     4          2
## 350  ds:obs1124   125     4          2
## 351  ds:obs0139   126     1          1
## 352  ds:obs0140   126     1          2
## 357  ds:obs1125   126     4          1
## 358  ds:obs1125   126     4          1
## 359  ds:obs1126   126     4          2
## 360  ds:obs1126   126     4          2
## 363  ds:obs0419   127     2          1
## 364  ds:obs0420   127     2          2
## 367  ds:obs1127   127     4          1
## 368  ds:obs1127   127     4          1
## 369  ds:obs1128   127     4          2
## 370  ds:obs1128   127     4          2
## 371  ds:obs0141   128     1          1
## 372  ds:obs0142   128     1          2
## 377  ds:obs1129   128     4          1
## 378  ds:obs1129   128     4          1
## 379  ds:obs1130   128     4          2
## 380  ds:obs1130   128     4          2
## 383  ds:obs0421   129     2          1
## 384  ds:obs0422   129     2          2
## 385  ds:obs0731   129     3          1
## 386  ds:obs0732   129     3          2
## 387  ds:obs1131   129     4          1
## 388  ds:obs1131   129     4          1
## 389  ds:obs1132   129     4          2
## 390  ds:obs1132   129     4          2
## 401  ds:obs0143   130     1          1
## 402  ds:obs0144   130     1          2
## 407  ds:obs1133   130     4          1
## 408  ds:obs1133   130     4          1
## 409  ds:obs1134   130     4          2
## 410  ds:obs1134   130     4          2
## 415  ds:obs0733   131     3          1
## 416  ds:obs0734   131     3          2
## 417  ds:obs1135   131     4          1
## 418  ds:obs1135   131     4          1
## 419  ds:obs1136   131     4          2
## 420  ds:obs1136   131     4          2
## 421  ds:obs0145   132     1          1
## 422  ds:obs0146   132     1          2
## 427  ds:obs1137   132     4          1
## 428  ds:obs1137   132     4          1
## 429  ds:obs1138   132     4          2
## 430  ds:obs1138   132     4          2
## 431  ds:obs0147   133     1          1
## 432  ds:obs0148   133     1          2
## 435  ds:obs0735   133     3          1
## 436  ds:obs0736   133     3          2
## 437  ds:obs1139   133     4          1
## 438  ds:obs1139   133     4          1
## 439  ds:obs1140   133     4          2
## 440  ds:obs1140   133     4          2
## 441  ds:obs0149   134     1          1
## 442  ds:obs0150   134     1          2
## 445  ds:obs0737   134     3          1
## 446  ds:obs0738   134     3          2
## 447  ds:obs1141   134     4          1
## 448  ds:obs1141   134     4          1
## 449  ds:obs1142   134     4          2
## 450  ds:obs1142   134     4          2
## 451  ds:obs0151   135     1          1
## 452  ds:obs0152   135     1          2
## 453  ds:obs0423   135     2          1
## 454  ds:obs0424   135     2          2
## 455  ds:obs0739   135     3          1
## 456  ds:obs0740   135     3          2
## 457  ds:obs1143   135     4          1
## 458  ds:obs1143   135     4          1
## 459  ds:obs1144   135     4          2
## 460  ds:obs1144   135     4          2
## 461  ds:obs0153   136     1          1
## 462  ds:obs0154   136     1          2
## 467  ds:obs1145   136     4          1
## 468  ds:obs1145   136     4          1
## 469  ds:obs1146   136     4          2
## 470  ds:obs1146   136     4          2
## 471  ds:obs0155   137     1          1
## 472  ds:obs0156   137     1          2
## 477  ds:obs1147   137     4          1
## 478  ds:obs1147   137     4          1
## 479  ds:obs1148   137     4          2
## 480  ds:obs1148   137     4          2
## 485  ds:obs0741   138     3          1
## 486  ds:obs0742   138     3          2
## 487  ds:obs1149   138     4          1
## 488  ds:obs1149   138     4          1
## 489  ds:obs1150   138     4          2
## 490  ds:obs1150   138     4          2
## 495  ds:obs0743   139     3          1
## 496  ds:obs0744   139     3          2
## 497  ds:obs1151   139     4          1
## 498  ds:obs1151   139     4          1
## 499  ds:obs1152   139     4          2
## 500  ds:obs1152   139     4          2
## 515  ds:obs0745   140     3          1
## 516  ds:obs0746   140     3          2
## 517  ds:obs1153   140     4          1
## 518  ds:obs1153   140     4          1
## 519  ds:obs1154   140     4          2
## 520  ds:obs1154   140     4          2
## 523  ds:obs0425   141     2          1
## 524  ds:obs0426   141     2          2
## 527  ds:obs1155   141     4          1
## 528  ds:obs1155   141     4          1
## 529  ds:obs1156   141     4          2
## 530  ds:obs1156   141     4          2
## 535  ds:obs0747   142     3          1
## 536  ds:obs0748   142     3          2
## 537  ds:obs1157   142     4          1
## 538  ds:obs1157   142     4          1
## 539  ds:obs1158   142     4          2
## 540  ds:obs1158   142     4          2
## 541  ds:obs0157   143     1          1
## 542  ds:obs0157   143     1          1
## 543  ds:obs0158   143     1          2
## 544  ds:obs0158   143     1          2
## 545  ds:obs0427   143     2          1
## 546  ds:obs0427   143     2          1
## 547  ds:obs0428   143     2          2
## 548  ds:obs0428   143     2          2
## 549  ds:obs0749   143     3          1
## 550  ds:obs0749   143     3          1
## 551  ds:obs0750   143     3          2
## 552  ds:obs0750   143     3          2
## 553  ds:obs1159   143     4          1
## 554  ds:obs1159   143     4          1
## 555  ds:obs1159   143     4          1
## 556  ds:obs1159   143     4          1
## 557  ds:obs1160   143     4          2
## 558  ds:obs1160   143     4          2
## 559  ds:obs1160   143     4          2
## 560  ds:obs1160   143     4          2
## 561  ds:obs0159   144     1          1
## 562  ds:obs0160   144     1          2
## 563  ds:obs0429   144     2          1
## 564  ds:obs0430   144     2          2
## 567  ds:obs1161   144     4          1
## 568  ds:obs1161   144     4          1
## 569  ds:obs1162   144     4          2
## 570  ds:obs1162   144     4          2
## 571  ds:obs0161   145     1          1
## 572  ds:obs0162   145     1          2
## 577  ds:obs1163   145     4          1
## 578  ds:obs1163   145     4          1
## 579  ds:obs1164   145     4          2
## 580  ds:obs1164   145     4          2
## 581  ds:obs0163   146     1          1
## 582  ds:obs0164   146     1          2
## 587  ds:obs1165   146     4          1
## 588  ds:obs1165   146     4          1
## 589  ds:obs1166   146     4          2
## 590  ds:obs1166   146     4          2
## 591  ds:obs0165   147     1          1
## 592  ds:obs0166   147     1          2
## 595  ds:obs0751   147     3          1
## 596  ds:obs0752   147     3          2
## 597  ds:obs1167   147     4          1
## 598  ds:obs1167   147     4          1
## 599  ds:obs1168   147     4          2
## 600  ds:obs1168   147     4          2
## 603  ds:obs0431   148     2          1
## 604  ds:obs0432   148     2          2
## 607  ds:obs1169   148     4          1
## 608  ds:obs1169   148     4          1
## 609  ds:obs1170   148     4          2
## 610  ds:obs1170   148     4          2
## 611  ds:obs0167   149     1          1
## 612  ds:obs0168   149     1          2
## 617  ds:obs1171   149     4          1
## 618  ds:obs1171   149     4          1
## 619  ds:obs1172   149     4          2
## 620  ds:obs1172   149     4          2
## 631  ds:obs0169   150     1          1
## 632  ds:obs0170   150     1          2
## 633  ds:obs0433   150     2          1
## 634  ds:obs0434   150     2          2
## 637  ds:obs1173   150     4          1
## 638  ds:obs1173   150     4          1
## 639  ds:obs1174   150     4          2
## 640  ds:obs1174   150     4          2
## 641  ds:obs0171   151     1          1
## 642  ds:obs0171   151     1          1
## 643  ds:obs0172   151     1          2
## 644  ds:obs0172   151     1          2
## 645  ds:obs0435   151     2          1
## 646  ds:obs0435   151     2          1
## 647  ds:obs0436   151     2          2
## 648  ds:obs0436   151     2          2
## 649  ds:obs0753   151     3          1
## 650  ds:obs0753   151     3          1
## 651  ds:obs0754   151     3          2
## 652  ds:obs0754   151     3          2
## 653  ds:obs1175   151     4          1
## 654  ds:obs1175   151     4          1
## 655  ds:obs1175   151     4          1
## 656  ds:obs1175   151     4          1
## 657  ds:obs1176   151     4          2
## 658  ds:obs1176   151     4          2
## 659  ds:obs1176   151     4          2
## 660  ds:obs1176   151     4          2
## 661  ds:obs0173   152     1          1
## 662  ds:obs0174   152     1          2
## 663  ds:obs0437   152     2          1
## 664  ds:obs0438   152     2          2
## 665  ds:obs0755   152     3          1
## 666  ds:obs0756   152     3          2
## 667  ds:obs1177   152     4          1
## 668  ds:obs1177   152     4          1
## 669  ds:obs1178   152     4          2
## 670  ds:obs1178   152     4          2
## 671  ds:obs0175   153     1          1
## 672  ds:obs0176   153     1          2
## 673  ds:obs0439   153     2          1
## 674  ds:obs0440   153     2          2
## 677  ds:obs1179   153     4          1
## 678  ds:obs1179   153     4          1
## 679  ds:obs1180   153     4          2
## 680  ds:obs1180   153     4          2
## 681  ds:obs0177   154     1          1
## 682  ds:obs0178   154     1          2
## 683  ds:obs0441   154     2          1
## 684  ds:obs0442   154     2          2
## 685  ds:obs0757   154     3          1
## 686  ds:obs0758   154     3          2
## 687  ds:obs1181   154     4          1
## 688  ds:obs1181   154     4          1
## 689  ds:obs1182   154     4          2
## 690  ds:obs1182   154     4          2
## 693  ds:obs0443   155     2          1
## 694  ds:obs0444   155     2          2
## 697  ds:obs1183   155     4          1
## 698  ds:obs1183   155     4          1
## 699  ds:obs1184   155     4          2
## 700  ds:obs1184   155     4          2
## 703  ds:obs0445   156     2          1
## 704  ds:obs0446   156     2          2
## 705  ds:obs0759   156     3          1
## 706  ds:obs0760   156     3          2
## 707  ds:obs1185   156     4          1
## 708  ds:obs1185   156     4          1
## 709  ds:obs1186   156     4          2
## 710  ds:obs1186   156     4          2
## 715  ds:obs0761   157     3          1
## 716  ds:obs0762   157     3          2
## 717  ds:obs1187   157     4          1
## 718  ds:obs1187   157     4          1
## 719  ds:obs1188   157     4          2
## 720  ds:obs1188   157     4          2
## 723  ds:obs0447   158     2          1
## 724  ds:obs0448   158     2          2
## 727  ds:obs1189   158     4          1
## 728  ds:obs1189   158     4          1
## 729  ds:obs1190   158     4          2
## 730  ds:obs1190   158     4          2
## 731  ds:obs0179   159     1          1
## 732  ds:obs0180   159     1          2
## 737  ds:obs1191   159     4          1
## 738  ds:obs1191   159     4          1
## 739  ds:obs1192   159     4          2
## 740  ds:obs1192   159     4          2
## 751  ds:obs0181   160     1          1
## 752  ds:obs0182   160     1          2
## 755  ds:obs0763   160     3          1
## 756  ds:obs0764   160     3          2
## 757  ds:obs1193   160     4          1
## 758  ds:obs1193   160     4          1
## 759  ds:obs1194   160     4          2
## 760  ds:obs1194   160     4          2
## 763  ds:obs0449   161     2          1
## 764  ds:obs0449   161     2          1
## 765  ds:obs0450   161     2          2
## 766  ds:obs0450   161     2          2
## 767  ds:obs0765   161     3          1
## 768  ds:obs0765   161     3          1
## 769  ds:obs0766   161     3          2
## 770  ds:obs0766   161     3          2
## 771  ds:obs1195   161     4          1
## 772  ds:obs1195   161     4          1
## 773  ds:obs1195   161     4          1
## 774  ds:obs1195   161     4          1
## 775  ds:obs1196   161     4          2
## 776  ds:obs1196   161     4          2
## 777  ds:obs1196   161     4          2
## 778  ds:obs1196   161     4          2
## 783  ds:obs0767   162     3          1
## 784  ds:obs0768   162     3          2
## 785  ds:obs1197   162     4          1
## 786  ds:obs1197   162     4          1
## 787  ds:obs1198   162     4          2
## 788  ds:obs1198   162     4          2
## 793  ds:obs0769   163     3          1
## 794  ds:obs0770   163     3          2
## 795  ds:obs1199   163     4          1
## 796  ds:obs1199   163     4          1
## 797  ds:obs1200   163     4          2
## 798  ds:obs1200   163     4          2
## 801  ds:obs0451   164     2          1
## 802  ds:obs0452   164     2          2
## 805  ds:obs1201   164     4          1
## 806  ds:obs1201   164     4          1
## 807  ds:obs1202   164     4          2
## 808  ds:obs1202   164     4          2
## 809  ds:obs0183   165     1          1
## 810  ds:obs0183   165     1          1
## 811  ds:obs0184   165     1          2
## 812  ds:obs0184   165     1          2
## 813  ds:obs0453   165     2          1
## 814  ds:obs0453   165     2          1
## 815  ds:obs0454   165     2          2
## 816  ds:obs0454   165     2          2
## 817  ds:obs0771   165     3          1
## 818  ds:obs0771   165     3          1
## 819  ds:obs0772   165     3          2
## 820  ds:obs0772   165     3          2
## 821  ds:obs1203   165     4          1
## 822  ds:obs1203   165     4          1
## 823  ds:obs1203   165     4          1
## 824  ds:obs1203   165     4          1
## 825  ds:obs1204   165     4          2
## 826  ds:obs1204   165     4          2
## 827  ds:obs1204   165     4          2
## 828  ds:obs1204   165     4          2
## 831  ds:obs0455   166     2          1
## 832  ds:obs0456   166     2          2
## 835  ds:obs1205   166     4          1
## 836  ds:obs1205   166     4          1
## 837  ds:obs1206   166     4          2
## 838  ds:obs1206   166     4          2
## 843  ds:obs0773   167     3          1
## 844  ds:obs0774   167     3          2
## 845  ds:obs1207   167     4          1
## 846  ds:obs1207   167     4          1
## 847  ds:obs1208   167     4          2
## 848  ds:obs1208   167     4          2
## 851  ds:obs0457   168     2          1
## 852  ds:obs0458   168     2          2
## 855  ds:obs1209   168     4          1
## 856  ds:obs1209   168     4          1
## 857  ds:obs1210   168     4          2
## 858  ds:obs1210   168     4          2
## 861  ds:obs0459   169     2          1
## 862  ds:obs0460   169     2          2
## 865  ds:obs1211   169     4          1
## 866  ds:obs1211   169     4          1
## 867  ds:obs1212   169     4          2
## 868  ds:obs1212   169     4          2
## 883  ds:obs0775   170     3          1
## 884  ds:obs0776   170     3          2
## 885  ds:obs1213   170     4          1
## 886  ds:obs1213   170     4          1
## 887  ds:obs1214   170     4          2
## 888  ds:obs1214   170     4          2
## 893  ds:obs0777   171     3          1
## 894  ds:obs0778   171     3          2
## 895  ds:obs1215   171     4          1
## 896  ds:obs1215   171     4          1
## 897  ds:obs1216   171     4          2
## 898  ds:obs1216   171     4          2
## 899  ds:obs0185   172     1          1
## 900  ds:obs0186   172     1          2
## 901  ds:obs0461   172     2          1
## 902  ds:obs0462   172     2          2
## 903  ds:obs0779   172     3          1
## 904  ds:obs0780   172     3          2
## 905  ds:obs1217   172     4          1
## 906  ds:obs1217   172     4          1
## 907  ds:obs1218   172     4          2
## 908  ds:obs1218   172     4          2
## 909  ds:obs0187   173     1          1
## 910  ds:obs0188   173     1          2
## 911  ds:obs0463   173     2          1
## 912  ds:obs0464   173     2          2
## 913  ds:obs0781   173     3          1
## 914  ds:obs0782   173     3          2
## 915  ds:obs1219   173     4          1
## 916  ds:obs1219   173     4          1
## 917  ds:obs1220   173     4          2
## 918  ds:obs1220   173     4          2
## 923  ds:obs0783   174     3          1
## 924  ds:obs0784   174     3          2
## 925  ds:obs1221   174     4          1
## 926  ds:obs1221   174     4          1
## 927  ds:obs1222   174     4          2
## 928  ds:obs1222   174     4          2
## 931  ds:obs0465   175     2          1
## 932  ds:obs0466   175     2          2
## 935  ds:obs1223   175     4          1
## 936  ds:obs1223   175     4          1
## 937  ds:obs1224   175     4          2
## 938  ds:obs1224   175     4          2
## 941  ds:obs0467   176     2          1
## 942  ds:obs0468   176     2          2
## 943  ds:obs0785   176     3          1
## 944  ds:obs0786   176     3          2
## 945  ds:obs1225   176     4          1
## 946  ds:obs1225   176     4          1
## 947  ds:obs1226   176     4          2
## 948  ds:obs1226   176     4          2
## 951  ds:obs0469   177     2          1
## 952  ds:obs0470   177     2          2
## 955  ds:obs1227   177     4          1
## 956  ds:obs1227   177     4          1
## 957  ds:obs1228   177     4          2
## 958  ds:obs1228   177     4          2
## 963  ds:obs0787   178     3          1
## 964  ds:obs0788   178     3          2
## 965  ds:obs1229   178     4          1
## 966  ds:obs1229   178     4          1
## 967  ds:obs1230   178     4          2
## 968  ds:obs1230   178     4          2
## 969  ds:obs0189   179     1          1
## 970  ds:obs0190   179     1          2
## 975  ds:obs1231   179     4          1
## 976  ds:obs1231   179     4          1
## 977  ds:obs1232   179     4          2
## 978  ds:obs1232   179     4          2
## 991  ds:obs0471   180     2          1
## 992  ds:obs0472   180     2          2
## 995  ds:obs1233   180     4          1
## 996  ds:obs1233   180     4          1
## 997  ds:obs1234   180     4          2
## 998  ds:obs1234   180     4          2
## 1001 ds:obs0473   181     2          1
## 1002 ds:obs0474   181     2          2
## 1005 ds:obs1235   181     4          1
## 1006 ds:obs1235   181     4          1
## 1007 ds:obs1236   181     4          2
## 1008 ds:obs1236   181     4          2
## 1009 ds:obs0191   182     1          1
## 1010 ds:obs0192   182     1          2
## 1015 ds:obs1237   182     4          1
## 1016 ds:obs1237   182     4          1
## 1017 ds:obs1238   182     4          2
## 1018 ds:obs1238   182     4          2
## 1019 ds:obs0193   183     1          1
## 1020 ds:obs0194   183     1          2
## 1021 ds:obs0475   183     2          1
## 1022 ds:obs0476   183     2          2
## 1023 ds:obs0789   183     3          1
## 1024 ds:obs0790   183     3          2
## 1025 ds:obs1239   183     4          1
## 1026 ds:obs1239   183     4          1
## 1027 ds:obs1240   183     4          2
## 1028 ds:obs1240   183     4          2
## 1033 ds:obs0791   184     3          1
## 1034 ds:obs0792   184     3          2
## 1035 ds:obs1241   184     4          1
## 1036 ds:obs1241   184     4          1
## 1037 ds:obs1242   184     4          2
## 1038 ds:obs1242   184     4          2
## 1041 ds:obs0477   185     2          1
## 1042 ds:obs0478   185     2          2
## 1043 ds:obs0793   185     3          1
## 1044 ds:obs0794   185     3          2
## 1045 ds:obs1243   185     4          1
## 1046 ds:obs1243   185     4          1
## 1047 ds:obs1244   185     4          2
## 1048 ds:obs1244   185     4          2
## 1051 ds:obs0479   186     2          1
## 1052 ds:obs0480   186     2          2
## 1055 ds:obs1245   186     4          1
## 1056 ds:obs1245   186     4          1
## 1057 ds:obs1246   186     4          2
## 1058 ds:obs1246   186     4          2
## 1061 ds:obs0481   187     2          1
## 1062 ds:obs0482   187     2          2
## 1063 ds:obs0795   187     3          1
## 1064 ds:obs0796   187     3          2
## 1065 ds:obs1247   187     4          1
## 1066 ds:obs1247   187     4          1
## 1067 ds:obs1248   187     4          2
## 1068 ds:obs1248   187     4          2
## 1069 ds:obs0195   188     1          1
## 1070 ds:obs0195   188     1          1
## 1071 ds:obs0196   188     1          2
## 1072 ds:obs0196   188     1          2
## 1073 ds:obs0483   188     2          1
## 1074 ds:obs0483   188     2          1
## 1075 ds:obs0484   188     2          2
## 1076 ds:obs0484   188     2          2
## 1077 ds:obs0797   188     3          1
## 1078 ds:obs0797   188     3          1
## 1079 ds:obs0798   188     3          2
## 1080 ds:obs0798   188     3          2
## 1081 ds:obs1249   188     4          1
## 1082 ds:obs1249   188     4          1
## 1083 ds:obs1249   188     4          1
## 1084 ds:obs1249   188     4          1
## 1085 ds:obs1250   188     4          2
## 1086 ds:obs1250   188     4          2
## 1087 ds:obs1250   188     4          2
## 1088 ds:obs1250   188     4          2
## 1089 ds:obs0197   189     1          1
## 1090 ds:obs0198   189     1          2
## 1091 ds:obs0485   189     2          1
## 1092 ds:obs0486   189     2          2
## 1093 ds:obs0799   189     3          1
## 1094 ds:obs0800   189     3          2
## 1095 ds:obs1251   189     4          1
## 1096 ds:obs1251   189     4          1
## 1097 ds:obs1252   189     4          2
## 1098 ds:obs1252   189     4          2
## 1109 ds:obs0199   190     1          1
## 1110 ds:obs0200   190     1          2
## 1113 ds:obs0801   190     3          1
## 1114 ds:obs0802   190     3          2
## 1115 ds:obs1253   190     4          1
## 1116 ds:obs1253   190     4          1
## 1117 ds:obs1254   190     4          2
## 1118 ds:obs1254   190     4          2
## 1119 ds:obs0201   191     1          1
## 1120 ds:obs0202   191     1          2
## 1125 ds:obs1255   191     4          1
## 1126 ds:obs1255   191     4          1
## 1127 ds:obs1256   191     4          2
## 1128 ds:obs1256   191     4          2
## 1129 ds:obs0203   192     1          1
## 1130 ds:obs0204   192     1          2
## 1131 ds:obs0487   192     2          1
## 1132 ds:obs0488   192     2          2
## 1133 ds:obs0803   192     3          1
## 1134 ds:obs0804   192     3          2
## 1135 ds:obs1257   192     4          1
## 1136 ds:obs1257   192     4          1
## 1137 ds:obs1258   192     4          2
## 1138 ds:obs1258   192     4          2
## 1141 ds:obs0489   193     2          1
## 1142 ds:obs0490   193     2          2
## 1145 ds:obs1259   193     4          1
## 1146 ds:obs1259   193     4          1
## 1147 ds:obs1260   193     4          2
## 1148 ds:obs1260   193     4          2
## 1149 ds:obs0205   194     1          1
## 1150 ds:obs0206   194     1          2
## 1151 ds:obs0491   194     2          1
## 1152 ds:obs0492   194     2          2
## 1155 ds:obs1261   194     4          1
## 1156 ds:obs1261   194     4          1
## 1157 ds:obs1262   194     4          2
## 1158 ds:obs1262   194     4          2
## 1161 ds:obs0493   195     2          1
## 1162 ds:obs0494   195     2          2
## 1163 ds:obs0805   195     3          1
## 1164 ds:obs0806   195     3          2
## 1165 ds:obs1263   195     4          1
## 1166 ds:obs1263   195     4          1
## 1167 ds:obs1264   195     4          2
## 1168 ds:obs1264   195     4          2
## 1169 ds:obs0207   196     1          1
## 1170 ds:obs0208   196     1          2
## 1175 ds:obs1265   196     4          1
## 1176 ds:obs1265   196     4          1
## 1177 ds:obs1266   196     4          2
## 1178 ds:obs1266   196     4          2
## 1181 ds:obs0495   197     2          1
## 1182 ds:obs0496   197     2          2
## 1185 ds:obs1267   197     4          1
## 1186 ds:obs1267   197     4          1
## 1187 ds:obs1268   197     4          2
## 1188 ds:obs1268   197     4          2
## 1191 ds:obs0497   198     2          1
## 1192 ds:obs0498   198     2          2
## 1195 ds:obs1269   198     4          1
## 1196 ds:obs1269   198     4          1
## 1197 ds:obs1270   198     4          2
## 1198 ds:obs1270   198     4          2
## 1199 ds:obs0209   199     1          1
## 1200 ds:obs0210   199     1          2
## 1201 ds:obs0499   199     2          1
## 1202 ds:obs0500   199     2          2
## 1205 ds:obs1271   199     4          1
## 1206 ds:obs1271   199     4          1
## 1207 ds:obs1272   199     4          2
## 1208 ds:obs1272   199     4          2
## 1239 ds:obs0211   200     1          1
## 1240 ds:obs0212   200     1          2
## 1243 ds:obs0807   200     3          1
## 1244 ds:obs0808   200     3          2
## 1245 ds:obs1273   200     4          1
## 1246 ds:obs1273   200     4          1
## 1247 ds:obs1274   200     4          2
## 1248 ds:obs1274   200     4          2
## 1251 ds:obs0501   201     2          1
## 1252 ds:obs0502   201     2          2
## 1255 ds:obs1275   201     4          1
## 1256 ds:obs1275   201     4          1
## 1257 ds:obs1276   201     4          2
## 1258 ds:obs1276   201     4          2
## 1261 ds:obs0503   202     2          1
## 1262 ds:obs0504   202     2          2
## 1265 ds:obs1277   202     4          1
## 1266 ds:obs1277   202     4          1
## 1267 ds:obs1278   202     4          2
## 1268 ds:obs1278   202     4          2
## 1271 ds:obs0505   203     2          1
## 1272 ds:obs0506   203     2          2
## 1275 ds:obs1279   203     4          1
## 1276 ds:obs1279   203     4          1
## 1277 ds:obs1280   203     4          2
## 1278 ds:obs1280   203     4          2
## 1283 ds:obs0809   204     3          1
## 1284 ds:obs0810   204     3          2
## 1285 ds:obs1281   204     4          1
## 1286 ds:obs1281   204     4          1
## 1287 ds:obs1282   204     4          2
## 1288 ds:obs1282   204     4          2
## 1289 ds:obs0213   205     1          1
## 1290 ds:obs0213   205     1          1
## 1291 ds:obs0214   205     1          2
## 1292 ds:obs0214   205     1          2
## 1293 ds:obs0507   205     2          1
## 1294 ds:obs0507   205     2          1
## 1295 ds:obs0508   205     2          2
## 1296 ds:obs0508   205     2          2
## 1297 ds:obs0811   205     3          1
## 1298 ds:obs0811   205     3          1
## 1299 ds:obs0812   205     3          2
## 1300 ds:obs0812   205     3          2
## 1301 ds:obs1283   205     4          1
## 1302 ds:obs1283   205     4          1
## 1303 ds:obs1283   205     4          1
## 1304 ds:obs1283   205     4          1
## 1305 ds:obs1284   205     4          2
## 1306 ds:obs1284   205     4          2
## 1307 ds:obs1284   205     4          2
## 1308 ds:obs1284   205     4          2
## 1311 ds:obs0509   206     2          1
## 1312 ds:obs0510   206     2          2
## 1315 ds:obs1285   206     4          1
## 1316 ds:obs1285   206     4          1
## 1317 ds:obs1286   206     4          2
## 1318 ds:obs1286   206     4          2
## 1319 ds:obs0215   207     1          1
## 1320 ds:obs0216   207     1          2
## 1323 ds:obs0813   207     3          1
## 1324 ds:obs0814   207     3          2
## 1325 ds:obs1287   207     4          1
## 1326 ds:obs1287   207     4          1
## 1327 ds:obs1288   207     4          2
## 1328 ds:obs1288   207     4          2
## 1333 ds:obs0815   208     3          1
## 1334 ds:obs0816   208     3          2
## 1335 ds:obs1289   208     4          1
## 1336 ds:obs1289   208     4          1
## 1337 ds:obs1290   208     4          2
## 1338 ds:obs1290   208     4          2
## 1343 ds:obs0817   209     3          1
## 1344 ds:obs0818   209     3          2
## 1345 ds:obs1291   209     4          1
## 1346 ds:obs1291   209     4          1
## 1347 ds:obs1292   209     4          2
## 1348 ds:obs1292   209     4          2
## 1359 ds:obs0217   210     1          1
## 1360 ds:obs0218   210     1          2
## 1361 ds:obs0511   210     2          1
## 1362 ds:obs0512   210     2          2
## 1363 ds:obs0819   210     3          1
## 1364 ds:obs0820   210     3          2
## 1365 ds:obs1293   210     4          1
## 1366 ds:obs1293   210     4          1
## 1367 ds:obs1294   210     4          2
## 1368 ds:obs1294   210     4          2
## 1369 ds:obs0219   211     1          1
## 1370 ds:obs0220   211     1          2
## 1371 ds:obs0513   211     2          1
## 1372 ds:obs0514   211     2          2
## 1375 ds:obs1295   211     4          1
## 1376 ds:obs1295   211     4          1
## 1377 ds:obs1296   211     4          2
## 1378 ds:obs1296   211     4          2
## 1379 ds:obs0221   212     1          1
## 1380 ds:obs0222   212     1          2
## 1385 ds:obs1297   212     4          1
## 1386 ds:obs1297   212     4          1
## 1387 ds:obs1298   212     4          2
## 1388 ds:obs1298   212     4          2
## 1389 ds:obs0223   213     1          1
## 1390 ds:obs0223   213     1          1
## 1391 ds:obs0224   213     1          2
## 1392 ds:obs0224   213     1          2
## 1393 ds:obs0515   213     2          1
## 1394 ds:obs0515   213     2          1
## 1395 ds:obs0516   213     2          2
## 1396 ds:obs0516   213     2          2
## 1399 ds:obs1299   213     4          1
## 1400 ds:obs1299   213     4          1
## 1401 ds:obs1299   213     4          1
## 1402 ds:obs1299   213     4          1
## 1403 ds:obs1300   213     4          2
## 1404 ds:obs1300   213     4          2
## 1405 ds:obs1300   213     4          2
## 1406 ds:obs1300   213     4          2
## 1407 ds:obs0225   214     1          1
## 1408 ds:obs0226   214     1          2
## 1409 ds:obs0517   214     2          1
## 1410 ds:obs0518   214     2          2
## 1413 ds:obs1301   214     4          1
## 1414 ds:obs1301   214     4          1
## 1415 ds:obs1302   214     4          2
## 1416 ds:obs1302   214     4          2
## 1417 ds:obs0227   215     1          1
## 1418 ds:obs0228   215     1          2
## 1423 ds:obs1303   215     4          1
## 1424 ds:obs1303   215     4          1
## 1425 ds:obs1304   215     4          2
## 1426 ds:obs1304   215     4          2
## 1427 ds:obs0229   216     1          1
## 1428 ds:obs0229   216     1          1
## 1429 ds:obs0230   216     1          2
## 1430 ds:obs0230   216     1          2
## 1431 ds:obs0519   216     2          1
## 1432 ds:obs0519   216     2          1
## 1433 ds:obs0520   216     2          2
## 1434 ds:obs0520   216     2          2
## 1435 ds:obs0821   216     3          1
## 1436 ds:obs0821   216     3          1
## 1437 ds:obs0822   216     3          2
## 1438 ds:obs0822   216     3          2
## 1439 ds:obs1305   216     4          1
## 1440 ds:obs1305   216     4          1
## 1441 ds:obs1305   216     4          1
## 1442 ds:obs1305   216     4          1
## 1443 ds:obs1306   216     4          2
## 1444 ds:obs1306   216     4          2
## 1445 ds:obs1306   216     4          2
## 1446 ds:obs1306   216     4          2
## 1449 ds:obs0521   217     2          1
## 1450 ds:obs0522   217     2          2
## 1453 ds:obs1307   217     4          1
## 1454 ds:obs1307   217     4          1
## 1455 ds:obs1308   217     4          2
## 1456 ds:obs1308   217     4          2
## 1457 ds:obs0231   218     1          1
## 1458 ds:obs0232   218     1          2
## 1459 ds:obs0523   218     2          1
## 1460 ds:obs0524   218     2          2
## 1461 ds:obs0823   218     3          1
## 1462 ds:obs0824   218     3          2
## 1463 ds:obs1309   218     4          1
## 1464 ds:obs1309   218     4          1
## 1465 ds:obs1310   218     4          2
## 1466 ds:obs1310   218     4          2
## 1471 ds:obs0825   219     3          1
## 1472 ds:obs0826   219     3          2
## 1473 ds:obs1311   219     4          1
## 1474 ds:obs1311   219     4          1
## 1475 ds:obs1312   219     4          2
## 1476 ds:obs1312   219     4          2
## 1487 ds:obs0233   220     1          1
## 1488 ds:obs0234   220     1          2
## 1489 ds:obs0525   220     2          1
## 1490 ds:obs0526   220     2          2
## 1491 ds:obs0827   220     3          1
## 1492 ds:obs0828   220     3          2
## 1493 ds:obs1313   220     4          1
## 1494 ds:obs1313   220     4          1
## 1495 ds:obs1314   220     4          2
## 1496 ds:obs1314   220     4          2
## 1497 ds:obs0235   221     1          1
## 1498 ds:obs0236   221     1          2
## 1503 ds:obs1315   221     4          1
## 1504 ds:obs1315   221     4          1
## 1505 ds:obs1316   221     4          2
## 1506 ds:obs1316   221     4          2
## 1509 ds:obs0527   222     2          1
## 1510 ds:obs0528   222     2          2
## 1511 ds:obs0829   222     3          1
## 1512 ds:obs0830   222     3          2
## 1513 ds:obs1317   222     4          1
## 1514 ds:obs1317   222     4          1
## 1515 ds:obs1318   222     4          2
## 1516 ds:obs1318   222     4          2
## 1517 ds:obs0237   223     1          1
## 1518 ds:obs0238   223     1          2
## 1523 ds:obs1319   223     4          1
## 1524 ds:obs1319   223     4          1
## 1525 ds:obs1320   223     4          2
## 1526 ds:obs1320   223     4          2
## 1527 ds:obs0239   224     1          1
## 1528 ds:obs0240   224     1          2
## 1529 ds:obs0529   224     2          1
## 1530 ds:obs0530   224     2          2
## 1531 ds:obs0831   224     3          1
## 1532 ds:obs0832   224     3          2
## 1533 ds:obs1321   224     4          1
## 1534 ds:obs1321   224     4          1
## 1535 ds:obs1322   224     4          2
## 1536 ds:obs1322   224     4          2
## 1539 ds:obs0531   225     2          1
## 1540 ds:obs0532   225     2          2
## 1543 ds:obs1323   225     4          1
## 1544 ds:obs1323   225     4          1
## 1545 ds:obs1324   225     4          2
## 1546 ds:obs1324   225     4          2
## 1549 ds:obs0533   226     2          1
## 1550 ds:obs0534   226     2          2
## 1551 ds:obs0833   226     3          1
## 1552 ds:obs0834   226     3          2
## 1553 ds:obs1325   226     4          1
## 1554 ds:obs1325   226     4          1
## 1555 ds:obs1326   226     4          2
## 1556 ds:obs1326   226     4          2
## 1557 ds:obs0241   227     1          1
## 1558 ds:obs0242   227     1          2
## 1563 ds:obs1327   227     4          1
## 1564 ds:obs1327   227     4          1
## 1565 ds:obs1328   227     4          2
## 1566 ds:obs1328   227     4          2
## 1569 ds:obs0535   228     2          1
## 1570 ds:obs0536   228     2          2
## 1573 ds:obs1329   228     4          1
## 1574 ds:obs1329   228     4          1
## 1575 ds:obs1330   228     4          2
## 1576 ds:obs1330   228     4          2
## 1577 ds:obs0243   229     1          1
## 1578 ds:obs0244   229     1          2
## 1583 ds:obs1331   229     4          1
## 1584 ds:obs1331   229     4          1
## 1585 ds:obs1332   229     4          2
## 1586 ds:obs1332   229     4          2
## 1607 ds:obs0537   230     2          1
## 1608 ds:obs0538   230     2          2
## 1611 ds:obs1333   230     4          1
## 1612 ds:obs1333   230     4          1
## 1613 ds:obs1334   230     4          2
## 1614 ds:obs1334   230     4          2
## 1617 ds:obs0539   231     2          1
## 1618 ds:obs0540   231     2          2
## 1619 ds:obs0835   231     3          1
## 1620 ds:obs0836   231     3          2
## 1621 ds:obs1335   231     4          1
## 1622 ds:obs1335   231     4          1
## 1623 ds:obs1336   231     4          2
## 1624 ds:obs1336   231     4          2
## 1625 ds:obs0245   232     1          1
## 1626 ds:obs0245   232     1          1
## 1627 ds:obs0246   232     1          2
## 1628 ds:obs0246   232     1          2
## 1629 ds:obs0541   232     2          1
## 1630 ds:obs0541   232     2          1
## 1631 ds:obs0542   232     2          2
## 1632 ds:obs0542   232     2          2
## 1633 ds:obs0837   232     3          1
## 1634 ds:obs0837   232     3          1
## 1635 ds:obs0838   232     3          2
## 1636 ds:obs0838   232     3          2
## 1637 ds:obs1337   232     4          1
## 1638 ds:obs1337   232     4          1
## 1639 ds:obs1337   232     4          1
## 1640 ds:obs1337   232     4          1
## 1641 ds:obs1338   232     4          2
## 1642 ds:obs1338   232     4          2
## 1643 ds:obs1338   232     4          2
## 1644 ds:obs1338   232     4          2
## 1647 ds:obs0543   233     2          1
## 1648 ds:obs0544   233     2          2
## 1651 ds:obs1339   233     4          1
## 1652 ds:obs1339   233     4          1
## 1653 ds:obs1340   233     4          2
## 1654 ds:obs1340   233     4          2
## 1655 ds:obs0247   234     1          1
## 1656 ds:obs0248   234     1          2
## 1661 ds:obs1341   234     4          1
## 1662 ds:obs1341   234     4          1
## 1663 ds:obs1342   234     4          2
## 1664 ds:obs1342   234     4          2
## 1667 ds:obs0545   235     2          1
## 1668 ds:obs0546   235     2          2
## 1669 ds:obs0839   235     3          1
## 1670 ds:obs0840   235     3          2
## 1671 ds:obs1343   235     4          1
## 1672 ds:obs1343   235     4          1
## 1673 ds:obs1344   235     4          2
## 1674 ds:obs1344   235     4          2
## 1675 ds:obs0249   236     1          1
## 1676 ds:obs0250   236     1          2
## 1681 ds:obs1345   236     4          1
## 1682 ds:obs1345   236     4          1
## 1683 ds:obs1346   236     4          2
## 1684 ds:obs1346   236     4          2
## 1685 ds:obs0251   237     1          1
## 1686 ds:obs0252   237     1          2
## 1691 ds:obs1347   237     4          1
## 1692 ds:obs1347   237     4          1
## 1693 ds:obs1348   237     4          2
## 1694 ds:obs1348   237     4          2
## 1699 ds:obs0841   238     3          1
## 1700 ds:obs0842   238     3          2
## 1701 ds:obs1349   238     4          1
## 1702 ds:obs1349   238     4          1
## 1703 ds:obs1350   238     4          2
## 1704 ds:obs1350   238     4          2
## 1705 ds:obs0253   239     1          1
## 1706 ds:obs0254   239     1          2
## 1711 ds:obs1351   239     4          1
## 1712 ds:obs1351   239     4          1
## 1713 ds:obs1352   239     4          2
## 1714 ds:obs1352   239     4          2
## 1725 ds:obs0255   240     1          1
## 1726 ds:obs0256   240     1          2
## 1727 ds:obs0547   240     2          1
## 1728 ds:obs0548   240     2          2
## 1729 ds:obs0843   240     3          1
## 1730 ds:obs0844   240     3          2
## 1731 ds:obs1353   240     4          1
## 1732 ds:obs1353   240     4          1
## 1733 ds:obs1354   240     4          2
## 1734 ds:obs1354   240     4          2
## 1735 ds:obs0257   241     1          1
## 1736 ds:obs0258   241     1          2
## 1737 ds:obs0549   241     2          1
## 1738 ds:obs0550   241     2          2
## 1739 ds:obs0845   241     3          1
## 1740 ds:obs0846   241     3          2
## 1741 ds:obs1355   241     4          1
## 1742 ds:obs1355   241     4          1
## 1743 ds:obs1356   241     4          2
## 1744 ds:obs1356   241     4          2
## 1745 ds:obs0259   242     1          1
## 1746 ds:obs0260   242     1          2
## 1747 ds:obs0551   242     2          1
## 1748 ds:obs0552   242     2          2
## 1749 ds:obs0847   242     3          1
## 1750 ds:obs0848   242     3          2
## 1751 ds:obs1357   242     4          1
## 1752 ds:obs1357   242     4          1
## 1753 ds:obs1358   242     4          2
## 1754 ds:obs1358   242     4          2
## 1757 ds:obs0553   243     2          1
## 1758 ds:obs0554   243     2          2
## 1759 ds:obs0849   243     3          1
## 1760 ds:obs0850   243     3          2
## 1761 ds:obs1359   243     4          1
## 1762 ds:obs1359   243     4          1
## 1763 ds:obs1360   243     4          2
## 1764 ds:obs1360   243     4          2
## 1765 ds:obs0261   244     1          1
## 1766 ds:obs0262   244     1          2
## 1767 ds:obs0555   244     2          1
## 1768 ds:obs0556   244     2          2
## 1769 ds:obs0851   244     3          1
## 1770 ds:obs0852   244     3          2
## 1771 ds:obs1361   244     4          1
## 1772 ds:obs1361   244     4          1
## 1773 ds:obs1362   244     4          2
## 1774 ds:obs1362   244     4          2
## 1779 ds:obs0853   245     3          1
## 1780 ds:obs0854   245     3          2
## 1781 ds:obs1363   245     4          1
## 1782 ds:obs1363   245     4          1
## 1783 ds:obs1364   245     4          2
## 1784 ds:obs1364   245     4          2
## 1787 ds:obs0557   246     2          1
## 1788 ds:obs0558   246     2          2
## 1791 ds:obs1365   246     4          1
## 1792 ds:obs1365   246     4          1
## 1793 ds:obs1366   246     4          2
## 1794 ds:obs1366   246     4          2
## 1797 ds:obs0559   247     2          1
## 1798 ds:obs0560   247     2          2
## 1801 ds:obs1367   247     4          1
## 1802 ds:obs1367   247     4          1
## 1803 ds:obs1368   247     4          2
## 1804 ds:obs1368   247     4          2
## 1807 ds:obs0561   248     2          1
## 1808 ds:obs0562   248     2          2
## 1809 ds:obs0855   248     3          1
## 1810 ds:obs0856   248     3          2
## 1811 ds:obs1369   248     4          1
## 1812 ds:obs1369   248     4          1
## 1813 ds:obs1370   248     4          2
## 1814 ds:obs1370   248     4          2
## 1819 ds:obs0857   249     3          1
## 1820 ds:obs0858   249     3          2
## 1821 ds:obs1371   249     4          1
## 1822 ds:obs1371   249     4          1
## 1823 ds:obs1372   249     4          2
## 1824 ds:obs1372   249     4          2
## 1845 ds:obs0263   250     1          1
## 1846 ds:obs0264   250     1          2
## 1847 ds:obs0563   250     2          1
## 1848 ds:obs0564   250     2          2
## 1849 ds:obs0859   250     3          1
## 1850 ds:obs0860   250     3          2
## 1851 ds:obs1373   250     4          1
## 1852 ds:obs1373   250     4          1
## 1853 ds:obs1374   250     4          2
## 1854 ds:obs1374   250     4          2
## 1857 ds:obs0565   251     2          1
## 1858 ds:obs0566   251     2          2
## 1861 ds:obs1375   251     4          1
## 1862 ds:obs1375   251     4          1
## 1863 ds:obs1376   251     4          2
## 1864 ds:obs1376   251     4          2
## 1865 ds:obs0265   252     1          1
## 1866 ds:obs0266   252     1          2
## 1871 ds:obs1377   252     4          1
## 1872 ds:obs1377   252     4          1
## 1873 ds:obs1378   252     4          2
## 1874 ds:obs1378   252     4          2
## 1877 ds:obs0567   253     2          1
## 1878 ds:obs0568   253     2          2
## 1879 ds:obs0861   253     3          1
## 1880 ds:obs0862   253     3          2
## 1881 ds:obs1379   253     4          1
## 1882 ds:obs1379   253     4          1
## 1883 ds:obs1380   253     4          2
## 1884 ds:obs1380   253     4          2
## 1887 ds:obs0569   254     2          1
## 1888 ds:obs0569   254     2          1
## 1889 ds:obs0570   254     2          2
## 1890 ds:obs0570   254     2          2
## 1893 ds:obs1381   254     4          1
## 1894 ds:obs1381   254     4          1
## 1895 ds:obs1381   254     4          1
## 1896 ds:obs1381   254     4          1
## 1897 ds:obs1382   254     4          2
## 1898 ds:obs1382   254     4          2
## 1899 ds:obs1382   254     4          2
## 1900 ds:obs1382   254     4          2
## 1903 ds:obs0571   255     2          1
## 1904 ds:obs0572   255     2          2
## 1907 ds:obs1383   255     4          1
## 1908 ds:obs1383   255     4          1
## 1909 ds:obs1384   255     4          2
## 1910 ds:obs1384   255     4          2
## 1911 ds:obs0267   256     1          1
## 1912 ds:obs0267   256     1          1
## 1913 ds:obs0268   256     1          2
## 1914 ds:obs0268   256     1          2
## 1915 ds:obs0573   256     2          1
## 1916 ds:obs0573   256     2          1
## 1917 ds:obs0574   256     2          2
## 1918 ds:obs0574   256     2          2
## 1919 ds:obs0863   256     3          1
## 1920 ds:obs0863   256     3          1
## 1921 ds:obs0864   256     3          2
## 1922 ds:obs0864   256     3          2
## 1923 ds:obs1385   256     4          1
## 1924 ds:obs1385   256     4          1
## 1925 ds:obs1385   256     4          1
## 1926 ds:obs1385   256     4          1
## 1927 ds:obs1386   256     4          2
## 1928 ds:obs1386   256     4          2
## 1929 ds:obs1386   256     4          2
## 1930 ds:obs1386   256     4          2
## 1933 ds:obs0575   257     2          1
## 1934 ds:obs0576   257     2          2
## 1937 ds:obs1387   257     4          1
## 1938 ds:obs1387   257     4          1
## 1939 ds:obs1388   257     4          2
## 1940 ds:obs1388   257     4          2
## 1941 ds:obs0269   258     1          1
## 1942 ds:obs0270   258     1          2
## 1945 ds:obs0865   258     3          1
## 1946 ds:obs0866   258     3          2
## 1947 ds:obs1389   258     4          1
## 1948 ds:obs1389   258     4          1
## 1949 ds:obs1390   258     4          2
## 1950 ds:obs1390   258     4          2
## 1951 ds:obs0271   259     1          1
## 1952 ds:obs0272   259     1          2
## 1957 ds:obs1391   259     4          1
## 1958 ds:obs1391   259     4          1
## 1959 ds:obs1392   259     4          2
## 1960 ds:obs1392   259     4          2
## 1973 ds:obs0577   260     2          1
## 1974 ds:obs0578   260     2          2
## 1977 ds:obs1393   260     4          1
## 1978 ds:obs1393   260     4          1
## 1979 ds:obs1394   260     4          2
## 1980 ds:obs1394   260     4          2
## 1981 ds:obs0273   261     1          1
## 1982 ds:obs0273   261     1          1
## 1983 ds:obs0274   261     1          2
## 1984 ds:obs0274   261     1          2
## 1985 ds:obs0579   261     2          1
## 1986 ds:obs0579   261     2          1
## 1987 ds:obs0580   261     2          2
## 1988 ds:obs0580   261     2          2
## 1989 ds:obs0867   261     3          1
## 1990 ds:obs0867   261     3          1
## 1991 ds:obs0868   261     3          2
## 1992 ds:obs0868   261     3          2
## 1993 ds:obs1395   261     4          1
## 1994 ds:obs1395   261     4          1
## 1995 ds:obs1395   261     4          1
## 1996 ds:obs1395   261     4          1
## 1997 ds:obs1396   261     4          2
## 1998 ds:obs1396   261     4          2
## 1999 ds:obs1396   261     4          2
## 2000 ds:obs1396   261     4          2
## 2005 ds:obs0869   262     3          1
## 2006 ds:obs0870   262     3          2
## 2007 ds:obs1397   262     4          1
## 2008 ds:obs1397   262     4          1
## 2009 ds:obs1398   262     4          2
## 2010 ds:obs1398   262     4          2
## 2011 ds:obs0275   263     1          1
## 2012 ds:obs0276   263     1          2
## 2013 ds:obs0581   263     2          1
## 2014 ds:obs0582   263     2          2
## 2015 ds:obs0871   263     3          1
## 2016 ds:obs0872   263     3          2
## 2017 ds:obs1399   263     4          1
## 2018 ds:obs1399   263     4          1
## 2019 ds:obs1400   263     4          2
## 2020 ds:obs1400   263     4          2
## 2021 ds:obs0277   264     1          1
## 2022 ds:obs0278   264     1          2
## 2025 ds:obs0873   264     3          1
## 2026 ds:obs0874   264     3          2
## 2027 ds:obs1401   264     4          1
## 2028 ds:obs1401   264     4          1
## 2029 ds:obs1402   264     4          2
## 2030 ds:obs1402   264     4          2
## 2031 ds:obs0279   265     1          1
## 2032 ds:obs0280   265     1          2
## 2037 ds:obs1403   265     4          1
## 2038 ds:obs1403   265     4          1
## 2039 ds:obs1404   265     4          2
## 2040 ds:obs1404   265     4          2
## 2043 ds:obs0583   266     2          1
## 2044 ds:obs0584   266     2          2
## 2047 ds:obs1405   266     4          1
## 2048 ds:obs1405   266     4          1
## 2049 ds:obs1406   266     4          2
## 2050 ds:obs1406   266     4          2
## Row  1 , observation (or)  1 , rowidname aesocvalue , contents:  _ALL_ 
## Row  1 , observation (or)  1 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  2 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  2 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  3 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  3 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  4 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  4 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  5 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  5 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  6 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  6 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  7 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  7 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  8 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  8 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  9 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  9 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  10 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  10 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  11 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  11 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  12 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  12 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  13 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  13 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  14 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  14 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  15 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  15 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  16 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  16 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  17 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  17 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  18 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  18 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  19 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  19 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  20 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  20 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  21 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  21 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  22 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  22 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  23 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  23 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  24 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  24 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  25 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  25 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  26 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  26 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  27 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  27 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  28 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  28 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  29 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  29 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  30 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  30 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  31 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  31 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  32 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  32 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  33 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  33 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  34 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  34 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  35 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  35 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  36 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  36 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  37 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  37 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  38 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  38 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  39 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  39 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  40 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  40 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  41 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  41 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  42 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  42 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  43 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  43 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  44 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  44 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  45 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  45 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  46 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  46 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  47 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  47 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  48 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  48 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  49 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  49 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  50 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  50 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  51 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  51 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  52 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  52 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  53 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  53 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  54 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  54 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  55 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  55 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  56 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  56 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  57 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  57 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  58 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  58 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  59 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  59 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  60 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  60 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  61 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  61 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  62 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  62 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  63 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  63 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  64 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  64 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  65 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  65 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  66 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  66 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  67 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  67 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  68 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  68 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  69 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  69 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  70 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  70 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  71 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  71 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  72 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  72 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  73 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  73 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  74 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  74 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  75 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  75 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  76 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  76 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  77 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  77 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  78 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  78 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  79 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  79 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  80 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  80 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  81 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  81 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  82 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  82 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  83 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  83 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  84 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  84 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  85 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  85 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  86 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  86 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  87 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  87 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  88 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  88 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  89 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  89 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  90 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  90 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  91 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  91 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  92 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  92 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  93 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  93 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  94 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  94 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  95 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  95 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  96 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  96 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  97 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  97 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  98 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  98 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  99 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  99 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  100 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  100 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  101 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  101 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  102 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  102 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  103 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  103 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  104 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  104 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  105 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  105 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  106 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  106 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  107 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  107 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  108 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  108 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  109 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  109 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  110 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  110 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  111 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  111 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  112 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  112 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  113 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  113 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  114 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  114 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  115 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  115 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  116 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  116 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  117 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  117 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  118 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  118 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  119 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  119 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  120 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  120 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  121 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  121 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  122 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  122 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  123 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  123 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  124 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  124 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  125 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  125 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  126 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  126 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  127 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  127 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  128 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  128 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  129 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  129 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  130 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  130 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  131 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  131 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  132 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  132 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  133 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  133 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  134 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  134 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  135 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  135 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  136 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  136 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  137 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  137 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  138 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  138 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  139 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  139 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  140 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  140 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  141 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  141 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  142 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  142 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  143 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  143 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  144 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  144 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  145 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  145 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  146 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  146 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  147 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  147 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  148 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  148 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  149 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  149 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  150 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  150 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  151 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  151 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  152 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  152 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  153 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  153 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  154 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  154 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  155 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  155 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  156 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  156 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  157 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  157 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  158 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  158 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  159 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  159 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  160 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  160 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  161 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  161 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  162 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  162 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  163 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  163 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  164 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  164 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  165 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  165 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  166 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  166 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  167 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  167 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  168 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  168 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  169 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  169 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  170 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  170 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  171 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  171 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  172 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  172 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  173 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  173 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  174 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  174 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  175 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  175 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  176 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  176 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  177 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  177 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  178 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  178 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  179 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  179 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  180 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  180 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  181 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  181 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  182 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  182 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  183 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  183 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  184 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  184 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  185 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  185 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  186 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  186 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  187 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  187 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  188 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  188 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  189 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  189 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  190 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  190 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  191 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  191 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  192 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  192 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  193 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  193 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  194 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  194 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  195 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  195 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  196 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  196 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  197 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  197 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  198 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  198 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  199 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  199 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  200 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  200 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  201 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  201 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  202 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  202 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  203 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  203 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  204 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  204 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  205 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  205 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  206 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  206 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  207 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  207 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  208 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  208 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  209 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  209 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  210 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  210 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  211 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  211 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  212 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  212 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  213 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  213 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  214 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  214 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  215 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  215 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  216 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  216 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  217 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  217 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  218 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  218 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  219 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  219 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  220 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  220 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  221 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  221 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  222 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  222 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  223 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  223 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  224 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  224 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  225 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  225 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  226 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  226 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  227 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  227 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  228 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  228 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  229 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  229 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  230 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  230 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  231 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  231 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  232 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  232 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  233 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  233 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  234 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  234 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  235 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  235 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  236 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  236 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  237 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  237 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  238 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  238 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  239 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  239 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  240 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  240 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  241 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  241 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  242 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  242 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  243 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  243 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  244 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  244 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  245 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  245 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  246 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  246 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  247 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  247 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  248 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  248 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  249 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  249 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  250 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  250 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  251 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  251 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  252 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  252 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  253 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  253 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  254 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  254 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  255 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  255 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  256 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  256 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  257 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  257 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  258 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  258 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  259 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  259 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  260 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  260 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  261 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  261 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  262 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  262 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  263 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  263 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  264 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  264 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  265 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  265 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Row  266 , observation (or)  2 , rowidname aesocvalue , contents:  _ALL_ 
## Row  266 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## Start data rows
## Data rows: Row  1 , observation (or)  1 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 1   1 == 1   1 == 1 
## Observation:  301 
## colvarindex:  1 == 1   1 == 1   1 == 2 
## colvarindex:  1 == 1   1 == 2   1 == 1 
## colvarindex:  1 == 1   1 == 2   1 == 2 
## colvarindex:  1 == 1   1 == 3   1 == 1 
## colvarindex:  1 == 1   1 == 3   1 == 2 
## colvarindex:  1 == 1   1 == 4   1 == 1 
## colvarindex:  1 == 1   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  2 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 2   1 == 1   1 == 1 
## colvarindex:  1 == 2   1 == 1   1 == 2 
## colvarindex:  1 == 2   1 == 2   1 == 1 
## colvarindex:  1 == 2   1 == 2   1 == 2 
## colvarindex:  1 == 2   1 == 3   1 == 1 
## colvarindex:  1 == 2   1 == 3   1 == 2 
## colvarindex:  1 == 2   1 == 4   1 == 1 
## colvarindex:  1 == 2   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  3 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 3   1 == 1   1 == 1 
## colvarindex:  1 == 3   1 == 1   1 == 2 
## colvarindex:  1 == 3   1 == 2   1 == 1 
## colvarindex:  1 == 3   1 == 2   1 == 2 
## colvarindex:  1 == 3   1 == 3   1 == 1 
## colvarindex:  1 == 3   1 == 3   1 == 2 
## colvarindex:  1 == 3   1 == 4   1 == 1 
## colvarindex:  1 == 3   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  4 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 4   1 == 1   1 == 1 
## colvarindex:  1 == 4   1 == 1   1 == 2 
## colvarindex:  1 == 4   1 == 2   1 == 1 
## colvarindex:  1 == 4   1 == 2   1 == 2 
## colvarindex:  1 == 4   1 == 3   1 == 1 
## colvarindex:  1 == 4   1 == 3   1 == 2 
## colvarindex:  1 == 4   1 == 4   1 == 1 
## colvarindex:  1 == 4   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  5 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 5   1 == 1   1 == 1 
## colvarindex:  1 == 5   1 == 1   1 == 2 
## colvarindex:  1 == 5   1 == 2   1 == 1 
## colvarindex:  1 == 5   1 == 2   1 == 2 
## colvarindex:  1 == 5   1 == 3   1 == 1 
## colvarindex:  1 == 5   1 == 3   1 == 2 
## colvarindex:  1 == 5   1 == 4   1 == 1 
## colvarindex:  1 == 5   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  6 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 6   1 == 1   1 == 1 
## colvarindex:  1 == 6   1 == 1   1 == 2 
## colvarindex:  1 == 6   1 == 2   1 == 1 
## colvarindex:  1 == 6   1 == 2   1 == 2 
## colvarindex:  1 == 6   1 == 3   1 == 1 
## colvarindex:  1 == 6   1 == 3   1 == 2 
## colvarindex:  1 == 6   1 == 4   1 == 1 
## colvarindex:  1 == 6   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  7 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 7   1 == 1   1 == 1 
## colvarindex:  1 == 7   1 == 1   1 == 2 
## colvarindex:  1 == 7   1 == 2   1 == 1 
## colvarindex:  1 == 7   1 == 2   1 == 2 
## colvarindex:  1 == 7   1 == 3   1 == 1 
## colvarindex:  1 == 7   1 == 3   1 == 2 
## colvarindex:  1 == 7   1 == 4   1 == 1 
## colvarindex:  1 == 7   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  8 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 8   1 == 1   1 == 1 
## colvarindex:  1 == 8   1 == 1   1 == 2 
## colvarindex:  1 == 8   1 == 2   1 == 1 
## colvarindex:  1 == 8   1 == 2   1 == 2 
## colvarindex:  1 == 8   1 == 3   1 == 1 
## colvarindex:  1 == 8   1 == 3   1 == 2 
## colvarindex:  1 == 8   1 == 4   1 == 1 
## colvarindex:  1 == 8   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  9 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 9   1 == 1   1 == 1 
## colvarindex:  1 == 9   1 == 1   1 == 2 
## colvarindex:  1 == 9   1 == 2   1 == 1 
## colvarindex:  1 == 9   1 == 2   1 == 2 
## colvarindex:  1 == 9   1 == 3   1 == 1 
## colvarindex:  1 == 9   1 == 3   1 == 2 
## colvarindex:  1 == 9   1 == 4   1 == 1 
## colvarindex:  1 == 9   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  10 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 10   1 == 1   1 == 1 
## colvarindex:  1 == 10   1 == 1   1 == 2 
## colvarindex:  1 == 10   1 == 2   1 == 1 
## colvarindex:  1 == 10   1 == 2   1 == 2 
## colvarindex:  1 == 10   1 == 3   1 == 1 
## colvarindex:  1 == 10   1 == 3   1 == 2 
## colvarindex:  1 == 10   1 == 4   1 == 1 
## colvarindex:  1 == 10   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  11 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 11   1 == 1   1 == 1 
## colvarindex:  1 == 11   1 == 1   1 == 2 
## colvarindex:  1 == 11   1 == 2   1 == 1 
## colvarindex:  1 == 11   1 == 2   1 == 2 
## colvarindex:  1 == 11   1 == 3   1 == 1 
## colvarindex:  1 == 11   1 == 3   1 == 2 
## colvarindex:  1 == 11   1 == 4   1 == 1 
## colvarindex:  1 == 11   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  12 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 12   1 == 1   1 == 1 
## colvarindex:  1 == 12   1 == 1   1 == 2 
## colvarindex:  1 == 12   1 == 2   1 == 1 
## colvarindex:  1 == 12   1 == 2   1 == 2 
## colvarindex:  1 == 12   1 == 3   1 == 1 
## colvarindex:  1 == 12   1 == 3   1 == 2 
## colvarindex:  1 == 12   1 == 4   1 == 1 
## colvarindex:  1 == 12   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  13 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 13   1 == 1   1 == 1 
## colvarindex:  1 == 13   1 == 1   1 == 2 
## colvarindex:  1 == 13   1 == 2   1 == 1 
## colvarindex:  1 == 13   1 == 2   1 == 2 
## colvarindex:  1 == 13   1 == 3   1 == 1 
## colvarindex:  1 == 13   1 == 3   1 == 2 
## colvarindex:  1 == 13   1 == 4   1 == 1 
## colvarindex:  1 == 13   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  14 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 14   1 == 1   1 == 1 
## colvarindex:  1 == 14   1 == 1   1 == 2 
## colvarindex:  1 == 14   1 == 2   1 == 1 
## colvarindex:  1 == 14   1 == 2   1 == 2 
## colvarindex:  1 == 14   1 == 3   1 == 1 
## colvarindex:  1 == 14   1 == 3   1 == 2 
## colvarindex:  1 == 14   1 == 4   1 == 1 
## colvarindex:  1 == 14   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  15 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 15   1 == 1   1 == 1 
## colvarindex:  1 == 15   1 == 1   1 == 2 
## colvarindex:  1 == 15   1 == 2   1 == 1 
## colvarindex:  1 == 15   1 == 2   1 == 2 
## colvarindex:  1 == 15   1 == 3   1 == 1 
## colvarindex:  1 == 15   1 == 3   1 == 2 
## colvarindex:  1 == 15   1 == 4   1 == 1 
## colvarindex:  1 == 15   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  16 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 16   1 == 1   1 == 1 
## colvarindex:  1 == 16   1 == 1   1 == 2 
## colvarindex:  1 == 16   1 == 2   1 == 1 
## colvarindex:  1 == 16   1 == 2   1 == 2 
## colvarindex:  1 == 16   1 == 3   1 == 1 
## colvarindex:  1 == 16   1 == 3   1 == 2 
## colvarindex:  1 == 16   1 == 4   1 == 1 
## colvarindex:  1 == 16   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  17 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 17   1 == 1   1 == 1 
## colvarindex:  1 == 17   1 == 1   1 == 2 
## colvarindex:  1 == 17   1 == 2   1 == 1 
## colvarindex:  1 == 17   1 == 2   1 == 2 
## colvarindex:  1 == 17   1 == 3   1 == 1 
## colvarindex:  1 == 17   1 == 3   1 == 2 
## colvarindex:  1 == 17   1 == 4   1 == 1 
## colvarindex:  1 == 17   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  18 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 18   1 == 1   1 == 1 
## colvarindex:  1 == 18   1 == 1   1 == 2 
## colvarindex:  1 == 18   1 == 2   1 == 1 
## colvarindex:  1 == 18   1 == 2   1 == 2 
## colvarindex:  1 == 18   1 == 3   1 == 1 
## colvarindex:  1 == 18   1 == 3   1 == 2 
## colvarindex:  1 == 18   1 == 4   1 == 1 
## colvarindex:  1 == 18   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  19 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 19   1 == 1   1 == 1 
## colvarindex:  1 == 19   1 == 1   1 == 2 
## colvarindex:  1 == 19   1 == 2   1 == 1 
## colvarindex:  1 == 19   1 == 2   1 == 2 
## colvarindex:  1 == 19   1 == 3   1 == 1 
## colvarindex:  1 == 19   1 == 3   1 == 2 
## colvarindex:  1 == 19   1 == 4   1 == 1 
## colvarindex:  1 == 19   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  20 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 20   1 == 1   1 == 1 
## colvarindex:  1 == 20   1 == 1   1 == 2 
## colvarindex:  1 == 20   1 == 2   1 == 1 
## colvarindex:  1 == 20   1 == 2   1 == 2 
## colvarindex:  1 == 20   1 == 3   1 == 1 
## colvarindex:  1 == 20   1 == 3   1 == 2 
## colvarindex:  1 == 20   1 == 4   1 == 1 
## colvarindex:  1 == 20   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  21 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 21   1 == 1   1 == 1 
## colvarindex:  1 == 21   1 == 1   1 == 2 
## colvarindex:  1 == 21   1 == 2   1 == 1 
## colvarindex:  1 == 21   1 == 2   1 == 2 
## colvarindex:  1 == 21   1 == 3   1 == 1 
## colvarindex:  1 == 21   1 == 3   1 == 2 
## colvarindex:  1 == 21   1 == 4   1 == 1 
## colvarindex:  1 == 21   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  22 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 22   1 == 1   1 == 1 
## colvarindex:  1 == 22   1 == 1   1 == 2 
## colvarindex:  1 == 22   1 == 2   1 == 1 
## colvarindex:  1 == 22   1 == 2   1 == 2 
## colvarindex:  1 == 22   1 == 3   1 == 1 
## colvarindex:  1 == 22   1 == 3   1 == 2 
## colvarindex:  1 == 22   1 == 4   1 == 1 
## colvarindex:  1 == 22   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  23 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 23   1 == 1   1 == 1 
## colvarindex:  1 == 23   1 == 1   1 == 2 
## colvarindex:  1 == 23   1 == 2   1 == 1 
## colvarindex:  1 == 23   1 == 2   1 == 2 
## colvarindex:  1 == 23   1 == 3   1 == 1 
## colvarindex:  1 == 23   1 == 3   1 == 2 
## colvarindex:  1 == 23   1 == 4   1 == 1 
## colvarindex:  1 == 23   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  24 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 24   1 == 1   1 == 1 
## colvarindex:  1 == 24   1 == 1   1 == 2 
## colvarindex:  1 == 24   1 == 2   1 == 1 
## colvarindex:  1 == 24   1 == 2   1 == 2 
## colvarindex:  1 == 24   1 == 3   1 == 1 
## colvarindex:  1 == 24   1 == 3   1 == 2 
## colvarindex:  1 == 24   1 == 4   1 == 1 
## colvarindex:  1 == 24   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  25 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 25   1 == 1   1 == 1 
## colvarindex:  1 == 25   1 == 1   1 == 2 
## colvarindex:  1 == 25   1 == 2   1 == 1 
## colvarindex:  1 == 25   1 == 2   1 == 2 
## colvarindex:  1 == 25   1 == 3   1 == 1 
## colvarindex:  1 == 25   1 == 3   1 == 2 
## colvarindex:  1 == 25   1 == 4   1 == 1 
## colvarindex:  1 == 25   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  26 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 26   1 == 1   1 == 1 
## colvarindex:  1 == 26   1 == 1   1 == 2 
## colvarindex:  1 == 26   1 == 2   1 == 1 
## colvarindex:  1 == 26   1 == 2   1 == 2 
## colvarindex:  1 == 26   1 == 3   1 == 1 
## colvarindex:  1 == 26   1 == 3   1 == 2 
## colvarindex:  1 == 26   1 == 4   1 == 1 
## colvarindex:  1 == 26   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  27 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 27   1 == 1   1 == 1 
## colvarindex:  1 == 27   1 == 1   1 == 2 
## colvarindex:  1 == 27   1 == 2   1 == 1 
## colvarindex:  1 == 27   1 == 2   1 == 2 
## colvarindex:  1 == 27   1 == 3   1 == 1 
## colvarindex:  1 == 27   1 == 3   1 == 2 
## colvarindex:  1 == 27   1 == 4   1 == 1 
## colvarindex:  1 == 27   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  28 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 28   1 == 1   1 == 1 
## colvarindex:  1 == 28   1 == 1   1 == 2 
## colvarindex:  1 == 28   1 == 2   1 == 1 
## colvarindex:  1 == 28   1 == 2   1 == 2 
## colvarindex:  1 == 28   1 == 3   1 == 1 
## colvarindex:  1 == 28   1 == 3   1 == 2 
## colvarindex:  1 == 28   1 == 4   1 == 1 
## colvarindex:  1 == 28   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  29 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 29   1 == 1   1 == 1 
## colvarindex:  1 == 29   1 == 1   1 == 2 
## colvarindex:  1 == 29   1 == 2   1 == 1 
## colvarindex:  1 == 29   1 == 2   1 == 2 
## colvarindex:  1 == 29   1 == 3   1 == 1 
## colvarindex:  1 == 29   1 == 3   1 == 2 
## colvarindex:  1 == 29   1 == 4   1 == 1 
## colvarindex:  1 == 29   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  30 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 30   1 == 1   1 == 1 
## colvarindex:  1 == 30   1 == 1   1 == 2 
## colvarindex:  1 == 30   1 == 2   1 == 1 
## colvarindex:  1 == 30   1 == 2   1 == 2 
## colvarindex:  1 == 30   1 == 3   1 == 1 
## colvarindex:  1 == 30   1 == 3   1 == 2 
## colvarindex:  1 == 30   1 == 4   1 == 1 
## colvarindex:  1 == 30   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  31 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 31   1 == 1   1 == 1 
## colvarindex:  1 == 31   1 == 1   1 == 2 
## colvarindex:  1 == 31   1 == 2   1 == 1 
## colvarindex:  1 == 31   1 == 2   1 == 2 
## colvarindex:  1 == 31   1 == 3   1 == 1 
## colvarindex:  1 == 31   1 == 3   1 == 2 
## colvarindex:  1 == 31   1 == 4   1 == 1 
## colvarindex:  1 == 31   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  32 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 32   1 == 1   1 == 1 
## colvarindex:  1 == 32   1 == 1   1 == 2 
## colvarindex:  1 == 32   1 == 2   1 == 1 
## colvarindex:  1 == 32   1 == 2   1 == 2 
## colvarindex:  1 == 32   1 == 3   1 == 1 
## colvarindex:  1 == 32   1 == 3   1 == 2 
## colvarindex:  1 == 32   1 == 4   1 == 1 
## colvarindex:  1 == 32   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  33 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 33   1 == 1   1 == 1 
## colvarindex:  1 == 33   1 == 1   1 == 2 
## colvarindex:  1 == 33   1 == 2   1 == 1 
## colvarindex:  1 == 33   1 == 2   1 == 2 
## colvarindex:  1 == 33   1 == 3   1 == 1 
## colvarindex:  1 == 33   1 == 3   1 == 2 
## colvarindex:  1 == 33   1 == 4   1 == 1 
## colvarindex:  1 == 33   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  34 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 34   1 == 1   1 == 1 
## colvarindex:  1 == 34   1 == 1   1 == 2 
## colvarindex:  1 == 34   1 == 2   1 == 1 
## colvarindex:  1 == 34   1 == 2   1 == 2 
## colvarindex:  1 == 34   1 == 3   1 == 1 
## colvarindex:  1 == 34   1 == 3   1 == 2 
## colvarindex:  1 == 34   1 == 4   1 == 1 
## colvarindex:  1 == 34   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  35 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 35   1 == 1   1 == 1 
## colvarindex:  1 == 35   1 == 1   1 == 2 
## colvarindex:  1 == 35   1 == 2   1 == 1 
## colvarindex:  1 == 35   1 == 2   1 == 2 
## colvarindex:  1 == 35   1 == 3   1 == 1 
## colvarindex:  1 == 35   1 == 3   1 == 2 
## colvarindex:  1 == 35   1 == 4   1 == 1 
## colvarindex:  1 == 35   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  36 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 36   1 == 1   1 == 1 
## colvarindex:  1 == 36   1 == 1   1 == 2 
## colvarindex:  1 == 36   1 == 2   1 == 1 
## colvarindex:  1 == 36   1 == 2   1 == 2 
## colvarindex:  1 == 36   1 == 3   1 == 1 
## colvarindex:  1 == 36   1 == 3   1 == 2 
## colvarindex:  1 == 36   1 == 4   1 == 1 
## colvarindex:  1 == 36   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  37 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 37   1 == 1   1 == 1 
## colvarindex:  1 == 37   1 == 1   1 == 2 
## colvarindex:  1 == 37   1 == 2   1 == 1 
## colvarindex:  1 == 37   1 == 2   1 == 2 
## colvarindex:  1 == 37   1 == 3   1 == 1 
## colvarindex:  1 == 37   1 == 3   1 == 2 
## colvarindex:  1 == 37   1 == 4   1 == 1 
## colvarindex:  1 == 37   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  38 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 38   1 == 1   1 == 1 
## colvarindex:  1 == 38   1 == 1   1 == 2 
## colvarindex:  1 == 38   1 == 2   1 == 1 
## colvarindex:  1 == 38   1 == 2   1 == 2 
## colvarindex:  1 == 38   1 == 3   1 == 1 
## colvarindex:  1 == 38   1 == 3   1 == 2 
## colvarindex:  1 == 38   1 == 4   1 == 1 
## colvarindex:  1 == 38   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  39 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 39   1 == 1   1 == 1 
## colvarindex:  1 == 39   1 == 1   1 == 2 
## colvarindex:  1 == 39   1 == 2   1 == 1 
## colvarindex:  1 == 39   1 == 2   1 == 2 
## colvarindex:  1 == 39   1 == 3   1 == 1 
## colvarindex:  1 == 39   1 == 3   1 == 2 
## colvarindex:  1 == 39   1 == 4   1 == 1 
## colvarindex:  1 == 39   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  40 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 40   1 == 1   1 == 1 
## colvarindex:  1 == 40   1 == 1   1 == 2 
## colvarindex:  1 == 40   1 == 2   1 == 1 
## colvarindex:  1 == 40   1 == 2   1 == 2 
## colvarindex:  1 == 40   1 == 3   1 == 1 
## colvarindex:  1 == 40   1 == 3   1 == 2 
## colvarindex:  1 == 40   1 == 4   1 == 1 
## colvarindex:  1 == 40   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  41 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 41   1 == 1   1 == 1 
## colvarindex:  1 == 41   1 == 1   1 == 2 
## colvarindex:  1 == 41   1 == 2   1 == 1 
## colvarindex:  1 == 41   1 == 2   1 == 2 
## colvarindex:  1 == 41   1 == 3   1 == 1 
## colvarindex:  1 == 41   1 == 3   1 == 2 
## colvarindex:  1 == 41   1 == 4   1 == 1 
## colvarindex:  1 == 41   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  42 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 42   1 == 1   1 == 1 
## colvarindex:  1 == 42   1 == 1   1 == 2 
## colvarindex:  1 == 42   1 == 2   1 == 1 
## colvarindex:  1 == 42   1 == 2   1 == 2 
## colvarindex:  1 == 42   1 == 3   1 == 1 
## colvarindex:  1 == 42   1 == 3   1 == 2 
## colvarindex:  1 == 42   1 == 4   1 == 1 
## colvarindex:  1 == 42   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  43 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 43   1 == 1   1 == 1 
## colvarindex:  1 == 43   1 == 1   1 == 2 
## colvarindex:  1 == 43   1 == 2   1 == 1 
## colvarindex:  1 == 43   1 == 2   1 == 2 
## colvarindex:  1 == 43   1 == 3   1 == 1 
## colvarindex:  1 == 43   1 == 3   1 == 2 
## colvarindex:  1 == 43   1 == 4   1 == 1 
## colvarindex:  1 == 43   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  44 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 44   1 == 1   1 == 1 
## colvarindex:  1 == 44   1 == 1   1 == 2 
## colvarindex:  1 == 44   1 == 2   1 == 1 
## colvarindex:  1 == 44   1 == 2   1 == 2 
## colvarindex:  1 == 44   1 == 3   1 == 1 
## colvarindex:  1 == 44   1 == 3   1 == 2 
## colvarindex:  1 == 44   1 == 4   1 == 1 
## colvarindex:  1 == 44   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  45 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 45   1 == 1   1 == 1 
## colvarindex:  1 == 45   1 == 1   1 == 2 
## colvarindex:  1 == 45   1 == 2   1 == 1 
## colvarindex:  1 == 45   1 == 2   1 == 2 
## colvarindex:  1 == 45   1 == 3   1 == 1 
## colvarindex:  1 == 45   1 == 3   1 == 2 
## colvarindex:  1 == 45   1 == 4   1 == 1 
## colvarindex:  1 == 45   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  46 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 46   1 == 1   1 == 1 
## colvarindex:  1 == 46   1 == 1   1 == 2 
## colvarindex:  1 == 46   1 == 2   1 == 1 
## colvarindex:  1 == 46   1 == 2   1 == 2 
## colvarindex:  1 == 46   1 == 3   1 == 1 
## colvarindex:  1 == 46   1 == 3   1 == 2 
## colvarindex:  1 == 46   1 == 4   1 == 1 
## colvarindex:  1 == 46   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  47 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 47   1 == 1   1 == 1 
## colvarindex:  1 == 47   1 == 1   1 == 2 
## colvarindex:  1 == 47   1 == 2   1 == 1 
## colvarindex:  1 == 47   1 == 2   1 == 2 
## colvarindex:  1 == 47   1 == 3   1 == 1 
## colvarindex:  1 == 47   1 == 3   1 == 2 
## colvarindex:  1 == 47   1 == 4   1 == 1 
## colvarindex:  1 == 47   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  48 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 48   1 == 1   1 == 1 
## colvarindex:  1 == 48   1 == 1   1 == 2 
## colvarindex:  1 == 48   1 == 2   1 == 1 
## colvarindex:  1 == 48   1 == 2   1 == 2 
## colvarindex:  1 == 48   1 == 3   1 == 1 
## colvarindex:  1 == 48   1 == 3   1 == 2 
## colvarindex:  1 == 48   1 == 4   1 == 1 
## colvarindex:  1 == 48   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  49 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 49   1 == 1   1 == 1 
## colvarindex:  1 == 49   1 == 1   1 == 2 
## colvarindex:  1 == 49   1 == 2   1 == 1 
## colvarindex:  1 == 49   1 == 2   1 == 2 
## colvarindex:  1 == 49   1 == 3   1 == 1 
## colvarindex:  1 == 49   1 == 3   1 == 2 
## colvarindex:  1 == 49   1 == 4   1 == 1 
## colvarindex:  1 == 49   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  50 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 50   1 == 1   1 == 1 
## colvarindex:  1 == 50   1 == 1   1 == 2 
## colvarindex:  1 == 50   1 == 2   1 == 1 
## colvarindex:  1 == 50   1 == 2   1 == 2 
## colvarindex:  1 == 50   1 == 3   1 == 1 
## colvarindex:  1 == 50   1 == 3   1 == 2 
## colvarindex:  1 == 50   1 == 4   1 == 1 
## colvarindex:  1 == 50   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  51 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 51   1 == 1   1 == 1 
## colvarindex:  1 == 51   1 == 1   1 == 2 
## colvarindex:  1 == 51   1 == 2   1 == 1 
## colvarindex:  1 == 51   1 == 2   1 == 2 
## colvarindex:  1 == 51   1 == 3   1 == 1 
## colvarindex:  1 == 51   1 == 3   1 == 2 
## colvarindex:  1 == 51   1 == 4   1 == 1 
## colvarindex:  1 == 51   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  52 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 52   1 == 1   1 == 1 
## colvarindex:  1 == 52   1 == 1   1 == 2 
## colvarindex:  1 == 52   1 == 2   1 == 1 
## colvarindex:  1 == 52   1 == 2   1 == 2 
## colvarindex:  1 == 52   1 == 3   1 == 1 
## colvarindex:  1 == 52   1 == 3   1 == 2 
## colvarindex:  1 == 52   1 == 4   1 == 1 
## colvarindex:  1 == 52   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  53 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 53   1 == 1   1 == 1 
## colvarindex:  1 == 53   1 == 1   1 == 2 
## colvarindex:  1 == 53   1 == 2   1 == 1 
## colvarindex:  1 == 53   1 == 2   1 == 2 
## colvarindex:  1 == 53   1 == 3   1 == 1 
## colvarindex:  1 == 53   1 == 3   1 == 2 
## colvarindex:  1 == 53   1 == 4   1 == 1 
## colvarindex:  1 == 53   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  54 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 54   1 == 1   1 == 1 
## colvarindex:  1 == 54   1 == 1   1 == 2 
## colvarindex:  1 == 54   1 == 2   1 == 1 
## colvarindex:  1 == 54   1 == 2   1 == 2 
## colvarindex:  1 == 54   1 == 3   1 == 1 
## colvarindex:  1 == 54   1 == 3   1 == 2 
## colvarindex:  1 == 54   1 == 4   1 == 1 
## colvarindex:  1 == 54   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  55 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 55   1 == 1   1 == 1 
## colvarindex:  1 == 55   1 == 1   1 == 2 
## colvarindex:  1 == 55   1 == 2   1 == 1 
## colvarindex:  1 == 55   1 == 2   1 == 2 
## colvarindex:  1 == 55   1 == 3   1 == 1 
## colvarindex:  1 == 55   1 == 3   1 == 2 
## colvarindex:  1 == 55   1 == 4   1 == 1 
## colvarindex:  1 == 55   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  56 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 56   1 == 1   1 == 1 
## colvarindex:  1 == 56   1 == 1   1 == 2 
## colvarindex:  1 == 56   1 == 2   1 == 1 
## colvarindex:  1 == 56   1 == 2   1 == 2 
## colvarindex:  1 == 56   1 == 3   1 == 1 
## colvarindex:  1 == 56   1 == 3   1 == 2 
## colvarindex:  1 == 56   1 == 4   1 == 1 
## colvarindex:  1 == 56   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  57 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 57   1 == 1   1 == 1 
## colvarindex:  1 == 57   1 == 1   1 == 2 
## colvarindex:  1 == 57   1 == 2   1 == 1 
## colvarindex:  1 == 57   1 == 2   1 == 2 
## colvarindex:  1 == 57   1 == 3   1 == 1 
## colvarindex:  1 == 57   1 == 3   1 == 2 
## colvarindex:  1 == 57   1 == 4   1 == 1 
## colvarindex:  1 == 57   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  58 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 58   1 == 1   1 == 1 
## colvarindex:  1 == 58   1 == 1   1 == 2 
## colvarindex:  1 == 58   1 == 2   1 == 1 
## colvarindex:  1 == 58   1 == 2   1 == 2 
## colvarindex:  1 == 58   1 == 3   1 == 1 
## colvarindex:  1 == 58   1 == 3   1 == 2 
## colvarindex:  1 == 58   1 == 4   1 == 1 
## colvarindex:  1 == 58   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  59 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 59   1 == 1   1 == 1 
## colvarindex:  1 == 59   1 == 1   1 == 2 
## colvarindex:  1 == 59   1 == 2   1 == 1 
## colvarindex:  1 == 59   1 == 2   1 == 2 
## colvarindex:  1 == 59   1 == 3   1 == 1 
## colvarindex:  1 == 59   1 == 3   1 == 2 
## colvarindex:  1 == 59   1 == 4   1 == 1 
## colvarindex:  1 == 59   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  60 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 60   1 == 1   1 == 1 
## colvarindex:  1 == 60   1 == 1   1 == 2 
## colvarindex:  1 == 60   1 == 2   1 == 1 
## colvarindex:  1 == 60   1 == 2   1 == 2 
## colvarindex:  1 == 60   1 == 3   1 == 1 
## colvarindex:  1 == 60   1 == 3   1 == 2 
## colvarindex:  1 == 60   1 == 4   1 == 1 
## colvarindex:  1 == 60   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  61 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 61   1 == 1   1 == 1 
## colvarindex:  1 == 61   1 == 1   1 == 2 
## colvarindex:  1 == 61   1 == 2   1 == 1 
## colvarindex:  1 == 61   1 == 2   1 == 2 
## colvarindex:  1 == 61   1 == 3   1 == 1 
## colvarindex:  1 == 61   1 == 3   1 == 2 
## colvarindex:  1 == 61   1 == 4   1 == 1 
## colvarindex:  1 == 61   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  62 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 62   1 == 1   1 == 1 
## colvarindex:  1 == 62   1 == 1   1 == 2 
## colvarindex:  1 == 62   1 == 2   1 == 1 
## colvarindex:  1 == 62   1 == 2   1 == 2 
## colvarindex:  1 == 62   1 == 3   1 == 1 
## colvarindex:  1 == 62   1 == 3   1 == 2 
## colvarindex:  1 == 62   1 == 4   1 == 1 
## colvarindex:  1 == 62   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  63 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 63   1 == 1   1 == 1 
## colvarindex:  1 == 63   1 == 1   1 == 2 
## colvarindex:  1 == 63   1 == 2   1 == 1 
## colvarindex:  1 == 63   1 == 2   1 == 2 
## colvarindex:  1 == 63   1 == 3   1 == 1 
## colvarindex:  1 == 63   1 == 3   1 == 2 
## colvarindex:  1 == 63   1 == 4   1 == 1 
## colvarindex:  1 == 63   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  64 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 64   1 == 1   1 == 1 
## colvarindex:  1 == 64   1 == 1   1 == 2 
## colvarindex:  1 == 64   1 == 2   1 == 1 
## colvarindex:  1 == 64   1 == 2   1 == 2 
## colvarindex:  1 == 64   1 == 3   1 == 1 
## colvarindex:  1 == 64   1 == 3   1 == 2 
## colvarindex:  1 == 64   1 == 4   1 == 1 
## colvarindex:  1 == 64   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  65 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 65   1 == 1   1 == 1 
## colvarindex:  1 == 65   1 == 1   1 == 2 
## colvarindex:  1 == 65   1 == 2   1 == 1 
## colvarindex:  1 == 65   1 == 2   1 == 2 
## colvarindex:  1 == 65   1 == 3   1 == 1 
## colvarindex:  1 == 65   1 == 3   1 == 2 
## colvarindex:  1 == 65   1 == 4   1 == 1 
## colvarindex:  1 == 65   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  66 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 66   1 == 1   1 == 1 
## colvarindex:  1 == 66   1 == 1   1 == 2 
## colvarindex:  1 == 66   1 == 2   1 == 1 
## colvarindex:  1 == 66   1 == 2   1 == 2 
## colvarindex:  1 == 66   1 == 3   1 == 1 
## colvarindex:  1 == 66   1 == 3   1 == 2 
## colvarindex:  1 == 66   1 == 4   1 == 1 
## colvarindex:  1 == 66   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  67 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 67   1 == 1   1 == 1 
## colvarindex:  1 == 67   1 == 1   1 == 2 
## colvarindex:  1 == 67   1 == 2   1 == 1 
## colvarindex:  1 == 67   1 == 2   1 == 2 
## colvarindex:  1 == 67   1 == 3   1 == 1 
## colvarindex:  1 == 67   1 == 3   1 == 2 
## colvarindex:  1 == 67   1 == 4   1 == 1 
## colvarindex:  1 == 67   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  68 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 68   1 == 1   1 == 1 
## colvarindex:  1 == 68   1 == 1   1 == 2 
## colvarindex:  1 == 68   1 == 2   1 == 1 
## colvarindex:  1 == 68   1 == 2   1 == 2 
## colvarindex:  1 == 68   1 == 3   1 == 1 
## colvarindex:  1 == 68   1 == 3   1 == 2 
## colvarindex:  1 == 68   1 == 4   1 == 1 
## colvarindex:  1 == 68   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  69 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 69   1 == 1   1 == 1 
## colvarindex:  1 == 69   1 == 1   1 == 2 
## colvarindex:  1 == 69   1 == 2   1 == 1 
## colvarindex:  1 == 69   1 == 2   1 == 2 
## colvarindex:  1 == 69   1 == 3   1 == 1 
## colvarindex:  1 == 69   1 == 3   1 == 2 
## colvarindex:  1 == 69   1 == 4   1 == 1 
## colvarindex:  1 == 69   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  70 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 70   1 == 1   1 == 1 
## colvarindex:  1 == 70   1 == 1   1 == 2 
## colvarindex:  1 == 70   1 == 2   1 == 1 
## colvarindex:  1 == 70   1 == 2   1 == 2 
## colvarindex:  1 == 70   1 == 3   1 == 1 
## colvarindex:  1 == 70   1 == 3   1 == 2 
## colvarindex:  1 == 70   1 == 4   1 == 1 
## colvarindex:  1 == 70   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  71 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 71   1 == 1   1 == 1 
## colvarindex:  1 == 71   1 == 1   1 == 2 
## colvarindex:  1 == 71   1 == 2   1 == 1 
## colvarindex:  1 == 71   1 == 2   1 == 2 
## colvarindex:  1 == 71   1 == 3   1 == 1 
## colvarindex:  1 == 71   1 == 3   1 == 2 
## colvarindex:  1 == 71   1 == 4   1 == 1 
## colvarindex:  1 == 71   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  72 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 72   1 == 1   1 == 1 
## colvarindex:  1 == 72   1 == 1   1 == 2 
## colvarindex:  1 == 72   1 == 2   1 == 1 
## colvarindex:  1 == 72   1 == 2   1 == 2 
## colvarindex:  1 == 72   1 == 3   1 == 1 
## colvarindex:  1 == 72   1 == 3   1 == 2 
## colvarindex:  1 == 72   1 == 4   1 == 1 
## colvarindex:  1 == 72   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  73 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 73   1 == 1   1 == 1 
## colvarindex:  1 == 73   1 == 1   1 == 2 
## colvarindex:  1 == 73   1 == 2   1 == 1 
## colvarindex:  1 == 73   1 == 2   1 == 2 
## colvarindex:  1 == 73   1 == 3   1 == 1 
## colvarindex:  1 == 73   1 == 3   1 == 2 
## colvarindex:  1 == 73   1 == 4   1 == 1 
## colvarindex:  1 == 73   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  74 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 74   1 == 1   1 == 1 
## colvarindex:  1 == 74   1 == 1   1 == 2 
## colvarindex:  1 == 74   1 == 2   1 == 1 
## colvarindex:  1 == 74   1 == 2   1 == 2 
## colvarindex:  1 == 74   1 == 3   1 == 1 
## colvarindex:  1 == 74   1 == 3   1 == 2 
## colvarindex:  1 == 74   1 == 4   1 == 1 
## colvarindex:  1 == 74   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  75 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 75   1 == 1   1 == 1 
## colvarindex:  1 == 75   1 == 1   1 == 2 
## colvarindex:  1 == 75   1 == 2   1 == 1 
## colvarindex:  1 == 75   1 == 2   1 == 2 
## colvarindex:  1 == 75   1 == 3   1 == 1 
## colvarindex:  1 == 75   1 == 3   1 == 2 
## colvarindex:  1 == 75   1 == 4   1 == 1 
## colvarindex:  1 == 75   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  76 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 76   1 == 1   1 == 1 
## colvarindex:  1 == 76   1 == 1   1 == 2 
## colvarindex:  1 == 76   1 == 2   1 == 1 
## colvarindex:  1 == 76   1 == 2   1 == 2 
## colvarindex:  1 == 76   1 == 3   1 == 1 
## colvarindex:  1 == 76   1 == 3   1 == 2 
## colvarindex:  1 == 76   1 == 4   1 == 1 
## colvarindex:  1 == 76   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  77 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 77   1 == 1   1 == 1 
## colvarindex:  1 == 77   1 == 1   1 == 2 
## colvarindex:  1 == 77   1 == 2   1 == 1 
## colvarindex:  1 == 77   1 == 2   1 == 2 
## colvarindex:  1 == 77   1 == 3   1 == 1 
## colvarindex:  1 == 77   1 == 3   1 == 2 
## colvarindex:  1 == 77   1 == 4   1 == 1 
## colvarindex:  1 == 77   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  78 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 78   1 == 1   1 == 1 
## colvarindex:  1 == 78   1 == 1   1 == 2 
## colvarindex:  1 == 78   1 == 2   1 == 1 
## colvarindex:  1 == 78   1 == 2   1 == 2 
## colvarindex:  1 == 78   1 == 3   1 == 1 
## colvarindex:  1 == 78   1 == 3   1 == 2 
## colvarindex:  1 == 78   1 == 4   1 == 1 
## colvarindex:  1 == 78   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  79 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 79   1 == 1   1 == 1 
## colvarindex:  1 == 79   1 == 1   1 == 2 
## colvarindex:  1 == 79   1 == 2   1 == 1 
## colvarindex:  1 == 79   1 == 2   1 == 2 
## colvarindex:  1 == 79   1 == 3   1 == 1 
## colvarindex:  1 == 79   1 == 3   1 == 2 
## colvarindex:  1 == 79   1 == 4   1 == 1 
## colvarindex:  1 == 79   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  80 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 80   1 == 1   1 == 1 
## colvarindex:  1 == 80   1 == 1   1 == 2 
## colvarindex:  1 == 80   1 == 2   1 == 1 
## colvarindex:  1 == 80   1 == 2   1 == 2 
## colvarindex:  1 == 80   1 == 3   1 == 1 
## colvarindex:  1 == 80   1 == 3   1 == 2 
## colvarindex:  1 == 80   1 == 4   1 == 1 
## colvarindex:  1 == 80   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  81 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 81   1 == 1   1 == 1 
## colvarindex:  1 == 81   1 == 1   1 == 2 
## colvarindex:  1 == 81   1 == 2   1 == 1 
## colvarindex:  1 == 81   1 == 2   1 == 2 
## colvarindex:  1 == 81   1 == 3   1 == 1 
## colvarindex:  1 == 81   1 == 3   1 == 2 
## colvarindex:  1 == 81   1 == 4   1 == 1 
## colvarindex:  1 == 81   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  82 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 82   1 == 1   1 == 1 
## colvarindex:  1 == 82   1 == 1   1 == 2 
## colvarindex:  1 == 82   1 == 2   1 == 1 
## colvarindex:  1 == 82   1 == 2   1 == 2 
## colvarindex:  1 == 82   1 == 3   1 == 1 
## colvarindex:  1 == 82   1 == 3   1 == 2 
## colvarindex:  1 == 82   1 == 4   1 == 1 
## colvarindex:  1 == 82   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  83 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 83   1 == 1   1 == 1 
## colvarindex:  1 == 83   1 == 1   1 == 2 
## colvarindex:  1 == 83   1 == 2   1 == 1 
## colvarindex:  1 == 83   1 == 2   1 == 2 
## colvarindex:  1 == 83   1 == 3   1 == 1 
## colvarindex:  1 == 83   1 == 3   1 == 2 
## colvarindex:  1 == 83   1 == 4   1 == 1 
## colvarindex:  1 == 83   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  84 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 84   1 == 1   1 == 1 
## colvarindex:  1 == 84   1 == 1   1 == 2 
## colvarindex:  1 == 84   1 == 2   1 == 1 
## colvarindex:  1 == 84   1 == 2   1 == 2 
## colvarindex:  1 == 84   1 == 3   1 == 1 
## colvarindex:  1 == 84   1 == 3   1 == 2 
## colvarindex:  1 == 84   1 == 4   1 == 1 
## colvarindex:  1 == 84   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  85 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 85   1 == 1   1 == 1 
## colvarindex:  1 == 85   1 == 1   1 == 2 
## colvarindex:  1 == 85   1 == 2   1 == 1 
## colvarindex:  1 == 85   1 == 2   1 == 2 
## colvarindex:  1 == 85   1 == 3   1 == 1 
## colvarindex:  1 == 85   1 == 3   1 == 2 
## colvarindex:  1 == 85   1 == 4   1 == 1 
## colvarindex:  1 == 85   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  86 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 86   1 == 1   1 == 1 
## colvarindex:  1 == 86   1 == 1   1 == 2 
## colvarindex:  1 == 86   1 == 2   1 == 1 
## colvarindex:  1 == 86   1 == 2   1 == 2 
## colvarindex:  1 == 86   1 == 3   1 == 1 
## colvarindex:  1 == 86   1 == 3   1 == 2 
## colvarindex:  1 == 86   1 == 4   1 == 1 
## colvarindex:  1 == 86   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  87 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 87   1 == 1   1 == 1 
## colvarindex:  1 == 87   1 == 1   1 == 2 
## colvarindex:  1 == 87   1 == 2   1 == 1 
## colvarindex:  1 == 87   1 == 2   1 == 2 
## colvarindex:  1 == 87   1 == 3   1 == 1 
## colvarindex:  1 == 87   1 == 3   1 == 2 
## colvarindex:  1 == 87   1 == 4   1 == 1 
## colvarindex:  1 == 87   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  88 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 88   1 == 1   1 == 1 
## colvarindex:  1 == 88   1 == 1   1 == 2 
## colvarindex:  1 == 88   1 == 2   1 == 1 
## colvarindex:  1 == 88   1 == 2   1 == 2 
## colvarindex:  1 == 88   1 == 3   1 == 1 
## colvarindex:  1 == 88   1 == 3   1 == 2 
## colvarindex:  1 == 88   1 == 4   1 == 1 
## colvarindex:  1 == 88   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  89 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 89   1 == 1   1 == 1 
## colvarindex:  1 == 89   1 == 1   1 == 2 
## colvarindex:  1 == 89   1 == 2   1 == 1 
## colvarindex:  1 == 89   1 == 2   1 == 2 
## colvarindex:  1 == 89   1 == 3   1 == 1 
## colvarindex:  1 == 89   1 == 3   1 == 2 
## colvarindex:  1 == 89   1 == 4   1 == 1 
## colvarindex:  1 == 89   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  90 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 90   1 == 1   1 == 1 
## colvarindex:  1 == 90   1 == 1   1 == 2 
## colvarindex:  1 == 90   1 == 2   1 == 1 
## colvarindex:  1 == 90   1 == 2   1 == 2 
## colvarindex:  1 == 90   1 == 3   1 == 1 
## colvarindex:  1 == 90   1 == 3   1 == 2 
## colvarindex:  1 == 90   1 == 4   1 == 1 
## colvarindex:  1 == 90   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  91 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 91   1 == 1   1 == 1 
## colvarindex:  1 == 91   1 == 1   1 == 2 
## colvarindex:  1 == 91   1 == 2   1 == 1 
## colvarindex:  1 == 91   1 == 2   1 == 2 
## colvarindex:  1 == 91   1 == 3   1 == 1 
## colvarindex:  1 == 91   1 == 3   1 == 2 
## colvarindex:  1 == 91   1 == 4   1 == 1 
## colvarindex:  1 == 91   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  92 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 92   1 == 1   1 == 1 
## colvarindex:  1 == 92   1 == 1   1 == 2 
## colvarindex:  1 == 92   1 == 2   1 == 1 
## colvarindex:  1 == 92   1 == 2   1 == 2 
## colvarindex:  1 == 92   1 == 3   1 == 1 
## colvarindex:  1 == 92   1 == 3   1 == 2 
## colvarindex:  1 == 92   1 == 4   1 == 1 
## colvarindex:  1 == 92   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  93 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 93   1 == 1   1 == 1 
## colvarindex:  1 == 93   1 == 1   1 == 2 
## colvarindex:  1 == 93   1 == 2   1 == 1 
## colvarindex:  1 == 93   1 == 2   1 == 2 
## colvarindex:  1 == 93   1 == 3   1 == 1 
## colvarindex:  1 == 93   1 == 3   1 == 2 
## colvarindex:  1 == 93   1 == 4   1 == 1 
## colvarindex:  1 == 93   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  94 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 94   1 == 1   1 == 1 
## colvarindex:  1 == 94   1 == 1   1 == 2 
## colvarindex:  1 == 94   1 == 2   1 == 1 
## colvarindex:  1 == 94   1 == 2   1 == 2 
## colvarindex:  1 == 94   1 == 3   1 == 1 
## colvarindex:  1 == 94   1 == 3   1 == 2 
## colvarindex:  1 == 94   1 == 4   1 == 1 
## colvarindex:  1 == 94   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  95 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 95   1 == 1   1 == 1 
## colvarindex:  1 == 95   1 == 1   1 == 2 
## colvarindex:  1 == 95   1 == 2   1 == 1 
## colvarindex:  1 == 95   1 == 2   1 == 2 
## colvarindex:  1 == 95   1 == 3   1 == 1 
## colvarindex:  1 == 95   1 == 3   1 == 2 
## colvarindex:  1 == 95   1 == 4   1 == 1 
## colvarindex:  1 == 95   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  96 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 96   1 == 1   1 == 1 
## colvarindex:  1 == 96   1 == 1   1 == 2 
## colvarindex:  1 == 96   1 == 2   1 == 1 
## colvarindex:  1 == 96   1 == 2   1 == 2 
## colvarindex:  1 == 96   1 == 3   1 == 1 
## colvarindex:  1 == 96   1 == 3   1 == 2 
## colvarindex:  1 == 96   1 == 4   1 == 1 
## colvarindex:  1 == 96   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  97 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 97   1 == 1   1 == 1 
## colvarindex:  1 == 97   1 == 1   1 == 2 
## colvarindex:  1 == 97   1 == 2   1 == 1 
## colvarindex:  1 == 97   1 == 2   1 == 2 
## colvarindex:  1 == 97   1 == 3   1 == 1 
## colvarindex:  1 == 97   1 == 3   1 == 2 
## colvarindex:  1 == 97   1 == 4   1 == 1 
## colvarindex:  1 == 97   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  98 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 98   1 == 1   1 == 1 
## colvarindex:  1 == 98   1 == 1   1 == 2 
## colvarindex:  1 == 98   1 == 2   1 == 1 
## colvarindex:  1 == 98   1 == 2   1 == 2 
## colvarindex:  1 == 98   1 == 3   1 == 1 
## colvarindex:  1 == 98   1 == 3   1 == 2 
## colvarindex:  1 == 98   1 == 4   1 == 1 
## colvarindex:  1 == 98   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  99 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 99   1 == 1   1 == 1 
## colvarindex:  1 == 99   1 == 1   1 == 2 
## colvarindex:  1 == 99   1 == 2   1 == 1 
## colvarindex:  1 == 99   1 == 2   1 == 2 
## colvarindex:  1 == 99   1 == 3   1 == 1 
## colvarindex:  1 == 99   1 == 3   1 == 2 
## colvarindex:  1 == 99   1 == 4   1 == 1 
## colvarindex:  1 == 99   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  100 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 100   1 == 1   1 == 1 
## colvarindex:  1 == 100   1 == 1   1 == 2 
## colvarindex:  1 == 100   1 == 2   1 == 1 
## colvarindex:  1 == 100   1 == 2   1 == 2 
## colvarindex:  1 == 100   1 == 3   1 == 1 
## colvarindex:  1 == 100   1 == 3   1 == 2 
## colvarindex:  1 == 100   1 == 4   1 == 1 
## colvarindex:  1 == 100   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  101 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 101   1 == 1   1 == 1 
## colvarindex:  1 == 101   1 == 1   1 == 2 
## colvarindex:  1 == 101   1 == 2   1 == 1 
## colvarindex:  1 == 101   1 == 2   1 == 2 
## colvarindex:  1 == 101   1 == 3   1 == 1 
## colvarindex:  1 == 101   1 == 3   1 == 2 
## colvarindex:  1 == 101   1 == 4   1 == 1 
## colvarindex:  1 == 101   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  102 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 102   1 == 1   1 == 1 
## colvarindex:  1 == 102   1 == 1   1 == 2 
## colvarindex:  1 == 102   1 == 2   1 == 1 
## colvarindex:  1 == 102   1 == 2   1 == 2 
## colvarindex:  1 == 102   1 == 3   1 == 1 
## colvarindex:  1 == 102   1 == 3   1 == 2 
## colvarindex:  1 == 102   1 == 4   1 == 1 
## colvarindex:  1 == 102   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  103 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 103   1 == 1   1 == 1 
## colvarindex:  1 == 103   1 == 1   1 == 2 
## colvarindex:  1 == 103   1 == 2   1 == 1 
## colvarindex:  1 == 103   1 == 2   1 == 2 
## colvarindex:  1 == 103   1 == 3   1 == 1 
## colvarindex:  1 == 103   1 == 3   1 == 2 
## colvarindex:  1 == 103   1 == 4   1 == 1 
## colvarindex:  1 == 103   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  104 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 104   1 == 1   1 == 1 
## colvarindex:  1 == 104   1 == 1   1 == 2 
## colvarindex:  1 == 104   1 == 2   1 == 1 
## colvarindex:  1 == 104   1 == 2   1 == 2 
## colvarindex:  1 == 104   1 == 3   1 == 1 
## colvarindex:  1 == 104   1 == 3   1 == 2 
## colvarindex:  1 == 104   1 == 4   1 == 1 
## colvarindex:  1 == 104   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  105 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 105   1 == 1   1 == 1 
## colvarindex:  1 == 105   1 == 1   1 == 2 
## colvarindex:  1 == 105   1 == 2   1 == 1 
## colvarindex:  1 == 105   1 == 2   1 == 2 
## colvarindex:  1 == 105   1 == 3   1 == 1 
## colvarindex:  1 == 105   1 == 3   1 == 2 
## colvarindex:  1 == 105   1 == 4   1 == 1 
## colvarindex:  1 == 105   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  106 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 106   1 == 1   1 == 1 
## colvarindex:  1 == 106   1 == 1   1 == 2 
## colvarindex:  1 == 106   1 == 2   1 == 1 
## colvarindex:  1 == 106   1 == 2   1 == 2 
## colvarindex:  1 == 106   1 == 3   1 == 1 
## colvarindex:  1 == 106   1 == 3   1 == 2 
## colvarindex:  1 == 106   1 == 4   1 == 1 
## colvarindex:  1 == 106   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  107 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 107   1 == 1   1 == 1 
## colvarindex:  1 == 107   1 == 1   1 == 2 
## colvarindex:  1 == 107   1 == 2   1 == 1 
## colvarindex:  1 == 107   1 == 2   1 == 2 
## colvarindex:  1 == 107   1 == 3   1 == 1 
## colvarindex:  1 == 107   1 == 3   1 == 2 
## colvarindex:  1 == 107   1 == 4   1 == 1 
## colvarindex:  1 == 107   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  108 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 108   1 == 1   1 == 1 
## colvarindex:  1 == 108   1 == 1   1 == 2 
## colvarindex:  1 == 108   1 == 2   1 == 1 
## colvarindex:  1 == 108   1 == 2   1 == 2 
## colvarindex:  1 == 108   1 == 3   1 == 1 
## colvarindex:  1 == 108   1 == 3   1 == 2 
## colvarindex:  1 == 108   1 == 4   1 == 1 
## colvarindex:  1 == 108   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  109 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 109   1 == 1   1 == 1 
## colvarindex:  1 == 109   1 == 1   1 == 2 
## colvarindex:  1 == 109   1 == 2   1 == 1 
## colvarindex:  1 == 109   1 == 2   1 == 2 
## colvarindex:  1 == 109   1 == 3   1 == 1 
## colvarindex:  1 == 109   1 == 3   1 == 2 
## colvarindex:  1 == 109   1 == 4   1 == 1 
## colvarindex:  1 == 109   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  110 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 110   1 == 1   1 == 1 
## colvarindex:  1 == 110   1 == 1   1 == 2 
## colvarindex:  1 == 110   1 == 2   1 == 1 
## colvarindex:  1 == 110   1 == 2   1 == 2 
## colvarindex:  1 == 110   1 == 3   1 == 1 
## colvarindex:  1 == 110   1 == 3   1 == 2 
## colvarindex:  1 == 110   1 == 4   1 == 1 
## colvarindex:  1 == 110   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  111 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 111   1 == 1   1 == 1 
## colvarindex:  1 == 111   1 == 1   1 == 2 
## colvarindex:  1 == 111   1 == 2   1 == 1 
## colvarindex:  1 == 111   1 == 2   1 == 2 
## colvarindex:  1 == 111   1 == 3   1 == 1 
## colvarindex:  1 == 111   1 == 3   1 == 2 
## colvarindex:  1 == 111   1 == 4   1 == 1 
## colvarindex:  1 == 111   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  112 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 112   1 == 1   1 == 1 
## colvarindex:  1 == 112   1 == 1   1 == 2 
## colvarindex:  1 == 112   1 == 2   1 == 1 
## colvarindex:  1 == 112   1 == 2   1 == 2 
## colvarindex:  1 == 112   1 == 3   1 == 1 
## colvarindex:  1 == 112   1 == 3   1 == 2 
## colvarindex:  1 == 112   1 == 4   1 == 1 
## colvarindex:  1 == 112   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  113 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 113   1 == 1   1 == 1 
## colvarindex:  1 == 113   1 == 1   1 == 2 
## colvarindex:  1 == 113   1 == 2   1 == 1 
## colvarindex:  1 == 113   1 == 2   1 == 2 
## colvarindex:  1 == 113   1 == 3   1 == 1 
## colvarindex:  1 == 113   1 == 3   1 == 2 
## colvarindex:  1 == 113   1 == 4   1 == 1 
## colvarindex:  1 == 113   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  114 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 114   1 == 1   1 == 1 
## colvarindex:  1 == 114   1 == 1   1 == 2 
## colvarindex:  1 == 114   1 == 2   1 == 1 
## colvarindex:  1 == 114   1 == 2   1 == 2 
## colvarindex:  1 == 114   1 == 3   1 == 1 
## colvarindex:  1 == 114   1 == 3   1 == 2 
## colvarindex:  1 == 114   1 == 4   1 == 1 
## colvarindex:  1 == 114   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  115 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 115   1 == 1   1 == 1 
## colvarindex:  1 == 115   1 == 1   1 == 2 
## colvarindex:  1 == 115   1 == 2   1 == 1 
## colvarindex:  1 == 115   1 == 2   1 == 2 
## colvarindex:  1 == 115   1 == 3   1 == 1 
## colvarindex:  1 == 115   1 == 3   1 == 2 
## colvarindex:  1 == 115   1 == 4   1 == 1 
## colvarindex:  1 == 115   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  116 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 116   1 == 1   1 == 1 
## colvarindex:  1 == 116   1 == 1   1 == 2 
## colvarindex:  1 == 116   1 == 2   1 == 1 
## colvarindex:  1 == 116   1 == 2   1 == 2 
## colvarindex:  1 == 116   1 == 3   1 == 1 
## colvarindex:  1 == 116   1 == 3   1 == 2 
## colvarindex:  1 == 116   1 == 4   1 == 1 
## colvarindex:  1 == 116   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  117 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 117   1 == 1   1 == 1 
## colvarindex:  1 == 117   1 == 1   1 == 2 
## colvarindex:  1 == 117   1 == 2   1 == 1 
## colvarindex:  1 == 117   1 == 2   1 == 2 
## colvarindex:  1 == 117   1 == 3   1 == 1 
## colvarindex:  1 == 117   1 == 3   1 == 2 
## colvarindex:  1 == 117   1 == 4   1 == 1 
## colvarindex:  1 == 117   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  118 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 118   1 == 1   1 == 1 
## colvarindex:  1 == 118   1 == 1   1 == 2 
## colvarindex:  1 == 118   1 == 2   1 == 1 
## colvarindex:  1 == 118   1 == 2   1 == 2 
## colvarindex:  1 == 118   1 == 3   1 == 1 
## colvarindex:  1 == 118   1 == 3   1 == 2 
## colvarindex:  1 == 118   1 == 4   1 == 1 
## colvarindex:  1 == 118   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  119 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 119   1 == 1   1 == 1 
## colvarindex:  1 == 119   1 == 1   1 == 2 
## colvarindex:  1 == 119   1 == 2   1 == 1 
## colvarindex:  1 == 119   1 == 2   1 == 2 
## colvarindex:  1 == 119   1 == 3   1 == 1 
## colvarindex:  1 == 119   1 == 3   1 == 2 
## colvarindex:  1 == 119   1 == 4   1 == 1 
## colvarindex:  1 == 119   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  120 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 120   1 == 1   1 == 1 
## colvarindex:  1 == 120   1 == 1   1 == 2 
## colvarindex:  1 == 120   1 == 2   1 == 1 
## colvarindex:  1 == 120   1 == 2   1 == 2 
## colvarindex:  1 == 120   1 == 3   1 == 1 
## colvarindex:  1 == 120   1 == 3   1 == 2 
## colvarindex:  1 == 120   1 == 4   1 == 1 
## colvarindex:  1 == 120   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  121 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 121   1 == 1   1 == 1 
## colvarindex:  1 == 121   1 == 1   1 == 2 
## colvarindex:  1 == 121   1 == 2   1 == 1 
## colvarindex:  1 == 121   1 == 2   1 == 2 
## colvarindex:  1 == 121   1 == 3   1 == 1 
## colvarindex:  1 == 121   1 == 3   1 == 2 
## colvarindex:  1 == 121   1 == 4   1 == 1 
## colvarindex:  1 == 121   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  122 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 122   1 == 1   1 == 1 
## colvarindex:  1 == 122   1 == 1   1 == 2 
## colvarindex:  1 == 122   1 == 2   1 == 1 
## colvarindex:  1 == 122   1 == 2   1 == 2 
## colvarindex:  1 == 122   1 == 3   1 == 1 
## colvarindex:  1 == 122   1 == 3   1 == 2 
## colvarindex:  1 == 122   1 == 4   1 == 1 
## colvarindex:  1 == 122   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  123 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 123   1 == 1   1 == 1 
## colvarindex:  1 == 123   1 == 1   1 == 2 
## colvarindex:  1 == 123   1 == 2   1 == 1 
## colvarindex:  1 == 123   1 == 2   1 == 2 
## colvarindex:  1 == 123   1 == 3   1 == 1 
## colvarindex:  1 == 123   1 == 3   1 == 2 
## colvarindex:  1 == 123   1 == 4   1 == 1 
## colvarindex:  1 == 123   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  124 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 124   1 == 1   1 == 1 
## colvarindex:  1 == 124   1 == 1   1 == 2 
## colvarindex:  1 == 124   1 == 2   1 == 1 
## colvarindex:  1 == 124   1 == 2   1 == 2 
## colvarindex:  1 == 124   1 == 3   1 == 1 
## colvarindex:  1 == 124   1 == 3   1 == 2 
## colvarindex:  1 == 124   1 == 4   1 == 1 
## colvarindex:  1 == 124   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  125 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 125   1 == 1   1 == 1 
## colvarindex:  1 == 125   1 == 1   1 == 2 
## colvarindex:  1 == 125   1 == 2   1 == 1 
## colvarindex:  1 == 125   1 == 2   1 == 2 
## colvarindex:  1 == 125   1 == 3   1 == 1 
## colvarindex:  1 == 125   1 == 3   1 == 2 
## colvarindex:  1 == 125   1 == 4   1 == 1 
## colvarindex:  1 == 125   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  126 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 126   1 == 1   1 == 1 
## colvarindex:  1 == 126   1 == 1   1 == 2 
## colvarindex:  1 == 126   1 == 2   1 == 1 
## colvarindex:  1 == 126   1 == 2   1 == 2 
## colvarindex:  1 == 126   1 == 3   1 == 1 
## colvarindex:  1 == 126   1 == 3   1 == 2 
## colvarindex:  1 == 126   1 == 4   1 == 1 
## colvarindex:  1 == 126   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  127 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 127   1 == 1   1 == 1 
## colvarindex:  1 == 127   1 == 1   1 == 2 
## colvarindex:  1 == 127   1 == 2   1 == 1 
## colvarindex:  1 == 127   1 == 2   1 == 2 
## colvarindex:  1 == 127   1 == 3   1 == 1 
## colvarindex:  1 == 127   1 == 3   1 == 2 
## colvarindex:  1 == 127   1 == 4   1 == 1 
## colvarindex:  1 == 127   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  128 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 128   1 == 1   1 == 1 
## colvarindex:  1 == 128   1 == 1   1 == 2 
## colvarindex:  1 == 128   1 == 2   1 == 1 
## colvarindex:  1 == 128   1 == 2   1 == 2 
## colvarindex:  1 == 128   1 == 3   1 == 1 
## colvarindex:  1 == 128   1 == 3   1 == 2 
## colvarindex:  1 == 128   1 == 4   1 == 1 
## colvarindex:  1 == 128   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  129 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 129   1 == 1   1 == 1 
## colvarindex:  1 == 129   1 == 1   1 == 2 
## colvarindex:  1 == 129   1 == 2   1 == 1 
## colvarindex:  1 == 129   1 == 2   1 == 2 
## colvarindex:  1 == 129   1 == 3   1 == 1 
## colvarindex:  1 == 129   1 == 3   1 == 2 
## colvarindex:  1 == 129   1 == 4   1 == 1 
## colvarindex:  1 == 129   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  130 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 130   1 == 1   1 == 1 
## colvarindex:  1 == 130   1 == 1   1 == 2 
## colvarindex:  1 == 130   1 == 2   1 == 1 
## colvarindex:  1 == 130   1 == 2   1 == 2 
## colvarindex:  1 == 130   1 == 3   1 == 1 
## colvarindex:  1 == 130   1 == 3   1 == 2 
## colvarindex:  1 == 130   1 == 4   1 == 1 
## colvarindex:  1 == 130   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  131 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 131   1 == 1   1 == 1 
## colvarindex:  1 == 131   1 == 1   1 == 2 
## colvarindex:  1 == 131   1 == 2   1 == 1 
## colvarindex:  1 == 131   1 == 2   1 == 2 
## colvarindex:  1 == 131   1 == 3   1 == 1 
## colvarindex:  1 == 131   1 == 3   1 == 2 
## colvarindex:  1 == 131   1 == 4   1 == 1 
## colvarindex:  1 == 131   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  132 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 132   1 == 1   1 == 1 
## colvarindex:  1 == 132   1 == 1   1 == 2 
## colvarindex:  1 == 132   1 == 2   1 == 1 
## colvarindex:  1 == 132   1 == 2   1 == 2 
## colvarindex:  1 == 132   1 == 3   1 == 1 
## colvarindex:  1 == 132   1 == 3   1 == 2 
## colvarindex:  1 == 132   1 == 4   1 == 1 
## colvarindex:  1 == 132   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  133 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 133   1 == 1   1 == 1 
## colvarindex:  1 == 133   1 == 1   1 == 2 
## colvarindex:  1 == 133   1 == 2   1 == 1 
## colvarindex:  1 == 133   1 == 2   1 == 2 
## colvarindex:  1 == 133   1 == 3   1 == 1 
## colvarindex:  1 == 133   1 == 3   1 == 2 
## colvarindex:  1 == 133   1 == 4   1 == 1 
## colvarindex:  1 == 133   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  134 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 134   1 == 1   1 == 1 
## colvarindex:  1 == 134   1 == 1   1 == 2 
## colvarindex:  1 == 134   1 == 2   1 == 1 
## colvarindex:  1 == 134   1 == 2   1 == 2 
## colvarindex:  1 == 134   1 == 3   1 == 1 
## colvarindex:  1 == 134   1 == 3   1 == 2 
## colvarindex:  1 == 134   1 == 4   1 == 1 
## colvarindex:  1 == 134   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  135 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 135   1 == 1   1 == 1 
## colvarindex:  1 == 135   1 == 1   1 == 2 
## colvarindex:  1 == 135   1 == 2   1 == 1 
## colvarindex:  1 == 135   1 == 2   1 == 2 
## colvarindex:  1 == 135   1 == 3   1 == 1 
## colvarindex:  1 == 135   1 == 3   1 == 2 
## colvarindex:  1 == 135   1 == 4   1 == 1 
## colvarindex:  1 == 135   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  136 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 136   1 == 1   1 == 1 
## colvarindex:  1 == 136   1 == 1   1 == 2 
## colvarindex:  1 == 136   1 == 2   1 == 1 
## colvarindex:  1 == 136   1 == 2   1 == 2 
## colvarindex:  1 == 136   1 == 3   1 == 1 
## colvarindex:  1 == 136   1 == 3   1 == 2 
## colvarindex:  1 == 136   1 == 4   1 == 1 
## colvarindex:  1 == 136   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  137 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 137   1 == 1   1 == 1 
## colvarindex:  1 == 137   1 == 1   1 == 2 
## colvarindex:  1 == 137   1 == 2   1 == 1 
## colvarindex:  1 == 137   1 == 2   1 == 2 
## colvarindex:  1 == 137   1 == 3   1 == 1 
## colvarindex:  1 == 137   1 == 3   1 == 2 
## colvarindex:  1 == 137   1 == 4   1 == 1 
## colvarindex:  1 == 137   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  138 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 138   1 == 1   1 == 1 
## colvarindex:  1 == 138   1 == 1   1 == 2 
## colvarindex:  1 == 138   1 == 2   1 == 1 
## colvarindex:  1 == 138   1 == 2   1 == 2 
## colvarindex:  1 == 138   1 == 3   1 == 1 
## colvarindex:  1 == 138   1 == 3   1 == 2 
## colvarindex:  1 == 138   1 == 4   1 == 1 
## colvarindex:  1 == 138   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  139 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 139   1 == 1   1 == 1 
## colvarindex:  1 == 139   1 == 1   1 == 2 
## colvarindex:  1 == 139   1 == 2   1 == 1 
## colvarindex:  1 == 139   1 == 2   1 == 2 
## colvarindex:  1 == 139   1 == 3   1 == 1 
## colvarindex:  1 == 139   1 == 3   1 == 2 
## colvarindex:  1 == 139   1 == 4   1 == 1 
## colvarindex:  1 == 139   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  140 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 140   1 == 1   1 == 1 
## colvarindex:  1 == 140   1 == 1   1 == 2 
## colvarindex:  1 == 140   1 == 2   1 == 1 
## colvarindex:  1 == 140   1 == 2   1 == 2 
## colvarindex:  1 == 140   1 == 3   1 == 1 
## colvarindex:  1 == 140   1 == 3   1 == 2 
## colvarindex:  1 == 140   1 == 4   1 == 1 
## colvarindex:  1 == 140   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  141 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 141   1 == 1   1 == 1 
## colvarindex:  1 == 141   1 == 1   1 == 2 
## colvarindex:  1 == 141   1 == 2   1 == 1 
## colvarindex:  1 == 141   1 == 2   1 == 2 
## colvarindex:  1 == 141   1 == 3   1 == 1 
## colvarindex:  1 == 141   1 == 3   1 == 2 
## colvarindex:  1 == 141   1 == 4   1 == 1 
## colvarindex:  1 == 141   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  142 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 142   1 == 1   1 == 1 
## colvarindex:  1 == 142   1 == 1   1 == 2 
## colvarindex:  1 == 142   1 == 2   1 == 1 
## colvarindex:  1 == 142   1 == 2   1 == 2 
## colvarindex:  1 == 142   1 == 3   1 == 1 
## colvarindex:  1 == 142   1 == 3   1 == 2 
## colvarindex:  1 == 142   1 == 4   1 == 1 
## colvarindex:  1 == 142   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  143 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 143   1 == 1   1 == 1 
## colvarindex:  1 == 143   1 == 1   1 == 2 
## colvarindex:  1 == 143   1 == 2   1 == 1 
## colvarindex:  1 == 143   1 == 2   1 == 2 
## colvarindex:  1 == 143   1 == 3   1 == 1 
## colvarindex:  1 == 143   1 == 3   1 == 2 
## colvarindex:  1 == 143   1 == 4   1 == 1 
## colvarindex:  1 == 143   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  144 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 144   1 == 1   1 == 1 
## colvarindex:  1 == 144   1 == 1   1 == 2 
## colvarindex:  1 == 144   1 == 2   1 == 1 
## colvarindex:  1 == 144   1 == 2   1 == 2 
## colvarindex:  1 == 144   1 == 3   1 == 1 
## colvarindex:  1 == 144   1 == 3   1 == 2 
## colvarindex:  1 == 144   1 == 4   1 == 1 
## colvarindex:  1 == 144   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  145 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 145   1 == 1   1 == 1 
## colvarindex:  1 == 145   1 == 1   1 == 2 
## colvarindex:  1 == 145   1 == 2   1 == 1 
## colvarindex:  1 == 145   1 == 2   1 == 2 
## colvarindex:  1 == 145   1 == 3   1 == 1 
## colvarindex:  1 == 145   1 == 3   1 == 2 
## colvarindex:  1 == 145   1 == 4   1 == 1 
## colvarindex:  1 == 145   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  146 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 146   1 == 1   1 == 1 
## colvarindex:  1 == 146   1 == 1   1 == 2 
## colvarindex:  1 == 146   1 == 2   1 == 1 
## colvarindex:  1 == 146   1 == 2   1 == 2 
## colvarindex:  1 == 146   1 == 3   1 == 1 
## colvarindex:  1 == 146   1 == 3   1 == 2 
## colvarindex:  1 == 146   1 == 4   1 == 1 
## colvarindex:  1 == 146   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  147 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 147   1 == 1   1 == 1 
## colvarindex:  1 == 147   1 == 1   1 == 2 
## colvarindex:  1 == 147   1 == 2   1 == 1 
## colvarindex:  1 == 147   1 == 2   1 == 2 
## colvarindex:  1 == 147   1 == 3   1 == 1 
## colvarindex:  1 == 147   1 == 3   1 == 2 
## colvarindex:  1 == 147   1 == 4   1 == 1 
## colvarindex:  1 == 147   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  148 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 148   1 == 1   1 == 1 
## colvarindex:  1 == 148   1 == 1   1 == 2 
## colvarindex:  1 == 148   1 == 2   1 == 1 
## colvarindex:  1 == 148   1 == 2   1 == 2 
## colvarindex:  1 == 148   1 == 3   1 == 1 
## colvarindex:  1 == 148   1 == 3   1 == 2 
## colvarindex:  1 == 148   1 == 4   1 == 1 
## colvarindex:  1 == 148   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  149 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 149   1 == 1   1 == 1 
## colvarindex:  1 == 149   1 == 1   1 == 2 
## colvarindex:  1 == 149   1 == 2   1 == 1 
## colvarindex:  1 == 149   1 == 2   1 == 2 
## colvarindex:  1 == 149   1 == 3   1 == 1 
## colvarindex:  1 == 149   1 == 3   1 == 2 
## colvarindex:  1 == 149   1 == 4   1 == 1 
## colvarindex:  1 == 149   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  150 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 150   1 == 1   1 == 1 
## colvarindex:  1 == 150   1 == 1   1 == 2 
## colvarindex:  1 == 150   1 == 2   1 == 1 
## colvarindex:  1 == 150   1 == 2   1 == 2 
## colvarindex:  1 == 150   1 == 3   1 == 1 
## colvarindex:  1 == 150   1 == 3   1 == 2 
## colvarindex:  1 == 150   1 == 4   1 == 1 
## colvarindex:  1 == 150   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  151 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 151   1 == 1   1 == 1 
## colvarindex:  1 == 151   1 == 1   1 == 2 
## colvarindex:  1 == 151   1 == 2   1 == 1 
## colvarindex:  1 == 151   1 == 2   1 == 2 
## colvarindex:  1 == 151   1 == 3   1 == 1 
## colvarindex:  1 == 151   1 == 3   1 == 2 
## colvarindex:  1 == 151   1 == 4   1 == 1 
## colvarindex:  1 == 151   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  152 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 152   1 == 1   1 == 1 
## colvarindex:  1 == 152   1 == 1   1 == 2 
## colvarindex:  1 == 152   1 == 2   1 == 1 
## colvarindex:  1 == 152   1 == 2   1 == 2 
## colvarindex:  1 == 152   1 == 3   1 == 1 
## colvarindex:  1 == 152   1 == 3   1 == 2 
## colvarindex:  1 == 152   1 == 4   1 == 1 
## colvarindex:  1 == 152   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  153 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 153   1 == 1   1 == 1 
## colvarindex:  1 == 153   1 == 1   1 == 2 
## colvarindex:  1 == 153   1 == 2   1 == 1 
## colvarindex:  1 == 153   1 == 2   1 == 2 
## colvarindex:  1 == 153   1 == 3   1 == 1 
## colvarindex:  1 == 153   1 == 3   1 == 2 
## colvarindex:  1 == 153   1 == 4   1 == 1 
## colvarindex:  1 == 153   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  154 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 154   1 == 1   1 == 1 
## colvarindex:  1 == 154   1 == 1   1 == 2 
## colvarindex:  1 == 154   1 == 2   1 == 1 
## colvarindex:  1 == 154   1 == 2   1 == 2 
## colvarindex:  1 == 154   1 == 3   1 == 1 
## colvarindex:  1 == 154   1 == 3   1 == 2 
## colvarindex:  1 == 154   1 == 4   1 == 1 
## colvarindex:  1 == 154   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  155 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 155   1 == 1   1 == 1 
## colvarindex:  1 == 155   1 == 1   1 == 2 
## colvarindex:  1 == 155   1 == 2   1 == 1 
## colvarindex:  1 == 155   1 == 2   1 == 2 
## colvarindex:  1 == 155   1 == 3   1 == 1 
## colvarindex:  1 == 155   1 == 3   1 == 2 
## colvarindex:  1 == 155   1 == 4   1 == 1 
## colvarindex:  1 == 155   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  156 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 156   1 == 1   1 == 1 
## colvarindex:  1 == 156   1 == 1   1 == 2 
## colvarindex:  1 == 156   1 == 2   1 == 1 
## colvarindex:  1 == 156   1 == 2   1 == 2 
## colvarindex:  1 == 156   1 == 3   1 == 1 
## colvarindex:  1 == 156   1 == 3   1 == 2 
## colvarindex:  1 == 156   1 == 4   1 == 1 
## colvarindex:  1 == 156   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  157 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 157   1 == 1   1 == 1 
## colvarindex:  1 == 157   1 == 1   1 == 2 
## colvarindex:  1 == 157   1 == 2   1 == 1 
## colvarindex:  1 == 157   1 == 2   1 == 2 
## colvarindex:  1 == 157   1 == 3   1 == 1 
## colvarindex:  1 == 157   1 == 3   1 == 2 
## colvarindex:  1 == 157   1 == 4   1 == 1 
## colvarindex:  1 == 157   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  158 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 158   1 == 1   1 == 1 
## colvarindex:  1 == 158   1 == 1   1 == 2 
## colvarindex:  1 == 158   1 == 2   1 == 1 
## colvarindex:  1 == 158   1 == 2   1 == 2 
## colvarindex:  1 == 158   1 == 3   1 == 1 
## colvarindex:  1 == 158   1 == 3   1 == 2 
## colvarindex:  1 == 158   1 == 4   1 == 1 
## colvarindex:  1 == 158   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  159 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 159   1 == 1   1 == 1 
## colvarindex:  1 == 159   1 == 1   1 == 2 
## colvarindex:  1 == 159   1 == 2   1 == 1 
## colvarindex:  1 == 159   1 == 2   1 == 2 
## colvarindex:  1 == 159   1 == 3   1 == 1 
## colvarindex:  1 == 159   1 == 3   1 == 2 
## colvarindex:  1 == 159   1 == 4   1 == 1 
## colvarindex:  1 == 159   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  160 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 160   1 == 1   1 == 1 
## colvarindex:  1 == 160   1 == 1   1 == 2 
## colvarindex:  1 == 160   1 == 2   1 == 1 
## colvarindex:  1 == 160   1 == 2   1 == 2 
## colvarindex:  1 == 160   1 == 3   1 == 1 
## colvarindex:  1 == 160   1 == 3   1 == 2 
## colvarindex:  1 == 160   1 == 4   1 == 1 
## colvarindex:  1 == 160   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  161 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 161   1 == 1   1 == 1 
## colvarindex:  1 == 161   1 == 1   1 == 2 
## colvarindex:  1 == 161   1 == 2   1 == 1 
## colvarindex:  1 == 161   1 == 2   1 == 2 
## colvarindex:  1 == 161   1 == 3   1 == 1 
## colvarindex:  1 == 161   1 == 3   1 == 2 
## colvarindex:  1 == 161   1 == 4   1 == 1 
## colvarindex:  1 == 161   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  162 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 162   1 == 1   1 == 1 
## colvarindex:  1 == 162   1 == 1   1 == 2 
## colvarindex:  1 == 162   1 == 2   1 == 1 
## colvarindex:  1 == 162   1 == 2   1 == 2 
## colvarindex:  1 == 162   1 == 3   1 == 1 
## colvarindex:  1 == 162   1 == 3   1 == 2 
## colvarindex:  1 == 162   1 == 4   1 == 1 
## colvarindex:  1 == 162   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  163 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 163   1 == 1   1 == 1 
## colvarindex:  1 == 163   1 == 1   1 == 2 
## colvarindex:  1 == 163   1 == 2   1 == 1 
## colvarindex:  1 == 163   1 == 2   1 == 2 
## colvarindex:  1 == 163   1 == 3   1 == 1 
## colvarindex:  1 == 163   1 == 3   1 == 2 
## colvarindex:  1 == 163   1 == 4   1 == 1 
## colvarindex:  1 == 163   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  164 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 164   1 == 1   1 == 1 
## colvarindex:  1 == 164   1 == 1   1 == 2 
## colvarindex:  1 == 164   1 == 2   1 == 1 
## colvarindex:  1 == 164   1 == 2   1 == 2 
## colvarindex:  1 == 164   1 == 3   1 == 1 
## colvarindex:  1 == 164   1 == 3   1 == 2 
## colvarindex:  1 == 164   1 == 4   1 == 1 
## colvarindex:  1 == 164   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  165 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 165   1 == 1   1 == 1 
## colvarindex:  1 == 165   1 == 1   1 == 2 
## colvarindex:  1 == 165   1 == 2   1 == 1 
## colvarindex:  1 == 165   1 == 2   1 == 2 
## colvarindex:  1 == 165   1 == 3   1 == 1 
## colvarindex:  1 == 165   1 == 3   1 == 2 
## colvarindex:  1 == 165   1 == 4   1 == 1 
## colvarindex:  1 == 165   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  166 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 166   1 == 1   1 == 1 
## colvarindex:  1 == 166   1 == 1   1 == 2 
## colvarindex:  1 == 166   1 == 2   1 == 1 
## colvarindex:  1 == 166   1 == 2   1 == 2 
## colvarindex:  1 == 166   1 == 3   1 == 1 
## colvarindex:  1 == 166   1 == 3   1 == 2 
## colvarindex:  1 == 166   1 == 4   1 == 1 
## colvarindex:  1 == 166   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  167 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 167   1 == 1   1 == 1 
## colvarindex:  1 == 167   1 == 1   1 == 2 
## colvarindex:  1 == 167   1 == 2   1 == 1 
## colvarindex:  1 == 167   1 == 2   1 == 2 
## colvarindex:  1 == 167   1 == 3   1 == 1 
## colvarindex:  1 == 167   1 == 3   1 == 2 
## colvarindex:  1 == 167   1 == 4   1 == 1 
## colvarindex:  1 == 167   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  168 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 168   1 == 1   1 == 1 
## colvarindex:  1 == 168   1 == 1   1 == 2 
## colvarindex:  1 == 168   1 == 2   1 == 1 
## colvarindex:  1 == 168   1 == 2   1 == 2 
## colvarindex:  1 == 168   1 == 3   1 == 1 
## colvarindex:  1 == 168   1 == 3   1 == 2 
## colvarindex:  1 == 168   1 == 4   1 == 1 
## colvarindex:  1 == 168   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  169 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 169   1 == 1   1 == 1 
## colvarindex:  1 == 169   1 == 1   1 == 2 
## colvarindex:  1 == 169   1 == 2   1 == 1 
## colvarindex:  1 == 169   1 == 2   1 == 2 
## colvarindex:  1 == 169   1 == 3   1 == 1 
## colvarindex:  1 == 169   1 == 3   1 == 2 
## colvarindex:  1 == 169   1 == 4   1 == 1 
## colvarindex:  1 == 169   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  170 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 170   1 == 1   1 == 1 
## colvarindex:  1 == 170   1 == 1   1 == 2 
## colvarindex:  1 == 170   1 == 2   1 == 1 
## colvarindex:  1 == 170   1 == 2   1 == 2 
## colvarindex:  1 == 170   1 == 3   1 == 1 
## colvarindex:  1 == 170   1 == 3   1 == 2 
## colvarindex:  1 == 170   1 == 4   1 == 1 
## colvarindex:  1 == 170   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  171 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 171   1 == 1   1 == 1 
## colvarindex:  1 == 171   1 == 1   1 == 2 
## colvarindex:  1 == 171   1 == 2   1 == 1 
## colvarindex:  1 == 171   1 == 2   1 == 2 
## colvarindex:  1 == 171   1 == 3   1 == 1 
## colvarindex:  1 == 171   1 == 3   1 == 2 
## colvarindex:  1 == 171   1 == 4   1 == 1 
## colvarindex:  1 == 171   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  172 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 172   1 == 1   1 == 1 
## colvarindex:  1 == 172   1 == 1   1 == 2 
## colvarindex:  1 == 172   1 == 2   1 == 1 
## colvarindex:  1 == 172   1 == 2   1 == 2 
## colvarindex:  1 == 172   1 == 3   1 == 1 
## colvarindex:  1 == 172   1 == 3   1 == 2 
## colvarindex:  1 == 172   1 == 4   1 == 1 
## colvarindex:  1 == 172   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  173 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 173   1 == 1   1 == 1 
## colvarindex:  1 == 173   1 == 1   1 == 2 
## colvarindex:  1 == 173   1 == 2   1 == 1 
## colvarindex:  1 == 173   1 == 2   1 == 2 
## colvarindex:  1 == 173   1 == 3   1 == 1 
## colvarindex:  1 == 173   1 == 3   1 == 2 
## colvarindex:  1 == 173   1 == 4   1 == 1 
## colvarindex:  1 == 173   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  174 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 174   1 == 1   1 == 1 
## colvarindex:  1 == 174   1 == 1   1 == 2 
## colvarindex:  1 == 174   1 == 2   1 == 1 
## colvarindex:  1 == 174   1 == 2   1 == 2 
## colvarindex:  1 == 174   1 == 3   1 == 1 
## colvarindex:  1 == 174   1 == 3   1 == 2 
## colvarindex:  1 == 174   1 == 4   1 == 1 
## colvarindex:  1 == 174   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  175 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 175   1 == 1   1 == 1 
## colvarindex:  1 == 175   1 == 1   1 == 2 
## colvarindex:  1 == 175   1 == 2   1 == 1 
## colvarindex:  1 == 175   1 == 2   1 == 2 
## colvarindex:  1 == 175   1 == 3   1 == 1 
## colvarindex:  1 == 175   1 == 3   1 == 2 
## colvarindex:  1 == 175   1 == 4   1 == 1 
## colvarindex:  1 == 175   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  176 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 176   1 == 1   1 == 1 
## colvarindex:  1 == 176   1 == 1   1 == 2 
## colvarindex:  1 == 176   1 == 2   1 == 1 
## colvarindex:  1 == 176   1 == 2   1 == 2 
## colvarindex:  1 == 176   1 == 3   1 == 1 
## colvarindex:  1 == 176   1 == 3   1 == 2 
## colvarindex:  1 == 176   1 == 4   1 == 1 
## colvarindex:  1 == 176   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  177 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 177   1 == 1   1 == 1 
## colvarindex:  1 == 177   1 == 1   1 == 2 
## colvarindex:  1 == 177   1 == 2   1 == 1 
## colvarindex:  1 == 177   1 == 2   1 == 2 
## colvarindex:  1 == 177   1 == 3   1 == 1 
## colvarindex:  1 == 177   1 == 3   1 == 2 
## colvarindex:  1 == 177   1 == 4   1 == 1 
## colvarindex:  1 == 177   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  178 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 178   1 == 1   1 == 1 
## colvarindex:  1 == 178   1 == 1   1 == 2 
## colvarindex:  1 == 178   1 == 2   1 == 1 
## colvarindex:  1 == 178   1 == 2   1 == 2 
## colvarindex:  1 == 178   1 == 3   1 == 1 
## colvarindex:  1 == 178   1 == 3   1 == 2 
## colvarindex:  1 == 178   1 == 4   1 == 1 
## colvarindex:  1 == 178   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  179 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 179   1 == 1   1 == 1 
## colvarindex:  1 == 179   1 == 1   1 == 2 
## colvarindex:  1 == 179   1 == 2   1 == 1 
## colvarindex:  1 == 179   1 == 2   1 == 2 
## colvarindex:  1 == 179   1 == 3   1 == 1 
## colvarindex:  1 == 179   1 == 3   1 == 2 
## colvarindex:  1 == 179   1 == 4   1 == 1 
## colvarindex:  1 == 179   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  180 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 180   1 == 1   1 == 1 
## colvarindex:  1 == 180   1 == 1   1 == 2 
## colvarindex:  1 == 180   1 == 2   1 == 1 
## colvarindex:  1 == 180   1 == 2   1 == 2 
## colvarindex:  1 == 180   1 == 3   1 == 1 
## colvarindex:  1 == 180   1 == 3   1 == 2 
## colvarindex:  1 == 180   1 == 4   1 == 1 
## colvarindex:  1 == 180   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  181 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 181   1 == 1   1 == 1 
## colvarindex:  1 == 181   1 == 1   1 == 2 
## colvarindex:  1 == 181   1 == 2   1 == 1 
## colvarindex:  1 == 181   1 == 2   1 == 2 
## colvarindex:  1 == 181   1 == 3   1 == 1 
## colvarindex:  1 == 181   1 == 3   1 == 2 
## colvarindex:  1 == 181   1 == 4   1 == 1 
## colvarindex:  1 == 181   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  182 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 182   1 == 1   1 == 1 
## colvarindex:  1 == 182   1 == 1   1 == 2 
## colvarindex:  1 == 182   1 == 2   1 == 1 
## colvarindex:  1 == 182   1 == 2   1 == 2 
## colvarindex:  1 == 182   1 == 3   1 == 1 
## colvarindex:  1 == 182   1 == 3   1 == 2 
## colvarindex:  1 == 182   1 == 4   1 == 1 
## colvarindex:  1 == 182   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  183 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 183   1 == 1   1 == 1 
## colvarindex:  1 == 183   1 == 1   1 == 2 
## colvarindex:  1 == 183   1 == 2   1 == 1 
## colvarindex:  1 == 183   1 == 2   1 == 2 
## colvarindex:  1 == 183   1 == 3   1 == 1 
## colvarindex:  1 == 183   1 == 3   1 == 2 
## colvarindex:  1 == 183   1 == 4   1 == 1 
## colvarindex:  1 == 183   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  184 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 184   1 == 1   1 == 1 
## colvarindex:  1 == 184   1 == 1   1 == 2 
## colvarindex:  1 == 184   1 == 2   1 == 1 
## colvarindex:  1 == 184   1 == 2   1 == 2 
## colvarindex:  1 == 184   1 == 3   1 == 1 
## colvarindex:  1 == 184   1 == 3   1 == 2 
## colvarindex:  1 == 184   1 == 4   1 == 1 
## colvarindex:  1 == 184   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  185 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 185   1 == 1   1 == 1 
## colvarindex:  1 == 185   1 == 1   1 == 2 
## colvarindex:  1 == 185   1 == 2   1 == 1 
## colvarindex:  1 == 185   1 == 2   1 == 2 
## colvarindex:  1 == 185   1 == 3   1 == 1 
## colvarindex:  1 == 185   1 == 3   1 == 2 
## colvarindex:  1 == 185   1 == 4   1 == 1 
## colvarindex:  1 == 185   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  186 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 186   1 == 1   1 == 1 
## colvarindex:  1 == 186   1 == 1   1 == 2 
## colvarindex:  1 == 186   1 == 2   1 == 1 
## colvarindex:  1 == 186   1 == 2   1 == 2 
## colvarindex:  1 == 186   1 == 3   1 == 1 
## colvarindex:  1 == 186   1 == 3   1 == 2 
## colvarindex:  1 == 186   1 == 4   1 == 1 
## colvarindex:  1 == 186   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  187 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 187   1 == 1   1 == 1 
## colvarindex:  1 == 187   1 == 1   1 == 2 
## colvarindex:  1 == 187   1 == 2   1 == 1 
## colvarindex:  1 == 187   1 == 2   1 == 2 
## colvarindex:  1 == 187   1 == 3   1 == 1 
## colvarindex:  1 == 187   1 == 3   1 == 2 
## colvarindex:  1 == 187   1 == 4   1 == 1 
## colvarindex:  1 == 187   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  188 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 188   1 == 1   1 == 1 
## colvarindex:  1 == 188   1 == 1   1 == 2 
## colvarindex:  1 == 188   1 == 2   1 == 1 
## colvarindex:  1 == 188   1 == 2   1 == 2 
## colvarindex:  1 == 188   1 == 3   1 == 1 
## colvarindex:  1 == 188   1 == 3   1 == 2 
## colvarindex:  1 == 188   1 == 4   1 == 1 
## colvarindex:  1 == 188   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  189 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 189   1 == 1   1 == 1 
## colvarindex:  1 == 189   1 == 1   1 == 2 
## colvarindex:  1 == 189   1 == 2   1 == 1 
## colvarindex:  1 == 189   1 == 2   1 == 2 
## colvarindex:  1 == 189   1 == 3   1 == 1 
## colvarindex:  1 == 189   1 == 3   1 == 2 
## colvarindex:  1 == 189   1 == 4   1 == 1 
## colvarindex:  1 == 189   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  190 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 190   1 == 1   1 == 1 
## colvarindex:  1 == 190   1 == 1   1 == 2 
## colvarindex:  1 == 190   1 == 2   1 == 1 
## colvarindex:  1 == 190   1 == 2   1 == 2 
## colvarindex:  1 == 190   1 == 3   1 == 1 
## colvarindex:  1 == 190   1 == 3   1 == 2 
## colvarindex:  1 == 190   1 == 4   1 == 1 
## colvarindex:  1 == 190   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  191 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 191   1 == 1   1 == 1 
## colvarindex:  1 == 191   1 == 1   1 == 2 
## colvarindex:  1 == 191   1 == 2   1 == 1 
## colvarindex:  1 == 191   1 == 2   1 == 2 
## colvarindex:  1 == 191   1 == 3   1 == 1 
## colvarindex:  1 == 191   1 == 3   1 == 2 
## colvarindex:  1 == 191   1 == 4   1 == 1 
## colvarindex:  1 == 191   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  192 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 192   1 == 1   1 == 1 
## colvarindex:  1 == 192   1 == 1   1 == 2 
## colvarindex:  1 == 192   1 == 2   1 == 1 
## colvarindex:  1 == 192   1 == 2   1 == 2 
## colvarindex:  1 == 192   1 == 3   1 == 1 
## colvarindex:  1 == 192   1 == 3   1 == 2 
## colvarindex:  1 == 192   1 == 4   1 == 1 
## colvarindex:  1 == 192   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  193 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 193   1 == 1   1 == 1 
## colvarindex:  1 == 193   1 == 1   1 == 2 
## colvarindex:  1 == 193   1 == 2   1 == 1 
## colvarindex:  1 == 193   1 == 2   1 == 2 
## colvarindex:  1 == 193   1 == 3   1 == 1 
## colvarindex:  1 == 193   1 == 3   1 == 2 
## colvarindex:  1 == 193   1 == 4   1 == 1 
## colvarindex:  1 == 193   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  194 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 194   1 == 1   1 == 1 
## colvarindex:  1 == 194   1 == 1   1 == 2 
## colvarindex:  1 == 194   1 == 2   1 == 1 
## colvarindex:  1 == 194   1 == 2   1 == 2 
## colvarindex:  1 == 194   1 == 3   1 == 1 
## colvarindex:  1 == 194   1 == 3   1 == 2 
## colvarindex:  1 == 194   1 == 4   1 == 1 
## colvarindex:  1 == 194   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  195 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 195   1 == 1   1 == 1 
## colvarindex:  1 == 195   1 == 1   1 == 2 
## colvarindex:  1 == 195   1 == 2   1 == 1 
## colvarindex:  1 == 195   1 == 2   1 == 2 
## colvarindex:  1 == 195   1 == 3   1 == 1 
## colvarindex:  1 == 195   1 == 3   1 == 2 
## colvarindex:  1 == 195   1 == 4   1 == 1 
## colvarindex:  1 == 195   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  196 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 196   1 == 1   1 == 1 
## colvarindex:  1 == 196   1 == 1   1 == 2 
## colvarindex:  1 == 196   1 == 2   1 == 1 
## colvarindex:  1 == 196   1 == 2   1 == 2 
## colvarindex:  1 == 196   1 == 3   1 == 1 
## colvarindex:  1 == 196   1 == 3   1 == 2 
## colvarindex:  1 == 196   1 == 4   1 == 1 
## colvarindex:  1 == 196   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  197 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 197   1 == 1   1 == 1 
## colvarindex:  1 == 197   1 == 1   1 == 2 
## colvarindex:  1 == 197   1 == 2   1 == 1 
## colvarindex:  1 == 197   1 == 2   1 == 2 
## colvarindex:  1 == 197   1 == 3   1 == 1 
## colvarindex:  1 == 197   1 == 3   1 == 2 
## colvarindex:  1 == 197   1 == 4   1 == 1 
## colvarindex:  1 == 197   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  198 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 198   1 == 1   1 == 1 
## colvarindex:  1 == 198   1 == 1   1 == 2 
## colvarindex:  1 == 198   1 == 2   1 == 1 
## colvarindex:  1 == 198   1 == 2   1 == 2 
## colvarindex:  1 == 198   1 == 3   1 == 1 
## colvarindex:  1 == 198   1 == 3   1 == 2 
## colvarindex:  1 == 198   1 == 4   1 == 1 
## colvarindex:  1 == 198   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  199 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 199   1 == 1   1 == 1 
## colvarindex:  1 == 199   1 == 1   1 == 2 
## colvarindex:  1 == 199   1 == 2   1 == 1 
## colvarindex:  1 == 199   1 == 2   1 == 2 
## colvarindex:  1 == 199   1 == 3   1 == 1 
## colvarindex:  1 == 199   1 == 3   1 == 2 
## colvarindex:  1 == 199   1 == 4   1 == 1 
## colvarindex:  1 == 199   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  200 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 200   1 == 1   1 == 1 
## colvarindex:  1 == 200   1 == 1   1 == 2 
## colvarindex:  1 == 200   1 == 2   1 == 1 
## colvarindex:  1 == 200   1 == 2   1 == 2 
## colvarindex:  1 == 200   1 == 3   1 == 1 
## colvarindex:  1 == 200   1 == 3   1 == 2 
## colvarindex:  1 == 200   1 == 4   1 == 1 
## colvarindex:  1 == 200   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  201 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 201   1 == 1   1 == 1 
## colvarindex:  1 == 201   1 == 1   1 == 2 
## colvarindex:  1 == 201   1 == 2   1 == 1 
## colvarindex:  1 == 201   1 == 2   1 == 2 
## colvarindex:  1 == 201   1 == 3   1 == 1 
## colvarindex:  1 == 201   1 == 3   1 == 2 
## colvarindex:  1 == 201   1 == 4   1 == 1 
## colvarindex:  1 == 201   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  202 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 202   1 == 1   1 == 1 
## colvarindex:  1 == 202   1 == 1   1 == 2 
## colvarindex:  1 == 202   1 == 2   1 == 1 
## colvarindex:  1 == 202   1 == 2   1 == 2 
## colvarindex:  1 == 202   1 == 3   1 == 1 
## colvarindex:  1 == 202   1 == 3   1 == 2 
## colvarindex:  1 == 202   1 == 4   1 == 1 
## colvarindex:  1 == 202   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  203 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 203   1 == 1   1 == 1 
## colvarindex:  1 == 203   1 == 1   1 == 2 
## colvarindex:  1 == 203   1 == 2   1 == 1 
## colvarindex:  1 == 203   1 == 2   1 == 2 
## colvarindex:  1 == 203   1 == 3   1 == 1 
## colvarindex:  1 == 203   1 == 3   1 == 2 
## colvarindex:  1 == 203   1 == 4   1 == 1 
## colvarindex:  1 == 203   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  204 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 204   1 == 1   1 == 1 
## colvarindex:  1 == 204   1 == 1   1 == 2 
## colvarindex:  1 == 204   1 == 2   1 == 1 
## colvarindex:  1 == 204   1 == 2   1 == 2 
## colvarindex:  1 == 204   1 == 3   1 == 1 
## colvarindex:  1 == 204   1 == 3   1 == 2 
## colvarindex:  1 == 204   1 == 4   1 == 1 
## colvarindex:  1 == 204   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  205 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 205   1 == 1   1 == 1 
## colvarindex:  1 == 205   1 == 1   1 == 2 
## colvarindex:  1 == 205   1 == 2   1 == 1 
## colvarindex:  1 == 205   1 == 2   1 == 2 
## colvarindex:  1 == 205   1 == 3   1 == 1 
## colvarindex:  1 == 205   1 == 3   1 == 2 
## colvarindex:  1 == 205   1 == 4   1 == 1 
## colvarindex:  1 == 205   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  206 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 206   1 == 1   1 == 1 
## colvarindex:  1 == 206   1 == 1   1 == 2 
## colvarindex:  1 == 206   1 == 2   1 == 1 
## colvarindex:  1 == 206   1 == 2   1 == 2 
## colvarindex:  1 == 206   1 == 3   1 == 1 
## colvarindex:  1 == 206   1 == 3   1 == 2 
## colvarindex:  1 == 206   1 == 4   1 == 1 
## colvarindex:  1 == 206   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  207 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 207   1 == 1   1 == 1 
## colvarindex:  1 == 207   1 == 1   1 == 2 
## colvarindex:  1 == 207   1 == 2   1 == 1 
## colvarindex:  1 == 207   1 == 2   1 == 2 
## colvarindex:  1 == 207   1 == 3   1 == 1 
## colvarindex:  1 == 207   1 == 3   1 == 2 
## colvarindex:  1 == 207   1 == 4   1 == 1 
## colvarindex:  1 == 207   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  208 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 208   1 == 1   1 == 1 
## colvarindex:  1 == 208   1 == 1   1 == 2 
## colvarindex:  1 == 208   1 == 2   1 == 1 
## colvarindex:  1 == 208   1 == 2   1 == 2 
## colvarindex:  1 == 208   1 == 3   1 == 1 
## colvarindex:  1 == 208   1 == 3   1 == 2 
## colvarindex:  1 == 208   1 == 4   1 == 1 
## colvarindex:  1 == 208   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  209 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 209   1 == 1   1 == 1 
## colvarindex:  1 == 209   1 == 1   1 == 2 
## colvarindex:  1 == 209   1 == 2   1 == 1 
## colvarindex:  1 == 209   1 == 2   1 == 2 
## colvarindex:  1 == 209   1 == 3   1 == 1 
## colvarindex:  1 == 209   1 == 3   1 == 2 
## colvarindex:  1 == 209   1 == 4   1 == 1 
## colvarindex:  1 == 209   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  210 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 210   1 == 1   1 == 1 
## colvarindex:  1 == 210   1 == 1   1 == 2 
## colvarindex:  1 == 210   1 == 2   1 == 1 
## colvarindex:  1 == 210   1 == 2   1 == 2 
## colvarindex:  1 == 210   1 == 3   1 == 1 
## colvarindex:  1 == 210   1 == 3   1 == 2 
## colvarindex:  1 == 210   1 == 4   1 == 1 
## colvarindex:  1 == 210   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  211 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 211   1 == 1   1 == 1 
## colvarindex:  1 == 211   1 == 1   1 == 2 
## colvarindex:  1 == 211   1 == 2   1 == 1 
## colvarindex:  1 == 211   1 == 2   1 == 2 
## colvarindex:  1 == 211   1 == 3   1 == 1 
## colvarindex:  1 == 211   1 == 3   1 == 2 
## colvarindex:  1 == 211   1 == 4   1 == 1 
## colvarindex:  1 == 211   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  212 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 212   1 == 1   1 == 1 
## colvarindex:  1 == 212   1 == 1   1 == 2 
## colvarindex:  1 == 212   1 == 2   1 == 1 
## colvarindex:  1 == 212   1 == 2   1 == 2 
## colvarindex:  1 == 212   1 == 3   1 == 1 
## colvarindex:  1 == 212   1 == 3   1 == 2 
## colvarindex:  1 == 212   1 == 4   1 == 1 
## colvarindex:  1 == 212   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  213 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 213   1 == 1   1 == 1 
## colvarindex:  1 == 213   1 == 1   1 == 2 
## colvarindex:  1 == 213   1 == 2   1 == 1 
## colvarindex:  1 == 213   1 == 2   1 == 2 
## colvarindex:  1 == 213   1 == 3   1 == 1 
## colvarindex:  1 == 213   1 == 3   1 == 2 
## colvarindex:  1 == 213   1 == 4   1 == 1 
## colvarindex:  1 == 213   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  214 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 214   1 == 1   1 == 1 
## colvarindex:  1 == 214   1 == 1   1 == 2 
## colvarindex:  1 == 214   1 == 2   1 == 1 
## colvarindex:  1 == 214   1 == 2   1 == 2 
## colvarindex:  1 == 214   1 == 3   1 == 1 
## colvarindex:  1 == 214   1 == 3   1 == 2 
## colvarindex:  1 == 214   1 == 4   1 == 1 
## colvarindex:  1 == 214   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  215 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 215   1 == 1   1 == 1 
## colvarindex:  1 == 215   1 == 1   1 == 2 
## colvarindex:  1 == 215   1 == 2   1 == 1 
## colvarindex:  1 == 215   1 == 2   1 == 2 
## colvarindex:  1 == 215   1 == 3   1 == 1 
## colvarindex:  1 == 215   1 == 3   1 == 2 
## colvarindex:  1 == 215   1 == 4   1 == 1 
## colvarindex:  1 == 215   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  216 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 216   1 == 1   1 == 1 
## colvarindex:  1 == 216   1 == 1   1 == 2 
## colvarindex:  1 == 216   1 == 2   1 == 1 
## colvarindex:  1 == 216   1 == 2   1 == 2 
## colvarindex:  1 == 216   1 == 3   1 == 1 
## colvarindex:  1 == 216   1 == 3   1 == 2 
## colvarindex:  1 == 216   1 == 4   1 == 1 
## colvarindex:  1 == 216   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  217 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 217   1 == 1   1 == 1 
## colvarindex:  1 == 217   1 == 1   1 == 2 
## colvarindex:  1 == 217   1 == 2   1 == 1 
## colvarindex:  1 == 217   1 == 2   1 == 2 
## colvarindex:  1 == 217   1 == 3   1 == 1 
## colvarindex:  1 == 217   1 == 3   1 == 2 
## colvarindex:  1 == 217   1 == 4   1 == 1 
## colvarindex:  1 == 217   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  218 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 218   1 == 1   1 == 1 
## colvarindex:  1 == 218   1 == 1   1 == 2 
## colvarindex:  1 == 218   1 == 2   1 == 1 
## colvarindex:  1 == 218   1 == 2   1 == 2 
## colvarindex:  1 == 218   1 == 3   1 == 1 
## colvarindex:  1 == 218   1 == 3   1 == 2 
## colvarindex:  1 == 218   1 == 4   1 == 1 
## colvarindex:  1 == 218   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  219 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 219   1 == 1   1 == 1 
## colvarindex:  1 == 219   1 == 1   1 == 2 
## colvarindex:  1 == 219   1 == 2   1 == 1 
## colvarindex:  1 == 219   1 == 2   1 == 2 
## colvarindex:  1 == 219   1 == 3   1 == 1 
## colvarindex:  1 == 219   1 == 3   1 == 2 
## colvarindex:  1 == 219   1 == 4   1 == 1 
## colvarindex:  1 == 219   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  220 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 220   1 == 1   1 == 1 
## colvarindex:  1 == 220   1 == 1   1 == 2 
## colvarindex:  1 == 220   1 == 2   1 == 1 
## colvarindex:  1 == 220   1 == 2   1 == 2 
## colvarindex:  1 == 220   1 == 3   1 == 1 
## colvarindex:  1 == 220   1 == 3   1 == 2 
## colvarindex:  1 == 220   1 == 4   1 == 1 
## colvarindex:  1 == 220   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  221 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 221   1 == 1   1 == 1 
## colvarindex:  1 == 221   1 == 1   1 == 2 
## colvarindex:  1 == 221   1 == 2   1 == 1 
## colvarindex:  1 == 221   1 == 2   1 == 2 
## colvarindex:  1 == 221   1 == 3   1 == 1 
## colvarindex:  1 == 221   1 == 3   1 == 2 
## colvarindex:  1 == 221   1 == 4   1 == 1 
## colvarindex:  1 == 221   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  222 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 222   1 == 1   1 == 1 
## colvarindex:  1 == 222   1 == 1   1 == 2 
## colvarindex:  1 == 222   1 == 2   1 == 1 
## colvarindex:  1 == 222   1 == 2   1 == 2 
## colvarindex:  1 == 222   1 == 3   1 == 1 
## colvarindex:  1 == 222   1 == 3   1 == 2 
## colvarindex:  1 == 222   1 == 4   1 == 1 
## colvarindex:  1 == 222   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  223 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 223   1 == 1   1 == 1 
## colvarindex:  1 == 223   1 == 1   1 == 2 
## colvarindex:  1 == 223   1 == 2   1 == 1 
## colvarindex:  1 == 223   1 == 2   1 == 2 
## colvarindex:  1 == 223   1 == 3   1 == 1 
## colvarindex:  1 == 223   1 == 3   1 == 2 
## colvarindex:  1 == 223   1 == 4   1 == 1 
## colvarindex:  1 == 223   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  224 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 224   1 == 1   1 == 1 
## colvarindex:  1 == 224   1 == 1   1 == 2 
## colvarindex:  1 == 224   1 == 2   1 == 1 
## colvarindex:  1 == 224   1 == 2   1 == 2 
## colvarindex:  1 == 224   1 == 3   1 == 1 
## colvarindex:  1 == 224   1 == 3   1 == 2 
## colvarindex:  1 == 224   1 == 4   1 == 1 
## colvarindex:  1 == 224   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  225 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 225   1 == 1   1 == 1 
## colvarindex:  1 == 225   1 == 1   1 == 2 
## colvarindex:  1 == 225   1 == 2   1 == 1 
## colvarindex:  1 == 225   1 == 2   1 == 2 
## colvarindex:  1 == 225   1 == 3   1 == 1 
## colvarindex:  1 == 225   1 == 3   1 == 2 
## colvarindex:  1 == 225   1 == 4   1 == 1 
## colvarindex:  1 == 225   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  226 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 226   1 == 1   1 == 1 
## colvarindex:  1 == 226   1 == 1   1 == 2 
## colvarindex:  1 == 226   1 == 2   1 == 1 
## colvarindex:  1 == 226   1 == 2   1 == 2 
## colvarindex:  1 == 226   1 == 3   1 == 1 
## colvarindex:  1 == 226   1 == 3   1 == 2 
## colvarindex:  1 == 226   1 == 4   1 == 1 
## colvarindex:  1 == 226   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  227 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 227   1 == 1   1 == 1 
## colvarindex:  1 == 227   1 == 1   1 == 2 
## colvarindex:  1 == 227   1 == 2   1 == 1 
## colvarindex:  1 == 227   1 == 2   1 == 2 
## colvarindex:  1 == 227   1 == 3   1 == 1 
## colvarindex:  1 == 227   1 == 3   1 == 2 
## colvarindex:  1 == 227   1 == 4   1 == 1 
## colvarindex:  1 == 227   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  228 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 228   1 == 1   1 == 1 
## colvarindex:  1 == 228   1 == 1   1 == 2 
## colvarindex:  1 == 228   1 == 2   1 == 1 
## colvarindex:  1 == 228   1 == 2   1 == 2 
## colvarindex:  1 == 228   1 == 3   1 == 1 
## colvarindex:  1 == 228   1 == 3   1 == 2 
## colvarindex:  1 == 228   1 == 4   1 == 1 
## colvarindex:  1 == 228   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  229 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 229   1 == 1   1 == 1 
## colvarindex:  1 == 229   1 == 1   1 == 2 
## colvarindex:  1 == 229   1 == 2   1 == 1 
## colvarindex:  1 == 229   1 == 2   1 == 2 
## colvarindex:  1 == 229   1 == 3   1 == 1 
## colvarindex:  1 == 229   1 == 3   1 == 2 
## colvarindex:  1 == 229   1 == 4   1 == 1 
## colvarindex:  1 == 229   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  230 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 230   1 == 1   1 == 1 
## colvarindex:  1 == 230   1 == 1   1 == 2 
## colvarindex:  1 == 230   1 == 2   1 == 1 
## colvarindex:  1 == 230   1 == 2   1 == 2 
## colvarindex:  1 == 230   1 == 3   1 == 1 
## colvarindex:  1 == 230   1 == 3   1 == 2 
## colvarindex:  1 == 230   1 == 4   1 == 1 
## colvarindex:  1 == 230   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  231 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 231   1 == 1   1 == 1 
## colvarindex:  1 == 231   1 == 1   1 == 2 
## colvarindex:  1 == 231   1 == 2   1 == 1 
## colvarindex:  1 == 231   1 == 2   1 == 2 
## colvarindex:  1 == 231   1 == 3   1 == 1 
## colvarindex:  1 == 231   1 == 3   1 == 2 
## colvarindex:  1 == 231   1 == 4   1 == 1 
## colvarindex:  1 == 231   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  232 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 232   1 == 1   1 == 1 
## colvarindex:  1 == 232   1 == 1   1 == 2 
## colvarindex:  1 == 232   1 == 2   1 == 1 
## colvarindex:  1 == 232   1 == 2   1 == 2 
## colvarindex:  1 == 232   1 == 3   1 == 1 
## colvarindex:  1 == 232   1 == 3   1 == 2 
## colvarindex:  1 == 232   1 == 4   1 == 1 
## colvarindex:  1 == 232   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  233 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 233   1 == 1   1 == 1 
## colvarindex:  1 == 233   1 == 1   1 == 2 
## colvarindex:  1 == 233   1 == 2   1 == 1 
## colvarindex:  1 == 233   1 == 2   1 == 2 
## colvarindex:  1 == 233   1 == 3   1 == 1 
## colvarindex:  1 == 233   1 == 3   1 == 2 
## colvarindex:  1 == 233   1 == 4   1 == 1 
## colvarindex:  1 == 233   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  234 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 234   1 == 1   1 == 1 
## colvarindex:  1 == 234   1 == 1   1 == 2 
## colvarindex:  1 == 234   1 == 2   1 == 1 
## colvarindex:  1 == 234   1 == 2   1 == 2 
## colvarindex:  1 == 234   1 == 3   1 == 1 
## colvarindex:  1 == 234   1 == 3   1 == 2 
## colvarindex:  1 == 234   1 == 4   1 == 1 
## colvarindex:  1 == 234   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  235 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 235   1 == 1   1 == 1 
## colvarindex:  1 == 235   1 == 1   1 == 2 
## colvarindex:  1 == 235   1 == 2   1 == 1 
## colvarindex:  1 == 235   1 == 2   1 == 2 
## colvarindex:  1 == 235   1 == 3   1 == 1 
## colvarindex:  1 == 235   1 == 3   1 == 2 
## colvarindex:  1 == 235   1 == 4   1 == 1 
## colvarindex:  1 == 235   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  236 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 236   1 == 1   1 == 1 
## colvarindex:  1 == 236   1 == 1   1 == 2 
## colvarindex:  1 == 236   1 == 2   1 == 1 
## colvarindex:  1 == 236   1 == 2   1 == 2 
## colvarindex:  1 == 236   1 == 3   1 == 1 
## colvarindex:  1 == 236   1 == 3   1 == 2 
## colvarindex:  1 == 236   1 == 4   1 == 1 
## colvarindex:  1 == 236   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  237 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 237   1 == 1   1 == 1 
## colvarindex:  1 == 237   1 == 1   1 == 2 
## colvarindex:  1 == 237   1 == 2   1 == 1 
## colvarindex:  1 == 237   1 == 2   1 == 2 
## colvarindex:  1 == 237   1 == 3   1 == 1 
## colvarindex:  1 == 237   1 == 3   1 == 2 
## colvarindex:  1 == 237   1 == 4   1 == 1 
## colvarindex:  1 == 237   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  238 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 238   1 == 1   1 == 1 
## colvarindex:  1 == 238   1 == 1   1 == 2 
## colvarindex:  1 == 238   1 == 2   1 == 1 
## colvarindex:  1 == 238   1 == 2   1 == 2 
## colvarindex:  1 == 238   1 == 3   1 == 1 
## colvarindex:  1 == 238   1 == 3   1 == 2 
## colvarindex:  1 == 238   1 == 4   1 == 1 
## colvarindex:  1 == 238   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  239 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 239   1 == 1   1 == 1 
## colvarindex:  1 == 239   1 == 1   1 == 2 
## colvarindex:  1 == 239   1 == 2   1 == 1 
## colvarindex:  1 == 239   1 == 2   1 == 2 
## colvarindex:  1 == 239   1 == 3   1 == 1 
## colvarindex:  1 == 239   1 == 3   1 == 2 
## colvarindex:  1 == 239   1 == 4   1 == 1 
## colvarindex:  1 == 239   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  240 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 240   1 == 1   1 == 1 
## colvarindex:  1 == 240   1 == 1   1 == 2 
## colvarindex:  1 == 240   1 == 2   1 == 1 
## colvarindex:  1 == 240   1 == 2   1 == 2 
## colvarindex:  1 == 240   1 == 3   1 == 1 
## colvarindex:  1 == 240   1 == 3   1 == 2 
## colvarindex:  1 == 240   1 == 4   1 == 1 
## colvarindex:  1 == 240   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  241 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 241   1 == 1   1 == 1 
## colvarindex:  1 == 241   1 == 1   1 == 2 
## colvarindex:  1 == 241   1 == 2   1 == 1 
## colvarindex:  1 == 241   1 == 2   1 == 2 
## colvarindex:  1 == 241   1 == 3   1 == 1 
## colvarindex:  1 == 241   1 == 3   1 == 2 
## colvarindex:  1 == 241   1 == 4   1 == 1 
## colvarindex:  1 == 241   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  242 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 242   1 == 1   1 == 1 
## colvarindex:  1 == 242   1 == 1   1 == 2 
## colvarindex:  1 == 242   1 == 2   1 == 1 
## colvarindex:  1 == 242   1 == 2   1 == 2 
## colvarindex:  1 == 242   1 == 3   1 == 1 
## colvarindex:  1 == 242   1 == 3   1 == 2 
## colvarindex:  1 == 242   1 == 4   1 == 1 
## colvarindex:  1 == 242   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  243 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 243   1 == 1   1 == 1 
## colvarindex:  1 == 243   1 == 1   1 == 2 
## colvarindex:  1 == 243   1 == 2   1 == 1 
## colvarindex:  1 == 243   1 == 2   1 == 2 
## colvarindex:  1 == 243   1 == 3   1 == 1 
## colvarindex:  1 == 243   1 == 3   1 == 2 
## colvarindex:  1 == 243   1 == 4   1 == 1 
## colvarindex:  1 == 243   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  244 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 244   1 == 1   1 == 1 
## colvarindex:  1 == 244   1 == 1   1 == 2 
## colvarindex:  1 == 244   1 == 2   1 == 1 
## colvarindex:  1 == 244   1 == 2   1 == 2 
## colvarindex:  1 == 244   1 == 3   1 == 1 
## colvarindex:  1 == 244   1 == 3   1 == 2 
## colvarindex:  1 == 244   1 == 4   1 == 1 
## colvarindex:  1 == 244   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  245 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 245   1 == 1   1 == 1 
## colvarindex:  1 == 245   1 == 1   1 == 2 
## colvarindex:  1 == 245   1 == 2   1 == 1 
## colvarindex:  1 == 245   1 == 2   1 == 2 
## colvarindex:  1 == 245   1 == 3   1 == 1 
## colvarindex:  1 == 245   1 == 3   1 == 2 
## colvarindex:  1 == 245   1 == 4   1 == 1 
## colvarindex:  1 == 245   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  246 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 246   1 == 1   1 == 1 
## colvarindex:  1 == 246   1 == 1   1 == 2 
## colvarindex:  1 == 246   1 == 2   1 == 1 
## colvarindex:  1 == 246   1 == 2   1 == 2 
## colvarindex:  1 == 246   1 == 3   1 == 1 
## colvarindex:  1 == 246   1 == 3   1 == 2 
## colvarindex:  1 == 246   1 == 4   1 == 1 
## colvarindex:  1 == 246   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  247 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 247   1 == 1   1 == 1 
## colvarindex:  1 == 247   1 == 1   1 == 2 
## colvarindex:  1 == 247   1 == 2   1 == 1 
## colvarindex:  1 == 247   1 == 2   1 == 2 
## colvarindex:  1 == 247   1 == 3   1 == 1 
## colvarindex:  1 == 247   1 == 3   1 == 2 
## colvarindex:  1 == 247   1 == 4   1 == 1 
## colvarindex:  1 == 247   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  248 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 248   1 == 1   1 == 1 
## colvarindex:  1 == 248   1 == 1   1 == 2 
## colvarindex:  1 == 248   1 == 2   1 == 1 
## colvarindex:  1 == 248   1 == 2   1 == 2 
## colvarindex:  1 == 248   1 == 3   1 == 1 
## colvarindex:  1 == 248   1 == 3   1 == 2 
## colvarindex:  1 == 248   1 == 4   1 == 1 
## colvarindex:  1 == 248   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  249 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 249   1 == 1   1 == 1 
## colvarindex:  1 == 249   1 == 1   1 == 2 
## colvarindex:  1 == 249   1 == 2   1 == 1 
## colvarindex:  1 == 249   1 == 2   1 == 2 
## colvarindex:  1 == 249   1 == 3   1 == 1 
## colvarindex:  1 == 249   1 == 3   1 == 2 
## colvarindex:  1 == 249   1 == 4   1 == 1 
## colvarindex:  1 == 249   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  250 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 250   1 == 1   1 == 1 
## colvarindex:  1 == 250   1 == 1   1 == 2 
## colvarindex:  1 == 250   1 == 2   1 == 1 
## colvarindex:  1 == 250   1 == 2   1 == 2 
## colvarindex:  1 == 250   1 == 3   1 == 1 
## colvarindex:  1 == 250   1 == 3   1 == 2 
## colvarindex:  1 == 250   1 == 4   1 == 1 
## colvarindex:  1 == 250   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  251 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 251   1 == 1   1 == 1 
## colvarindex:  1 == 251   1 == 1   1 == 2 
## colvarindex:  1 == 251   1 == 2   1 == 1 
## colvarindex:  1 == 251   1 == 2   1 == 2 
## colvarindex:  1 == 251   1 == 3   1 == 1 
## colvarindex:  1 == 251   1 == 3   1 == 2 
## colvarindex:  1 == 251   1 == 4   1 == 1 
## colvarindex:  1 == 251   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  252 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 252   1 == 1   1 == 1 
## colvarindex:  1 == 252   1 == 1   1 == 2 
## colvarindex:  1 == 252   1 == 2   1 == 1 
## colvarindex:  1 == 252   1 == 2   1 == 2 
## colvarindex:  1 == 252   1 == 3   1 == 1 
## colvarindex:  1 == 252   1 == 3   1 == 2 
## colvarindex:  1 == 252   1 == 4   1 == 1 
## colvarindex:  1 == 252   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  253 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 253   1 == 1   1 == 1 
## colvarindex:  1 == 253   1 == 1   1 == 2 
## colvarindex:  1 == 253   1 == 2   1 == 1 
## colvarindex:  1 == 253   1 == 2   1 == 2 
## colvarindex:  1 == 253   1 == 3   1 == 1 
## colvarindex:  1 == 253   1 == 3   1 == 2 
## colvarindex:  1 == 253   1 == 4   1 == 1 
## colvarindex:  1 == 253   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  254 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 254   1 == 1   1 == 1 
## colvarindex:  1 == 254   1 == 1   1 == 2 
## colvarindex:  1 == 254   1 == 2   1 == 1 
## colvarindex:  1 == 254   1 == 2   1 == 2 
## colvarindex:  1 == 254   1 == 3   1 == 1 
## colvarindex:  1 == 254   1 == 3   1 == 2 
## colvarindex:  1 == 254   1 == 4   1 == 1 
## colvarindex:  1 == 254   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  255 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 255   1 == 1   1 == 1 
## colvarindex:  1 == 255   1 == 1   1 == 2 
## colvarindex:  1 == 255   1 == 2   1 == 1 
## colvarindex:  1 == 255   1 == 2   1 == 2 
## colvarindex:  1 == 255   1 == 3   1 == 1 
## colvarindex:  1 == 255   1 == 3   1 == 2 
## colvarindex:  1 == 255   1 == 4   1 == 1 
## colvarindex:  1 == 255   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  256 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 256   1 == 1   1 == 1 
## colvarindex:  1 == 256   1 == 1   1 == 2 
## colvarindex:  1 == 256   1 == 2   1 == 1 
## colvarindex:  1 == 256   1 == 2   1 == 2 
## colvarindex:  1 == 256   1 == 3   1 == 1 
## colvarindex:  1 == 256   1 == 3   1 == 2 
## colvarindex:  1 == 256   1 == 4   1 == 1 
## colvarindex:  1 == 256   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  257 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 257   1 == 1   1 == 1 
## colvarindex:  1 == 257   1 == 1   1 == 2 
## colvarindex:  1 == 257   1 == 2   1 == 1 
## colvarindex:  1 == 257   1 == 2   1 == 2 
## colvarindex:  1 == 257   1 == 3   1 == 1 
## colvarindex:  1 == 257   1 == 3   1 == 2 
## colvarindex:  1 == 257   1 == 4   1 == 1 
## colvarindex:  1 == 257   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  258 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 258   1 == 1   1 == 1 
## colvarindex:  1 == 258   1 == 1   1 == 2 
## colvarindex:  1 == 258   1 == 2   1 == 1 
## colvarindex:  1 == 258   1 == 2   1 == 2 
## colvarindex:  1 == 258   1 == 3   1 == 1 
## colvarindex:  1 == 258   1 == 3   1 == 2 
## colvarindex:  1 == 258   1 == 4   1 == 1 
## colvarindex:  1 == 258   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  259 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 259   1 == 1   1 == 1 
## colvarindex:  1 == 259   1 == 1   1 == 2 
## colvarindex:  1 == 259   1 == 2   1 == 1 
## colvarindex:  1 == 259   1 == 2   1 == 2 
## colvarindex:  1 == 259   1 == 3   1 == 1 
## colvarindex:  1 == 259   1 == 3   1 == 2 
## colvarindex:  1 == 259   1 == 4   1 == 1 
## colvarindex:  1 == 259   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  260 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 260   1 == 1   1 == 1 
## colvarindex:  1 == 260   1 == 1   1 == 2 
## colvarindex:  1 == 260   1 == 2   1 == 1 
## colvarindex:  1 == 260   1 == 2   1 == 2 
## colvarindex:  1 == 260   1 == 3   1 == 1 
## colvarindex:  1 == 260   1 == 3   1 == 2 
## colvarindex:  1 == 260   1 == 4   1 == 1 
## colvarindex:  1 == 260   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  261 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 261   1 == 1   1 == 1 
## colvarindex:  1 == 261   1 == 1   1 == 2 
## colvarindex:  1 == 261   1 == 2   1 == 1 
## colvarindex:  1 == 261   1 == 2   1 == 2 
## colvarindex:  1 == 261   1 == 3   1 == 1 
## colvarindex:  1 == 261   1 == 3   1 == 2 
## colvarindex:  1 == 261   1 == 4   1 == 1 
## colvarindex:  1 == 261   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  262 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 262   1 == 1   1 == 1 
## colvarindex:  1 == 262   1 == 1   1 == 2 
## colvarindex:  1 == 262   1 == 2   1 == 1 
## colvarindex:  1 == 262   1 == 2   1 == 2 
## colvarindex:  1 == 262   1 == 3   1 == 1 
## colvarindex:  1 == 262   1 == 3   1 == 2 
## colvarindex:  1 == 262   1 == 4   1 == 1 
## colvarindex:  1 == 262   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  263 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 263   1 == 1   1 == 1 
## colvarindex:  1 == 263   1 == 1   1 == 2 
## colvarindex:  1 == 263   1 == 2   1 == 1 
## colvarindex:  1 == 263   1 == 2   1 == 2 
## colvarindex:  1 == 263   1 == 3   1 == 1 
## colvarindex:  1 == 263   1 == 3   1 == 2 
## colvarindex:  1 == 263   1 == 4   1 == 1 
## colvarindex:  1 == 263   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  264 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 264   1 == 1   1 == 1 
## colvarindex:  1 == 264   1 == 1   1 == 2 
## colvarindex:  1 == 264   1 == 2   1 == 1 
## colvarindex:  1 == 264   1 == 2   1 == 2 
## colvarindex:  1 == 264   1 == 3   1 == 1 
## colvarindex:  1 == 264   1 == 3   1 == 2 
## colvarindex:  1 == 264   1 == 4   1 == 1 
## colvarindex:  1 == 264   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  265 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 265   1 == 1   1 == 1 
## colvarindex:  1 == 265   1 == 1   1 == 2 
## colvarindex:  1 == 265   1 == 2   1 == 1 
## colvarindex:  1 == 265   1 == 2   1 == 2 
## colvarindex:  1 == 265   1 == 3   1 == 1 
## colvarindex:  1 == 265   1 == 3   1 == 2 
## colvarindex:  1 == 265   1 == 4   1 == 1 
## colvarindex:  1 == 265   1 == 4   1 == 2 
## End of for, or  2 
## Data rows: Row  266 , observation (or)  2 , rowidname aedecodvalue , contents:  _ALL_ 
## colvarindex:  1 == 266   1 == 1   1 == 1 
## colvarindex:  1 == 266   1 == 1   1 == 2 
## colvarindex:  1 == 266   1 == 2   1 == 1 
## colvarindex:  1 == 266   1 == 2   1 == 2 
## colvarindex:  1 == 266   1 == 3   1 == 1 
## colvarindex:  1 == 266   1 == 3   1 == 2 
## colvarindex:  1 == 266   1 == 4   1 == 1 
## colvarindex:  1 == 266   1 == 4   1 == 2 
## End of for, or  2
```

```r
cat("HTML stored as: ", normalizePath(resHtmlFile), "\n")
```

```
## HTML stored as:  /home/ma/R/x86_64-redhat-linux-gnu-library/3.2/rrdfqbpresent/extdata/sample-html/DC-AE-sample.html
```

## Create DEMO html example


```r
dataCubeFile<- system.file("extdata/sample-rdf", "DC-DEMO-sample.ttl", package="rrdfqbcrndex")
htmlfile<- file.path(system.file("extdata/sample-html", package="rrdfqbpresent"), "DC-DEMO-sample.html")
coldim<- c("crnd-attribute:colno", "crnd-attribute:cellpartno", "crnd-dimension:trt01a",
           "crnd-dimension:factor", "crnd-dimension:procedure" )
rowdim<- c("crnd-attribute:rowno", "crnd-dimension:agegr1", "crnd-dimension:race",
           "crnd-dimension:ethnic", "crnd-dimension:sex" )
idrow<-  c( "agegr1value", "racevalue", "ethnicvalue", "sexvalue" )
idcol<-  c( "crnd-dimension:trt01a" )
resHtmlFile<- MakeTable( dataCubeFile, htmlfile, rowdim, coldim, idrow, idcol )
```

```
## Loading  /home/ma/R/x86_64-redhat-linux-gnu-library/3.2/rrdfqbcrndex/extdata/sample-rdf/DC-DEMO-sample.ttl 
## [1] "Number of triples: 3094"
##  [1] "1"  "2"  "3"  "4"  "5"  "6"  "7"  "8"  "9"  "10" "11" "18" "19" "20"
## [15] "21" "22" "23" "24" "25" "26" "27" "28" "29" "30" "31" "32" "33" "36"
## [29] "38" "40"
## [1] "1" "2" "3"
## [1] "1" "2"
##              s rowno colno cellpartno
## 9    ds:obs001     1     1          1
## 10   ds:obs001     1     1          1
## 11   ds:obs001     1     1          1
## 12   ds:obs001     1     1          1
## 21   ds:obs004     1     1          2
## 22   ds:obs004     1     1          2
## 23   ds:obs004     1     1          2
## 24   ds:obs004     1     1          2
## 33   ds:obs002     1     2          1
## 34   ds:obs002     1     2          1
## 35   ds:obs002     1     2          1
## 36   ds:obs002     1     2          1
## 45   ds:obs005     1     2          2
## 46   ds:obs005     1     2          2
## 47   ds:obs005     1     2          2
## 48   ds:obs005     1     2          2
## 57   ds:obs003     1     3          1
## 58   ds:obs003     1     3          1
## 59   ds:obs003     1     3          1
## 60   ds:obs003     1     3          1
## 69   ds:obs006     1     3          2
## 70   ds:obs006     1     3          2
## 71   ds:obs006     1     3          2
## 72   ds:obs006     1     3          2
## 339  ds:obs007     2     1          1
## 340  ds:obs007     2     1          1
## 341  ds:obs007     2     1          1
## 342  ds:obs007     2     1          1
## 343  ds:obs007     2     1          1
## 344  ds:obs007     2     1          1
## 345  ds:obs007     2     1          1
## 346  ds:obs007     2     1          1
## 355  ds:obs010     2     1          2
## 356  ds:obs010     2     1          2
## 357  ds:obs010     2     1          2
## 358  ds:obs010     2     1          2
## 359  ds:obs010     2     1          2
## 360  ds:obs010     2     1          2
## 361  ds:obs010     2     1          2
## 362  ds:obs010     2     1          2
## 371  ds:obs008     2     2          1
## 372  ds:obs008     2     2          1
## 373  ds:obs008     2     2          1
## 374  ds:obs008     2     2          1
## 375  ds:obs008     2     2          1
## 376  ds:obs008     2     2          1
## 377  ds:obs008     2     2          1
## 378  ds:obs008     2     2          1
## 387  ds:obs011     2     2          2
## 388  ds:obs011     2     2          2
## 389  ds:obs011     2     2          2
## 390  ds:obs011     2     2          2
## 391  ds:obs011     2     2          2
## 392  ds:obs011     2     2          2
## 393  ds:obs011     2     2          2
## 394  ds:obs011     2     2          2
## 403  ds:obs009     2     3          1
## 404  ds:obs009     2     3          1
## 405  ds:obs009     2     3          1
## 406  ds:obs009     2     3          1
## 407  ds:obs009     2     3          1
## 408  ds:obs009     2     3          1
## 409  ds:obs009     2     3          1
## 410  ds:obs009     2     3          1
## 419  ds:obs012     2     3          2
## 420  ds:obs012     2     3          2
## 421  ds:obs012     2     3          2
## 422  ds:obs012     2     3          2
## 423  ds:obs012     2     3          2
## 424  ds:obs012     2     3          2
## 425  ds:obs012     2     3          2
## 426  ds:obs012     2     3          2
## 1167 ds:obs013     3     1          1
## 1168 ds:obs013     3     1          1
## 1169 ds:obs013     3     1          1
## 1170 ds:obs013     3     1          1
## 1171 ds:obs013     3     1          1
## 1172 ds:obs013     3     1          1
## 1173 ds:obs013     3     1          1
## 1174 ds:obs013     3     1          1
## 1183 ds:obs016     3     1          2
## 1184 ds:obs016     3     1          2
## 1185 ds:obs016     3     1          2
## 1186 ds:obs016     3     1          2
## 1187 ds:obs016     3     1          2
## 1188 ds:obs016     3     1          2
## 1189 ds:obs016     3     1          2
## 1190 ds:obs016     3     1          2
## 1199 ds:obs014     3     2          1
## 1200 ds:obs014     3     2          1
## 1201 ds:obs014     3     2          1
## 1202 ds:obs014     3     2          1
## 1203 ds:obs014     3     2          1
## 1204 ds:obs014     3     2          1
## 1205 ds:obs014     3     2          1
## 1206 ds:obs014     3     2          1
## 1215 ds:obs017     3     2          2
## 1216 ds:obs017     3     2          2
## 1217 ds:obs017     3     2          2
## 1218 ds:obs017     3     2          2
## 1219 ds:obs017     3     2          2
## 1220 ds:obs017     3     2          2
## 1221 ds:obs017     3     2          2
## 1222 ds:obs017     3     2          2
## 1231 ds:obs015     3     3          1
## 1232 ds:obs015     3     3          1
## 1233 ds:obs015     3     3          1
## 1234 ds:obs015     3     3          1
## 1235 ds:obs015     3     3          1
## 1236 ds:obs015     3     3          1
## 1237 ds:obs015     3     3          1
## 1238 ds:obs015     3     3          1
## 1247 ds:obs018     3     3          2
## 1248 ds:obs018     3     3          2
## 1249 ds:obs018     3     3          2
## 1250 ds:obs018     3     3          2
## 1251 ds:obs018     3     3          2
## 1252 ds:obs018     3     3          2
## 1253 ds:obs018     3     3          2
## 1254 ds:obs018     3     3          2
## 1646 ds:obs019     4     1          1
## 1647 ds:obs019     4     1          1
## 1648 ds:obs019     4     1          1
## 1649 ds:obs019     4     1          1
## 1667 ds:obs020     4     2          1
## 1668 ds:obs020     4     2          1
## 1669 ds:obs020     4     2          1
## 1670 ds:obs020     4     2          1
## 1688 ds:obs021     4     3          1
## 1689 ds:obs021     4     3          1
## 1690 ds:obs021     4     3          1
## 1691 ds:obs021     4     3          1
## 1766 ds:obs022     5     1          1
## 1767 ds:obs022     5     1          1
## 1768 ds:obs022     5     1          1
## 1769 ds:obs022     5     1          1
## 1787 ds:obs023     5     2          1
## 1788 ds:obs023     5     2          1
## 1789 ds:obs023     5     2          1
## 1790 ds:obs023     5     2          1
## 1808 ds:obs024     5     3          1
## 1809 ds:obs024     5     3          1
## 1810 ds:obs024     5     3          1
## 1811 ds:obs024     5     3          1
## 1827 ds:obs025     6     1          1
## 1828 ds:obs025     6     1          1
## 1829 ds:obs025     6     1          1
## 1830 ds:obs025     6     1          1
## 1848 ds:obs026     6     2          1
## 1849 ds:obs026     6     2          1
## 1850 ds:obs026     6     2          1
## 1851 ds:obs026     6     2          1
## 1869 ds:obs027     6     3          1
## 1870 ds:obs027     6     3          1
## 1871 ds:obs027     6     3          1
## 1872 ds:obs027     6     3          1
## 1889 ds:obs028     7     1          1
## 1890 ds:obs028     7     1          1
## 1891 ds:obs028     7     1          1
## 1892 ds:obs028     7     1          1
## 1910 ds:obs029     7     2          1
## 1911 ds:obs029     7     2          1
## 1912 ds:obs029     7     2          1
## 1913 ds:obs029     7     2          1
## 1931 ds:obs030     7     3          1
## 1932 ds:obs030     7     3          1
## 1933 ds:obs030     7     3          1
## 1934 ds:obs030     7     3          1
## 1957 ds:obs031     8     1          1
## 1958 ds:obs031     8     1          1
## 1959 ds:obs031     8     1          1
## 1960 ds:obs031     8     1          1
## 1978 ds:obs032     8     2          1
## 1979 ds:obs032     8     2          1
## 1980 ds:obs032     8     2          1
## 1981 ds:obs032     8     2          1
## 1999 ds:obs033     8     3          1
## 2000 ds:obs033     8     3          1
## 2001 ds:obs033     8     3          1
## 2002 ds:obs033     8     3          1
## 2019 ds:obs034     9     1          1
## 2020 ds:obs034     9     1          1
## 2021 ds:obs034     9     1          1
## 2022 ds:obs034     9     1          1
## 2040 ds:obs035     9     2          1
## 2041 ds:obs035     9     2          1
## 2042 ds:obs035     9     2          1
## 2043 ds:obs035     9     2          1
## 2061 ds:obs036     9     3          1
## 2062 ds:obs036     9     3          1
## 2063 ds:obs036     9     3          1
## 2064 ds:obs036     9     3          1
## 73   ds:obs037    10     1          1
## 74   ds:obs037    10     1          1
## 75   ds:obs037    10     1          1
## 76   ds:obs037    10     1          1
## 94   ds:obs038    10     2          1
## 95   ds:obs038    10     2          1
## 96   ds:obs038    10     2          1
## 97   ds:obs038    10     2          1
## 115  ds:obs039    10     3          1
## 116  ds:obs039    10     3          1
## 117  ds:obs039    10     3          1
## 118  ds:obs039    10     3          1
## 139  ds:obs040    11     1          1
## 140  ds:obs040    11     1          1
## 141  ds:obs040    11     1          1
## 142  ds:obs040    11     1          1
## 160  ds:obs041    11     2          1
## 161  ds:obs041    11     2          1
## 162  ds:obs041    11     2          1
## 163  ds:obs041    11     2          1
## 181  ds:obs042    11     3          1
## 182  ds:obs042    11     3          1
## 183  ds:obs042    11     3          1
## 184  ds:obs042    11     3          1
## 207  ds:obs043    18     1          1
## 208  ds:obs043    18     1          1
## 209  ds:obs043    18     1          1
## 210  ds:obs043    18     1          1
## 219  ds:obs046    18     1          2
## 220  ds:obs046    18     1          2
## 221  ds:obs046    18     1          2
## 222  ds:obs046    18     1          2
## 231  ds:obs044    18     2          1
## 232  ds:obs044    18     2          1
## 233  ds:obs044    18     2          1
## 234  ds:obs044    18     2          1
## 243  ds:obs047    18     2          2
## 244  ds:obs047    18     2          2
## 245  ds:obs047    18     2          2
## 246  ds:obs047    18     2          2
## 255  ds:obs045    18     3          1
## 256  ds:obs045    18     3          1
## 257  ds:obs045    18     3          1
## 258  ds:obs045    18     3          1
## 267  ds:obs048    18     3          2
## 268  ds:obs048    18     3          2
## 269  ds:obs048    18     3          2
## 270  ds:obs048    18     3          2
## 279  ds:obs049    19     1          1
## 280  ds:obs049    19     1          1
## 289  ds:obs052    19     1          2
## 290  ds:obs052    19     1          2
## 299  ds:obs050    19     2          1
## 300  ds:obs050    19     2          1
## 309  ds:obs053    19     2          2
## 310  ds:obs053    19     2          2
## 319  ds:obs051    19     3          1
## 320  ds:obs051    19     3          1
## 329  ds:obs054    19     3          2
## 330  ds:obs054    19     3          2
## 435  ds:obs055    20     1          1
## 436  ds:obs055    20     1          1
## 445  ds:obs058    20     1          2
## 446  ds:obs058    20     1          2
## 455  ds:obs056    20     2          1
## 456  ds:obs056    20     2          1
## 465  ds:obs059    20     2          2
## 466  ds:obs059    20     2          2
## 475  ds:obs057    20     3          1
## 476  ds:obs057    20     3          1
## 485  ds:obs060    20     3          2
## 486  ds:obs060    20     3          2
## 495  ds:obs061    21     1          1
## 496  ds:obs061    21     1          1
## 505  ds:obs064    21     1          2
## 506  ds:obs064    21     1          2
## 515  ds:obs062    21     2          1
## 516  ds:obs062    21     2          1
## 525  ds:obs065    21     2          2
## 526  ds:obs065    21     2          2
## 535  ds:obs063    21     3          1
## 536  ds:obs063    21     3          1
## 545  ds:obs066    21     3          2
## 546  ds:obs066    21     3          2
## 555  ds:obs067    22     1          1
## 556  ds:obs067    22     1          1
## 557  ds:obs067    22     1          1
## 558  ds:obs067    22     1          1
## 567  ds:obs070    22     1          2
## 568  ds:obs070    22     1          2
## 569  ds:obs070    22     1          2
## 570  ds:obs070    22     1          2
## 579  ds:obs068    22     2          1
## 580  ds:obs068    22     2          1
## 581  ds:obs068    22     2          1
## 582  ds:obs068    22     2          1
## 591  ds:obs071    22     2          2
## 592  ds:obs071    22     2          2
## 593  ds:obs071    22     2          2
## 594  ds:obs071    22     2          2
## 603  ds:obs069    22     3          1
## 604  ds:obs069    22     3          1
## 605  ds:obs069    22     3          1
## 606  ds:obs069    22     3          1
## 615  ds:obs072    22     3          2
## 616  ds:obs072    22     3          2
## 617  ds:obs072    22     3          2
## 618  ds:obs072    22     3          2
## 627  ds:obs073    23     1          1
## 628  ds:obs073    23     1          1
## 629  ds:obs073    23     1          1
## 630  ds:obs073    23     1          1
## 631  ds:obs073    23     1          1
## 632  ds:obs073    23     1          1
## 633  ds:obs073    23     1          1
## 634  ds:obs073    23     1          1
## 643  ds:obs076    23     1          2
## 644  ds:obs076    23     1          2
## 645  ds:obs076    23     1          2
## 646  ds:obs076    23     1          2
## 647  ds:obs076    23     1          2
## 648  ds:obs076    23     1          2
## 649  ds:obs076    23     1          2
## 650  ds:obs076    23     1          2
## 659  ds:obs074    23     2          1
## 660  ds:obs074    23     2          1
## 661  ds:obs074    23     2          1
## 662  ds:obs074    23     2          1
## 663  ds:obs074    23     2          1
## 664  ds:obs074    23     2          1
## 665  ds:obs074    23     2          1
## 666  ds:obs074    23     2          1
## 675  ds:obs077    23     2          2
## 676  ds:obs077    23     2          2
## 677  ds:obs077    23     2          2
## 678  ds:obs077    23     2          2
## 679  ds:obs077    23     2          2
## 680  ds:obs077    23     2          2
## 681  ds:obs077    23     2          2
## 682  ds:obs077    23     2          2
## 691  ds:obs075    23     3          1
## 692  ds:obs075    23     3          1
## 693  ds:obs075    23     3          1
## 694  ds:obs075    23     3          1
## 695  ds:obs075    23     3          1
## 696  ds:obs075    23     3          1
## 697  ds:obs075    23     3          1
## 698  ds:obs075    23     3          1
## 707  ds:obs078    23     3          2
## 708  ds:obs078    23     3          2
## 709  ds:obs078    23     3          2
## 710  ds:obs078    23     3          2
## 711  ds:obs078    23     3          2
## 712  ds:obs078    23     3          2
## 713  ds:obs078    23     3          2
## 714  ds:obs078    23     3          2
## 723  ds:obs079    24     1          1
## 724  ds:obs079    24     1          1
## 725  ds:obs079    24     1          1
## 726  ds:obs079    24     1          1
## 727  ds:obs079    24     1          1
## 728  ds:obs079    24     1          1
## 729  ds:obs079    24     1          1
## 730  ds:obs079    24     1          1
## 739  ds:obs082    24     1          2
## 740  ds:obs082    24     1          2
## 741  ds:obs082    24     1          2
## 742  ds:obs082    24     1          2
## 743  ds:obs082    24     1          2
## 744  ds:obs082    24     1          2
## 745  ds:obs082    24     1          2
## 746  ds:obs082    24     1          2
## 755  ds:obs080    24     2          1
## 756  ds:obs080    24     2          1
## 757  ds:obs080    24     2          1
## 758  ds:obs080    24     2          1
## 759  ds:obs080    24     2          1
## 760  ds:obs080    24     2          1
## 761  ds:obs080    24     2          1
## 762  ds:obs080    24     2          1
## 771  ds:obs083    24     2          2
## 772  ds:obs083    24     2          2
## 773  ds:obs083    24     2          2
## 774  ds:obs083    24     2          2
## 775  ds:obs083    24     2          2
## 776  ds:obs083    24     2          2
## 777  ds:obs083    24     2          2
## 778  ds:obs083    24     2          2
## 787  ds:obs081    24     3          1
## 788  ds:obs081    24     3          1
## 789  ds:obs081    24     3          1
## 790  ds:obs081    24     3          1
## 791  ds:obs081    24     3          1
## 792  ds:obs081    24     3          1
## 793  ds:obs081    24     3          1
## 794  ds:obs081    24     3          1
## 803  ds:obs084    24     3          2
## 804  ds:obs084    24     3          2
## 805  ds:obs084    24     3          2
## 806  ds:obs084    24     3          2
## 807  ds:obs084    24     3          2
## 808  ds:obs084    24     3          2
## 809  ds:obs084    24     3          2
## 810  ds:obs084    24     3          2
## 819  ds:obs085    25     1          1
## 820  ds:obs085    25     1          1
## 821  ds:obs085    25     1          1
## 822  ds:obs085    25     1          1
## 823  ds:obs085    25     1          1
## 824  ds:obs085    25     1          1
## 825  ds:obs085    25     1          1
## 826  ds:obs085    25     1          1
## 835  ds:obs088    25     1          2
## 836  ds:obs088    25     1          2
## 837  ds:obs088    25     1          2
## 838  ds:obs088    25     1          2
## 839  ds:obs088    25     1          2
## 840  ds:obs088    25     1          2
## 841  ds:obs088    25     1          2
## 842  ds:obs088    25     1          2
## 851  ds:obs086    25     2          1
## 852  ds:obs086    25     2          1
## 853  ds:obs086    25     2          1
## 854  ds:obs086    25     2          1
## 855  ds:obs086    25     2          1
## 856  ds:obs086    25     2          1
## 857  ds:obs086    25     2          1
## 858  ds:obs086    25     2          1
## 867  ds:obs089    25     2          2
## 868  ds:obs089    25     2          2
## 869  ds:obs089    25     2          2
## 870  ds:obs089    25     2          2
## 871  ds:obs089    25     2          2
## 872  ds:obs089    25     2          2
## 873  ds:obs089    25     2          2
## 874  ds:obs089    25     2          2
## 883  ds:obs087    25     3          1
## 884  ds:obs087    25     3          1
## 885  ds:obs087    25     3          1
## 886  ds:obs087    25     3          1
## 887  ds:obs087    25     3          1
## 888  ds:obs087    25     3          1
## 889  ds:obs087    25     3          1
## 890  ds:obs087    25     3          1
## 899  ds:obs090    25     3          2
## 900  ds:obs090    25     3          2
## 901  ds:obs090    25     3          2
## 902  ds:obs090    25     3          2
## 903  ds:obs090    25     3          2
## 904  ds:obs090    25     3          2
## 905  ds:obs090    25     3          2
## 906  ds:obs090    25     3          2
## 923  ds:obs091    26     1          1
## 924  ds:obs091    26     1          1
## 925  ds:obs091    26     1          1
## 926  ds:obs091    26     1          1
## 944  ds:obs092    26     2          1
## 945  ds:obs092    26     2          1
## 946  ds:obs092    26     2          1
## 947  ds:obs092    26     2          1
## 965  ds:obs093    26     3          1
## 966  ds:obs093    26     3          1
## 967  ds:obs093    26     3          1
## 968  ds:obs093    26     3          1
## 983  ds:obs094    27     1          1
## 984  ds:obs094    27     1          1
## 985  ds:obs094    27     1          1
## 986  ds:obs094    27     1          1
## 1004 ds:obs095    27     2          1
## 1005 ds:obs095    27     2          1
## 1006 ds:obs095    27     2          1
## 1007 ds:obs095    27     2          1
## 1025 ds:obs096    27     3          1
## 1026 ds:obs096    27     3          1
## 1027 ds:obs096    27     3          1
## 1028 ds:obs096    27     3          1
## 1044 ds:obs097    28     1          1
## 1045 ds:obs097    28     1          1
## 1046 ds:obs097    28     1          1
## 1047 ds:obs097    28     1          1
## 1065 ds:obs098    28     2          1
## 1066 ds:obs098    28     2          1
## 1067 ds:obs098    28     2          1
## 1068 ds:obs098    28     2          1
## 1086 ds:obs099    28     3          1
## 1087 ds:obs099    28     3          1
## 1088 ds:obs099    28     3          1
## 1089 ds:obs099    28     3          1
## 1106 ds:obs100    29     1          1
## 1107 ds:obs100    29     1          1
## 1108 ds:obs100    29     1          1
## 1109 ds:obs100    29     1          1
## 1127 ds:obs101    29     2          1
## 1128 ds:obs101    29     2          1
## 1129 ds:obs101    29     2          1
## 1130 ds:obs101    29     2          1
## 1148 ds:obs102    29     3          1
## 1149 ds:obs102    29     3          1
## 1150 ds:obs102    29     3          1
## 1151 ds:obs102    29     3          1
## 1270 ds:obs103    30     1          1
## 1271 ds:obs103    30     1          1
## 1272 ds:obs103    30     1          1
## 1273 ds:obs103    30     1          1
## 1291 ds:obs104    30     2          1
## 1292 ds:obs104    30     2          1
## 1293 ds:obs104    30     2          1
## 1294 ds:obs104    30     2          1
## 1312 ds:obs105    30     3          1
## 1313 ds:obs105    30     3          1
## 1314 ds:obs105    30     3          1
## 1315 ds:obs105    30     3          1
## 1332 ds:obs106    31     1          1
## 1333 ds:obs106    31     1          1
## 1334 ds:obs106    31     1          1
## 1335 ds:obs106    31     1          1
## 1353 ds:obs107    31     2          1
## 1354 ds:obs107    31     2          1
## 1355 ds:obs107    31     2          1
## 1356 ds:obs107    31     2          1
## 1374 ds:obs108    31     3          1
## 1375 ds:obs108    31     3          1
## 1376 ds:obs108    31     3          1
## 1377 ds:obs108    31     3          1
## 1390 ds:obs109    32     1          1
## 1391 ds:obs109    32     1          1
## 1392 ds:obs109    32     1          1
## 1393 ds:obs109    32     1          1
## 1411 ds:obs110    32     2          1
## 1412 ds:obs110    32     2          1
## 1413 ds:obs110    32     2          1
## 1414 ds:obs110    32     2          1
## 1432 ds:obs111    32     3          1
## 1433 ds:obs111    32     3          1
## 1434 ds:obs111    32     3          1
## 1435 ds:obs111    32     3          1
## 1456 ds:obs112    33     1          1
## 1457 ds:obs112    33     1          1
## 1458 ds:obs112    33     1          1
## 1459 ds:obs112    33     1          1
## 1477 ds:obs113    33     2          1
## 1478 ds:obs113    33     2          1
## 1479 ds:obs113    33     2          1
## 1480 ds:obs113    33     2          1
## 1498 ds:obs114    33     3          1
## 1499 ds:obs114    33     3          1
## 1500 ds:obs114    33     3          1
## 1501 ds:obs114    33     3          1
## 1515 ds:obs115    36     1          1
## 1516 ds:obs115    36     1          1
## 1517 ds:obs115    36     1          1
## 1518 ds:obs115    36     1          1
## 1527 ds:obs118    36     1          2
## 1528 ds:obs118    36     1          2
## 1529 ds:obs118    36     1          2
## 1530 ds:obs118    36     1          2
## 1539 ds:obs116    36     2          1
## 1540 ds:obs116    36     2          1
## 1541 ds:obs116    36     2          1
## 1542 ds:obs116    36     2          1
## 1551 ds:obs119    36     2          2
## 1552 ds:obs119    36     2          2
## 1553 ds:obs119    36     2          2
## 1554 ds:obs119    36     2          2
## 1563 ds:obs117    36     3          1
## 1564 ds:obs117    36     3          1
## 1565 ds:obs117    36     3          1
## 1566 ds:obs117    36     3          1
## 1575 ds:obs120    36     3          2
## 1576 ds:obs120    36     3          2
## 1577 ds:obs120    36     3          2
## 1578 ds:obs120    36     3          2
## 1587 ds:obs121    38     1          1
## 1588 ds:obs121    38     1          1
## 1597 ds:obs124    38     1          2
## 1598 ds:obs124    38     1          2
## 1607 ds:obs122    38     2          1
## 1608 ds:obs122    38     2          1
## 1617 ds:obs125    38     2          2
## 1618 ds:obs125    38     2          2
## 1627 ds:obs123    38     3          1
## 1628 ds:obs123    38     3          1
## 1637 ds:obs126    38     3          2
## 1638 ds:obs126    38     3          2
## 1710 ds:obs127    40     1          1
## 1711 ds:obs127    40     1          1
## 1720 ds:obs130    40     1          2
## 1721 ds:obs130    40     1          2
## 1730 ds:obs128    40     2          1
## 1731 ds:obs128    40     2          1
## 1740 ds:obs131    40     2          2
## 1741 ds:obs131    40     2          2
## 1750 ds:obs129    40     3          1
## 1751 ds:obs129    40     3          1
## 1760 ds:obs132    40     3          2
## 1761 ds:obs132    40     3          2
## Row  1 , observation (or)  1 , rowidname agegr1value , contents:  _ALL_ 
## Row  1 , observation (or)  1 , rowidname racevalue , contents:  _ALL_ 
## Row  1 , observation (or)  1 , rowidname ethnicvalue , contents:  _ALL_ 
## Row  1 , observation (or)  1 , rowidname sexvalue , contents:  _NONMISS_ 
## Row  2 , observation (or)  2 , rowidname agegr1value , contents:  _ALL_ 
## Row  2 , observation (or)  2 , rowidname racevalue , contents:  _ALL_ 
## Row  2 , observation (or)  2 , rowidname ethnicvalue , contents:  _ALL_ 
## Row  2 , observation (or)  2 , rowidname sexvalue , contents:  _NONMISS_ 
## Row  3 , observation (or)  2 , rowidname agegr1value , contents:  _ALL_ 
## Row  3 , observation (or)  2 , rowidname racevalue , contents:  _ALL_ 
## Row  3 , observation (or)  2 , rowidname ethnicvalue , contents:  _ALL_ 
## Row  3 , observation (or)  2 , rowidname sexvalue , contents:  _NONMISS_ 
## Row  4 , observation (or)  2 , rowidname agegr1value , contents:  _ALL_ 
## Row  4 , observation (or)  2 , rowidname racevalue , contents:  _ALL_ 
## Row  4 , observation (or)  2 , rowidname ethnicvalue , contents:  _ALL_ 
## Row  4 , observation (or)  2 , rowidname sexvalue , contents:  _NONMISS_ 
## Row  5 , observation (or)  2 , rowidname agegr1value , contents:  _ALL_ 
## Row  5 , observation (or)  2 , rowidname racevalue , contents:  _ALL_ 
## Row  5 , observation (or)  2 , rowidname ethnicvalue , contents:  _ALL_ 
## Row  5 , observation (or)  2 , rowidname sexvalue , contents:  _NONMISS_ 
## Row  6 , observation (or)  2 , rowidname agegr1value , contents:  _ALL_ 
## Row  6 , observation (or)  2 , rowidname racevalue , contents:  _ALL_ 
## Row  6 , observation (or)  2 , rowidname ethnicvalue , contents:  _ALL_ 
## Row  6 , observation (or)  2 , rowidname sexvalue , contents:  _NONMISS_ 
## Row  7 , observation (or)  2 , rowidname agegr1value , contents:  _ALL_ 
## Row  7 , observation (or)  2 , rowidname racevalue , contents:  _ALL_ 
## Row  7 , observation (or)  2 , rowidname ethnicvalue , contents:  _ALL_ 
## Row  7 , observation (or)  2 , rowidname sexvalue , contents:  _NONMISS_ 
## Row  8 , observation (or)  2 , rowidname agegr1value , contents:  _ALL_ 
## Row  8 , observation (or)  2 , rowidname racevalue , contents:  _ALL_ 
## Row  8 , observation (or)  2 , rowidname ethnicvalue , contents:  _ALL_ 
## Row  8 , observation (or)  2 , rowidname sexvalue , contents:  _NONMISS_ 
## Row  9 , observation (or)  2 , rowidname agegr1value , contents:  _ALL_ 
## Row  9 , observation (or)  2 , rowidname racevalue , contents:  _ALL_ 
## Row  9 , observation (or)  2 , rowidname ethnicvalue , contents:  _ALL_ 
## Row  9 , observation (or)  2 , rowidname sexvalue , contents:  _NONMISS_ 
## Row  10 , observation (or)  2 , rowidname agegr1value , contents:  _ALL_ 
## Row  10 , observation (or)  2 , rowidname racevalue , contents:  _ALL_ 
## Row  10 , observation (or)  2 , rowidname ethnicvalue , contents:  _ALL_ 
## Row  10 , observation (or)  2 , rowidname sexvalue , contents:  _NONMISS_ 
## Row  11 , observation (or)  2 , rowidname agegr1value , contents:  _ALL_ 
## Row  11 , observation (or)  2 , rowidname racevalue , contents:  _ALL_ 
## Row  11 , observation (or)  2 , rowidname ethnicvalue , contents:  _ALL_ 
## Row  11 , observation (or)  2 , rowidname sexvalue , contents:  _NONMISS_ 
## Row  18 , observation (or)  2 , rowidname agegr1value , contents:  _ALL_ 
## Row  18 , observation (or)  2 , rowidname racevalue , contents:  _ALL_ 
## Row  18 , observation (or)  2 , rowidname ethnicvalue , contents:  _ALL_ 
## Row  18 , observation (or)  2 , rowidname sexvalue , contents:  _NONMISS_ 
## Row  19 , observation (or)  2 , rowidname agegr1value , contents:  _ALL_ 
## Row  19 , observation (or)  2 , rowidname racevalue , contents:  _ALL_ 
## Row  19 , observation (or)  2 , rowidname ethnicvalue , contents:  _ALL_ 
## Row  19 , observation (or)  2 , rowidname sexvalue , contents:  _NONMISS_ 
## Row  20 , observation (or)  2 , rowidname agegr1value , contents:  _ALL_ 
## Row  20 , observation (or)  2 , rowidname racevalue , contents:  _ALL_ 
## Row  20 , observation (or)  2 , rowidname ethnicvalue , contents:  _ALL_ 
## Row  20 , observation (or)  2 , rowidname sexvalue , contents:  _NONMISS_ 
## Row  21 , observation (or)  2 , rowidname agegr1value , contents:  _ALL_ 
## Row  21 , observation (or)  2 , rowidname racevalue , contents:  _ALL_ 
## Row  21 , observation (or)  2 , rowidname ethnicvalue , contents:  _ALL_ 
## Row  21 , observation (or)  2 , rowidname sexvalue , contents:  _NONMISS_ 
## Row  22 , observation (or)  2 , rowidname agegr1value , contents:  _ALL_ 
## Row  22 , observation (or)  2 , rowidname racevalue , contents:  _ALL_ 
## Row  22 , observation (or)  2 , rowidname ethnicvalue , contents:  _ALL_ 
## Row  22 , observation (or)  2 , rowidname sexvalue , contents:  _NONMISS_ 
## Row  23 , observation (or)  2 , rowidname agegr1value , contents:  _ALL_ 
## Row  23 , observation (or)  2 , rowidname racevalue , contents:  _ALL_ 
## Row  23 , observation (or)  2 , rowidname ethnicvalue , contents:  _ALL_ 
## Row  23 , observation (or)  2 , rowidname sexvalue , contents:  _NONMISS_ 
## Row  24 , observation (or)  2 , rowidname agegr1value , contents:  _ALL_ 
## Row  24 , observation (or)  2 , rowidname racevalue , contents:  _ALL_ 
## Row  24 , observation (or)  2 , rowidname ethnicvalue , contents:  _ALL_ 
## Row  24 , observation (or)  2 , rowidname sexvalue , contents:  _NONMISS_ 
## Row  25 , observation (or)  2 , rowidname agegr1value , contents:  _ALL_ 
## Row  25 , observation (or)  2 , rowidname racevalue , contents:  _ALL_ 
## Row  25 , observation (or)  2 , rowidname ethnicvalue , contents:  _ALL_ 
## Row  25 , observation (or)  2 , rowidname sexvalue , contents:  _NONMISS_ 
## Row  26 , observation (or)  2 , rowidname agegr1value , contents:  _ALL_ 
## Row  26 , observation (or)  2 , rowidname racevalue , contents:  _ALL_ 
## Row  26 , observation (or)  2 , rowidname ethnicvalue , contents:  _ALL_ 
## Row  26 , observation (or)  2 , rowidname sexvalue , contents:  _NONMISS_ 
## Row  27 , observation (or)  2 , rowidname agegr1value , contents:  _ALL_ 
## Row  27 , observation (or)  2 , rowidname racevalue , contents:  _ALL_ 
## Row  27 , observation (or)  2 , rowidname ethnicvalue , contents:  _ALL_ 
## Row  27 , observation (or)  2 , rowidname sexvalue , contents:  _NONMISS_ 
## Row  28 , observation (or)  2 , rowidname agegr1value , contents:  _ALL_ 
## Row  28 , observation (or)  2 , rowidname racevalue , contents:  _ALL_ 
## Row  28 , observation (or)  2 , rowidname ethnicvalue , contents:  _ALL_ 
## Row  28 , observation (or)  2 , rowidname sexvalue , contents:  _NONMISS_ 
## Row  29 , observation (or)  2 , rowidname agegr1value , contents:  _ALL_ 
## Row  29 , observation (or)  2 , rowidname racevalue , contents:  _ALL_ 
## Row  29 , observation (or)  2 , rowidname ethnicvalue , contents:  _ALL_ 
## Row  29 , observation (or)  2 , rowidname sexvalue , contents:  _NONMISS_ 
## Row  30 , observation (or)  2 , rowidname agegr1value , contents:  _ALL_ 
## Row  30 , observation (or)  2 , rowidname racevalue , contents:  _ALL_ 
## Row  30 , observation (or)  2 , rowidname ethnicvalue , contents:  _ALL_ 
## Row  30 , observation (or)  2 , rowidname sexvalue , contents:  _NONMISS_ 
## Row  31 , observation (or)  2 , rowidname agegr1value , contents:  _ALL_ 
## Row  31 , observation (or)  2 , rowidname racevalue , contents:  _ALL_ 
## Row  31 , observation (or)  2 , rowidname ethnicvalue , contents:  _ALL_ 
## Row  31 , observation (or)  2 , rowidname sexvalue , contents:  _NONMISS_ 
## Row  32 , observation (or)  2 , rowidname agegr1value , contents:  _ALL_ 
## Row  32 , observation (or)  2 , rowidname racevalue , contents:  _ALL_ 
## Row  32 , observation (or)  2 , rowidname ethnicvalue , contents:  _ALL_ 
## Row  32 , observation (or)  2 , rowidname sexvalue , contents:  _NONMISS_ 
## Row  33 , observation (or)  2 , rowidname agegr1value , contents:  _ALL_ 
## Row  33 , observation (or)  2 , rowidname racevalue , contents:  _ALL_ 
## Row  33 , observation (or)  2 , rowidname ethnicvalue , contents:  _ALL_ 
## Row  33 , observation (or)  2 , rowidname sexvalue , contents:  _NONMISS_ 
## Row  36 , observation (or)  2 , rowidname agegr1value , contents:  _ALL_ 
## Row  36 , observation (or)  2 , rowidname racevalue , contents:  _ALL_ 
## Row  36 , observation (or)  2 , rowidname ethnicvalue , contents:  _ALL_ 
## Row  36 , observation (or)  2 , rowidname sexvalue , contents:  _NONMISS_ 
## Row  38 , observation (or)  2 , rowidname agegr1value , contents:  _ALL_ 
## Row  38 , observation (or)  2 , rowidname racevalue , contents:  _ALL_ 
## Row  38 , observation (or)  2 , rowidname ethnicvalue , contents:  _ALL_ 
## Row  38 , observation (or)  2 , rowidname sexvalue , contents:  _NONMISS_ 
## Row  40 , observation (or)  2 , rowidname agegr1value , contents:  _ALL_ 
## Row  40 , observation (or)  2 , rowidname racevalue , contents:  _ALL_ 
## Row  40 , observation (or)  2 , rowidname ethnicvalue , contents:  _ALL_ 
## Row  40 , observation (or)  2 , rowidname sexvalue , contents:  _NONMISS_ 
## Start data rows
## Data rows: Row  1 , observation (or)  1 , rowidname sexvalue , contents:  _NONMISS_ 
## colvarindex:  1 == 1   1 == 1   1 == 1 
## Observation:  86 
## colvarindex:  1 == 1   1 == 1   1 == 2 
## colvarindex:  1 == 1   1 == 2   1 == 1 
## colvarindex:  1 == 1   1 == 2   1 == 2 
## colvarindex:  1 == 1   1 == 3   1 == 1 
## colvarindex:  1 == 1   1 == 3   1 == 2 
## End of for, or  2 
## Data rows: Row  2 , observation (or)  2 , rowidname sexvalue , contents:  _NONMISS_ 
## colvarindex:  1 == 2   1 == 1   1 == 1 
## colvarindex:  1 == 2   1 == 1   1 == 2 
## colvarindex:  1 == 2   1 == 2   1 == 1 
## colvarindex:  1 == 2   1 == 2   1 == 2 
## colvarindex:  1 == 2   1 == 3   1 == 1 
## colvarindex:  1 == 2   1 == 3   1 == 2 
## End of for, or  2 
## Data rows: Row  3 , observation (or)  2 , rowidname sexvalue , contents:  _NONMISS_ 
## colvarindex:  1 == 3   1 == 1   1 == 1 
## colvarindex:  1 == 3   1 == 1   1 == 2 
## colvarindex:  1 == 3   1 == 2   1 == 1 
## colvarindex:  1 == 3   1 == 2   1 == 2 
## colvarindex:  1 == 3   1 == 3   1 == 1 
## colvarindex:  1 == 3   1 == 3   1 == 2 
## End of for, or  2 
## Data rows: Row  4 , observation (or)  2 , rowidname sexvalue , contents:  _NONMISS_ 
## colvarindex:  1 == 4   1 == 1   1 == 1 
## colvarindex:  1 == 4   1 == 1   1 == 2 
## colvarindex:  1 == 4   1 == 2   1 == 1 
## colvarindex:  1 == 4   1 == 2   1 == 2 
## colvarindex:  1 == 4   1 == 3   1 == 1 
## colvarindex:  1 == 4   1 == 3   1 == 2 
## End of for, or  2 
## Data rows: Row  5 , observation (or)  2 , rowidname sexvalue , contents:  _NONMISS_ 
## colvarindex:  1 == 5   1 == 1   1 == 1 
## colvarindex:  1 == 5   1 == 1   1 == 2 
## colvarindex:  1 == 5   1 == 2   1 == 1 
## colvarindex:  1 == 5   1 == 2   1 == 2 
## colvarindex:  1 == 5   1 == 3   1 == 1 
## colvarindex:  1 == 5   1 == 3   1 == 2 
## End of for, or  2 
## Data rows: Row  6 , observation (or)  2 , rowidname sexvalue , contents:  _NONMISS_ 
## colvarindex:  1 == 6   1 == 1   1 == 1 
## colvarindex:  1 == 6   1 == 1   1 == 2 
## colvarindex:  1 == 6   1 == 2   1 == 1 
## colvarindex:  1 == 6   1 == 2   1 == 2 
## colvarindex:  1 == 6   1 == 3   1 == 1 
## colvarindex:  1 == 6   1 == 3   1 == 2 
## End of for, or  2 
## Data rows: Row  7 , observation (or)  2 , rowidname sexvalue , contents:  _NONMISS_ 
## colvarindex:  1 == 7   1 == 1   1 == 1 
## colvarindex:  1 == 7   1 == 1   1 == 2 
## colvarindex:  1 == 7   1 == 2   1 == 1 
## colvarindex:  1 == 7   1 == 2   1 == 2 
## colvarindex:  1 == 7   1 == 3   1 == 1 
## colvarindex:  1 == 7   1 == 3   1 == 2 
## End of for, or  2 
## Data rows: Row  8 , observation (or)  2 , rowidname sexvalue , contents:  _NONMISS_ 
## colvarindex:  1 == 8   1 == 1   1 == 1 
## colvarindex:  1 == 8   1 == 1   1 == 2 
## colvarindex:  1 == 8   1 == 2   1 == 1 
## colvarindex:  1 == 8   1 == 2   1 == 2 
## colvarindex:  1 == 8   1 == 3   1 == 1 
## colvarindex:  1 == 8   1 == 3   1 == 2 
## End of for, or  2 
## Data rows: Row  9 , observation (or)  2 , rowidname sexvalue , contents:  _NONMISS_ 
## colvarindex:  1 == 9   1 == 1   1 == 1 
## colvarindex:  1 == 9   1 == 1   1 == 2 
## colvarindex:  1 == 9   1 == 2   1 == 1 
## colvarindex:  1 == 9   1 == 2   1 == 2 
## colvarindex:  1 == 9   1 == 3   1 == 1 
## colvarindex:  1 == 9   1 == 3   1 == 2 
## End of for, or  2 
## Data rows: Row  10 , observation (or)  2 , rowidname sexvalue , contents:  _NONMISS_ 
## colvarindex:  1 == 10   1 == 1   1 == 1 
## colvarindex:  1 == 10   1 == 1   1 == 2 
## colvarindex:  1 == 10   1 == 2   1 == 1 
## colvarindex:  1 == 10   1 == 2   1 == 2 
## colvarindex:  1 == 10   1 == 3   1 == 1 
## colvarindex:  1 == 10   1 == 3   1 == 2 
## End of for, or  2 
## Data rows: Row  11 , observation (or)  2 , rowidname sexvalue , contents:  _NONMISS_ 
## colvarindex:  1 == 11   1 == 1   1 == 1 
## colvarindex:  1 == 11   1 == 1   1 == 2 
## colvarindex:  1 == 11   1 == 2   1 == 1 
## colvarindex:  1 == 11   1 == 2   1 == 2 
## colvarindex:  1 == 11   1 == 3   1 == 1 
## colvarindex:  1 == 11   1 == 3   1 == 2 
## End of for, or  2 
## Data rows: Row  18 , observation (or)  2 , rowidname sexvalue , contents:  _NONMISS_ 
## colvarindex:  1 == 18   1 == 1   1 == 1 
## colvarindex:  1 == 18   1 == 1   1 == 2 
## colvarindex:  1 == 18   1 == 2   1 == 1 
## colvarindex:  1 == 18   1 == 2   1 == 2 
## colvarindex:  1 == 18   1 == 3   1 == 1 
## colvarindex:  1 == 18   1 == 3   1 == 2 
## End of for, or  2 
## Data rows: Row  19 , observation (or)  2 , rowidname sexvalue , contents:  _NONMISS_ 
## colvarindex:  1 == 19   1 == 1   1 == 1 
## colvarindex:  1 == 19   1 == 1   1 == 2 
## colvarindex:  1 == 19   1 == 2   1 == 1 
## colvarindex:  1 == 19   1 == 2   1 == 2 
## colvarindex:  1 == 19   1 == 3   1 == 1 
## colvarindex:  1 == 19   1 == 3   1 == 2 
## End of for, or  2 
## Data rows: Row  20 , observation (or)  2 , rowidname sexvalue , contents:  _NONMISS_ 
## colvarindex:  1 == 20   1 == 1   1 == 1 
## colvarindex:  1 == 20   1 == 1   1 == 2 
## colvarindex:  1 == 20   1 == 2   1 == 1 
## colvarindex:  1 == 20   1 == 2   1 == 2 
## colvarindex:  1 == 20   1 == 3   1 == 1 
## colvarindex:  1 == 20   1 == 3   1 == 2 
## End of for, or  2 
## Data rows: Row  21 , observation (or)  2 , rowidname sexvalue , contents:  _NONMISS_ 
## colvarindex:  1 == 21   1 == 1   1 == 1 
## colvarindex:  1 == 21   1 == 1   1 == 2 
## colvarindex:  1 == 21   1 == 2   1 == 1 
## colvarindex:  1 == 21   1 == 2   1 == 2 
## colvarindex:  1 == 21   1 == 3   1 == 1 
## colvarindex:  1 == 21   1 == 3   1 == 2 
## End of for, or  2 
## Data rows: Row  22 , observation (or)  2 , rowidname sexvalue , contents:  _NONMISS_ 
## colvarindex:  1 == 22   1 == 1   1 == 1 
## colvarindex:  1 == 22   1 == 1   1 == 2 
## colvarindex:  1 == 22   1 == 2   1 == 1 
## colvarindex:  1 == 22   1 == 2   1 == 2 
## colvarindex:  1 == 22   1 == 3   1 == 1 
## colvarindex:  1 == 22   1 == 3   1 == 2 
## End of for, or  2 
## Data rows: Row  23 , observation (or)  2 , rowidname sexvalue , contents:  _NONMISS_ 
## colvarindex:  1 == 23   1 == 1   1 == 1 
## colvarindex:  1 == 23   1 == 1   1 == 2 
## colvarindex:  1 == 23   1 == 2   1 == 1 
## colvarindex:  1 == 23   1 == 2   1 == 2 
## colvarindex:  1 == 23   1 == 3   1 == 1 
## colvarindex:  1 == 23   1 == 3   1 == 2 
## End of for, or  2 
## Data rows: Row  24 , observation (or)  2 , rowidname sexvalue , contents:  _NONMISS_ 
## colvarindex:  1 == 24   1 == 1   1 == 1 
## colvarindex:  1 == 24   1 == 1   1 == 2 
## colvarindex:  1 == 24   1 == 2   1 == 1 
## colvarindex:  1 == 24   1 == 2   1 == 2 
## colvarindex:  1 == 24   1 == 3   1 == 1 
## colvarindex:  1 == 24   1 == 3   1 == 2 
## End of for, or  2 
## Data rows: Row  25 , observation (or)  2 , rowidname sexvalue , contents:  _NONMISS_ 
## colvarindex:  1 == 25   1 == 1   1 == 1 
## colvarindex:  1 == 25   1 == 1   1 == 2 
## colvarindex:  1 == 25   1 == 2   1 == 1 
## colvarindex:  1 == 25   1 == 2   1 == 2 
## colvarindex:  1 == 25   1 == 3   1 == 1 
## colvarindex:  1 == 25   1 == 3   1 == 2 
## End of for, or  2 
## Data rows: Row  26 , observation (or)  2 , rowidname sexvalue , contents:  _NONMISS_ 
## colvarindex:  1 == 26   1 == 1   1 == 1 
## colvarindex:  1 == 26   1 == 1   1 == 2 
## colvarindex:  1 == 26   1 == 2   1 == 1 
## colvarindex:  1 == 26   1 == 2   1 == 2 
## colvarindex:  1 == 26   1 == 3   1 == 1 
## colvarindex:  1 == 26   1 == 3   1 == 2 
## End of for, or  2 
## Data rows: Row  27 , observation (or)  2 , rowidname sexvalue , contents:  _NONMISS_ 
## colvarindex:  1 == 27   1 == 1   1 == 1 
## colvarindex:  1 == 27   1 == 1   1 == 2 
## colvarindex:  1 == 27   1 == 2   1 == 1 
## colvarindex:  1 == 27   1 == 2   1 == 2 
## colvarindex:  1 == 27   1 == 3   1 == 1 
## colvarindex:  1 == 27   1 == 3   1 == 2 
## End of for, or  2 
## Data rows: Row  28 , observation (or)  2 , rowidname sexvalue , contents:  _NONMISS_ 
## colvarindex:  1 == 28   1 == 1   1 == 1 
## colvarindex:  1 == 28   1 == 1   1 == 2 
## colvarindex:  1 == 28   1 == 2   1 == 1 
## colvarindex:  1 == 28   1 == 2   1 == 2 
## colvarindex:  1 == 28   1 == 3   1 == 1 
## colvarindex:  1 == 28   1 == 3   1 == 2 
## End of for, or  2 
## Data rows: Row  29 , observation (or)  2 , rowidname sexvalue , contents:  _NONMISS_ 
## colvarindex:  1 == 29   1 == 1   1 == 1 
## colvarindex:  1 == 29   1 == 1   1 == 2 
## colvarindex:  1 == 29   1 == 2   1 == 1 
## colvarindex:  1 == 29   1 == 2   1 == 2 
## colvarindex:  1 == 29   1 == 3   1 == 1 
## colvarindex:  1 == 29   1 == 3   1 == 2 
## End of for, or  2 
## Data rows: Row  30 , observation (or)  2 , rowidname sexvalue , contents:  _NONMISS_ 
## colvarindex:  1 == 30   1 == 1   1 == 1 
## colvarindex:  1 == 30   1 == 1   1 == 2 
## colvarindex:  1 == 30   1 == 2   1 == 1 
## colvarindex:  1 == 30   1 == 2   1 == 2 
## colvarindex:  1 == 30   1 == 3   1 == 1 
## colvarindex:  1 == 30   1 == 3   1 == 2 
## End of for, or  2 
## Data rows: Row  31 , observation (or)  2 , rowidname sexvalue , contents:  _NONMISS_ 
## colvarindex:  1 == 31   1 == 1   1 == 1 
## colvarindex:  1 == 31   1 == 1   1 == 2 
## colvarindex:  1 == 31   1 == 2   1 == 1 
## colvarindex:  1 == 31   1 == 2   1 == 2 
## colvarindex:  1 == 31   1 == 3   1 == 1 
## colvarindex:  1 == 31   1 == 3   1 == 2 
## End of for, or  2 
## Data rows: Row  32 , observation (or)  2 , rowidname sexvalue , contents:  _NONMISS_ 
## colvarindex:  1 == 32   1 == 1   1 == 1 
## colvarindex:  1 == 32   1 == 1   1 == 2 
## colvarindex:  1 == 32   1 == 2   1 == 1 
## colvarindex:  1 == 32   1 == 2   1 == 2 
## colvarindex:  1 == 32   1 == 3   1 == 1 
## colvarindex:  1 == 32   1 == 3   1 == 2 
## End of for, or  2 
## Data rows: Row  33 , observation (or)  2 , rowidname sexvalue , contents:  _NONMISS_ 
## colvarindex:  1 == 33   1 == 1   1 == 1 
## colvarindex:  1 == 33   1 == 1   1 == 2 
## colvarindex:  1 == 33   1 == 2   1 == 1 
## colvarindex:  1 == 33   1 == 2   1 == 2 
## colvarindex:  1 == 33   1 == 3   1 == 1 
## colvarindex:  1 == 33   1 == 3   1 == 2 
## End of for, or  2 
## Data rows: Row  36 , observation (or)  2 , rowidname sexvalue , contents:  _NONMISS_ 
## colvarindex:  1 == 36   1 == 1   1 == 1 
## colvarindex:  1 == 36   1 == 1   1 == 2 
## colvarindex:  1 == 36   1 == 2   1 == 1 
## colvarindex:  1 == 36   1 == 2   1 == 2 
## colvarindex:  1 == 36   1 == 3   1 == 1 
## colvarindex:  1 == 36   1 == 3   1 == 2 
## End of for, or  2 
## Data rows: Row  38 , observation (or)  2 , rowidname sexvalue , contents:  _NONMISS_ 
## colvarindex:  1 == 38   1 == 1   1 == 1 
## colvarindex:  1 == 38   1 == 1   1 == 2 
## colvarindex:  1 == 38   1 == 2   1 == 1 
## colvarindex:  1 == 38   1 == 2   1 == 2 
## colvarindex:  1 == 38   1 == 3   1 == 1 
## colvarindex:  1 == 38   1 == 3   1 == 2 
## End of for, or  2 
## Data rows: Row  40 , observation (or)  2 , rowidname sexvalue , contents:  _NONMISS_ 
## colvarindex:  1 == 40   1 == 1   1 == 1 
## colvarindex:  1 == 40   1 == 1   1 == 2 
## colvarindex:  1 == 40   1 == 2   1 == 1 
## colvarindex:  1 == 40   1 == 2   1 == 2 
## colvarindex:  1 == 40   1 == 3   1 == 1 
## colvarindex:  1 == 40   1 == 3   1 == 2 
## End of for, or  2
```

```r
cat("HTML stored as: ", normalizePath(resHtmlFile), "\n")
```

```
## HTML stored as:  /home/ma/R/x86_64-redhat-linux-gnu-library/3.2/rrdfqbpresent/extdata/sample-html/DC-DEMO-sample.html
```

## For development

### Setup


```r
store <- new.rdf()  # Initialize
cat("Loading ", dataCubeFile, "\n")
```

```
## Loading  /home/ma/R/x86_64-redhat-linux-gnu-library/3.2/rrdfqbcrndex/extdata/sample-rdf/DC-DEMO-sample.ttl
```

```r
temp<-load.rdf(dataCubeFile, format="TURTLE", appendTo= store)
summarize.rdf(store)
```

```
## [1] "Number of triples: 3094"
```

```r
dsdName<- GetDsdNameFromCube( store )
domainName<- GetDomainNameFromCube( store )
forsparqlprefix<- GetForSparqlPrefix( domainName )
```

### Check GetTwoDimTableFromQb


```r
dataCubeFile<- system.file("extdata/sample-rdf", "DC-DEMO-sample.ttl", package="rrdfqbcrndex")
store <- new.rdf()  # Initialize
cat("Loading ", dataCubeFile, "\n")
```

```
## Loading  /home/ma/R/x86_64-redhat-linux-gnu-library/3.2/rrdfqbcrndex/extdata/sample-rdf/DC-DEMO-sample.ttl
```

```r
temp<-load.rdf(dataCubeFile, format="TURTLE", appendTo= store)
dsdName<- GetDsdNameFromCube( store )
domainName<- GetDomainNameFromCube( store )
forsparqlprefix<- GetForSparqlPrefix( domainName )
cat("dsdName: ", dsdName, "\n")
```

```
## dsdName:  dsd-DEMO
```

```r
cat("domainName: ", domainName, "\n")
```

```
## domainName:  DEMO
```

```r
cat("forsparqlprefix: ", forsparqlprefix, "\n")
```

```
## forsparqlprefix:  prefix rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
## prefix skos: <http://www.w3.org/2004/02/skos/core#>
## prefix prov: <http://www.w3.org/ns/prov#>
## prefix rdfs: <http://www.w3.org/2000/01/rdf-schema#>
## prefix dcat: <http://www.w3.org/ns/dcat#>
## prefix owl: <http://www.w3.org/2002/07/owl#>
## prefix xsd: <http://www.w3.org/2001/XMLSchema#>
## prefix qb: <http://purl.org/linked-data/cube#>
## prefix pav: <http://purl.org/pav>
## prefix dct: <http://purl.org/dc/terms/>
## prefix mms: <http://rdf.cdisc.org/mms#>
## prefix cts: <http://rdf.cdisc.org/ct/schema#>
## prefix qb: <http://purl.org/linked-data/cube#>
## prefix rrdfqbcrnd0: <http://www.example.org/rrdfqbcrnd0/>
## prefix code: <http://www.example.org/dc/code/>
## prefix dccs: <http://www.example.org/dc/demo/dccs/>
## prefix ds: <http://www.example.org/dc/demo/ds/>
## prefix crnd-dimension: <http://www.example.org/dc/dimension#>
## prefix crnd-attribute: <http://www.example.org/dc/attribute#>
## prefix crnd-measure: <http://www.example.org/dc/measure#>
## 
```

```r
coldim<- c("crnd-attribute:colno", "crnd-attribute:cellpartno", "crnd-dimension:trt01a" )
rowdim<- c("crnd-attribute:rowno", "crnd-dimension:agegr1", "crnd-dimension:race",
           "crnd-dimension:ethnic", "crnd-dimension:sex", "crnd-dimension:procedure" )
xqbtest<- GetTwoDimTableFromQb( store, forsparqlprefix, domainName, rowdim, coldim )

dimensionsRq <- GetDimensionsSparqlQuery( forsparqlprefix )
dimensions<- sparql.rdf(store, dimensionsRq)

attributesRq<- GetAttributesSparqlQuery( forsparqlprefix )
attributes<- sparql.rdf(store, attributesRq)

observationsDescriptionRq<- GetObservationsWithDescriptionSparqlQuery( forsparqlprefix, domainName, dimensions, attributes )
observationsDesc<- as.data.frame(sparql.rdf(store, observationsDescriptionRq ), stringsAsFactors=FALSE)
```

### View a specific observation.

The observation is specified in the values part of the SPARQL query.


```r
cube.observations.rq<-  paste( forsparqlprefix,
'
select *
where { 
?s a qb:Observation ; 
?p ?o .
values (?s) {
(ds:obs029)
}
}
',
"\n"                               
)

cube.observations<- sparql.rdf(store, cube.observations.rq)
knitr::kable(cube.observations)
```



|s         |p                          |o                                                                            |
|:---------|:--------------------------|:----------------------------------------------------------------------------|
|ds:obs029 |crnd-dimension:factor      |code:factor-age                                                              |
|ds:obs029 |crnd-attribute:cellpartno  |1                                                                            |
|ds:obs029 |crnd-measure:measure       |75.666666667                                                                 |
|ds:obs029 |crnd-dimension:race        |code:race-_ALL_                                                              |
|ds:obs029 |crnd-dimension:sex         |code:sex-_ALL_                                                               |
|ds:obs029 |crnd-dimension:procedure   |code:procedure-mean                                                          |
|ds:obs029 |rdf:type                   |qb:Observation                                                               |
|ds:obs029 |rdfs:comment               |Statistic for number of records/Statistics for factor with the dimensions XX |
|ds:obs029 |crnd-dimension:trt01a      |code:trt01a-Xanomeline_Low_Dose                                              |
|ds:obs029 |crnd-attribute:measurefmt  |%6.1f                                                                        |
|ds:obs029 |crnd-attribute:rowno       |7                                                                            |
|ds:obs029 |crnd-attribute:unit        |NA                                                                           |
|ds:obs029 |crnd-dimension:agegr1      |code:agegr1-_ALL_                                                            |
|ds:obs029 |qb:dataSet                 |ds:dataset-DEMO                                                              |
|ds:obs029 |crnd-dimension:ethnic      |code:ethnic-_ALL_                                                            |
|ds:obs029 |crnd-attribute:denominator |                                                                             |
|ds:obs029 |rdfs:label                 |29                                                                           |
|ds:obs029 |crnd-attribute:colno       |2                                                                            |

### View formating of measure


```r
cube.measurefmt.rq<-  paste( forsparqlprefix,
'
select distinct ?procedure ?measurefmt
where { 
?s a qb:Observation ; 
crnd-dimension:procedure ?procedure ;
crnd-attribute:measurefmt ?measurefmt .
}
',
"\n"                               
)

cube.measurefmt<- sparql.rdf(store, cube.measurefmt.rq)
knitr::kable(cube.measurefmt)
```



|procedure              |measurefmt |
|:----------------------|:----------|
|code:procedure-q3      |%6.1f      |
|code:procedure-count   |%6.0f      |
|code:procedure-percent |%6.1f      |
|code:procedure-std     |%6.1f      |
|code:procedure-min     |%6.1f      |
|code:procedure-n       |%6.0f      |
|code:procedure-median  |%6.1f      |
|code:procedure-q1      |%6.1f      |
|code:procedure-max     |%6.1f      |
|code:procedure-mean    |%6.1f      |

### Columns

The contents of the 

```r
cols.rq<- GetRownoColnoCellpartnoSparqlQuery( forsparqlprefix )
cols<- data.frame(sparql.rdf(store, cols.rq))
knitr::kable(cols)
```



|rowno |colno |cellpartno |
|:-----|:-----|:----------|
|1     |1     |1          |
|1     |1     |2          |
|1     |2     |1          |
|1     |2     |2          |
|1     |3     |1          |
|1     |3     |2          |
|10    |1     |1          |
|10    |2     |1          |
|10    |3     |1          |
|11    |1     |1          |
|11    |2     |1          |
|11    |3     |1          |
|18    |1     |1          |
|18    |1     |2          |
|18    |2     |1          |
|18    |2     |2          |
|18    |3     |1          |
|18    |3     |2          |
|19    |1     |1          |
|19    |1     |2          |
|19    |2     |1          |
|19    |2     |2          |
|19    |3     |1          |
|19    |3     |2          |
|2     |1     |1          |
|2     |1     |2          |
|2     |2     |1          |
|2     |2     |2          |
|2     |3     |1          |
|2     |3     |2          |
|20    |1     |1          |
|20    |1     |2          |
|20    |2     |1          |
|20    |2     |2          |
|20    |3     |1          |
|20    |3     |2          |
|21    |1     |1          |
|21    |1     |2          |
|21    |2     |1          |
|21    |2     |2          |
|21    |3     |1          |
|21    |3     |2          |
|22    |1     |1          |
|22    |1     |2          |
|22    |2     |1          |
|22    |2     |2          |
|22    |3     |1          |
|22    |3     |2          |
|23    |1     |1          |
|23    |1     |2          |
|23    |2     |1          |
|23    |2     |2          |
|23    |3     |1          |
|23    |3     |2          |
|24    |1     |1          |
|24    |1     |2          |
|24    |2     |1          |
|24    |2     |2          |
|24    |3     |1          |
|24    |3     |2          |
|25    |1     |1          |
|25    |1     |2          |
|25    |2     |1          |
|25    |2     |2          |
|25    |3     |1          |
|25    |3     |2          |
|26    |1     |1          |
|26    |2     |1          |
|26    |3     |1          |
|27    |1     |1          |
|27    |2     |1          |
|27    |3     |1          |
|28    |1     |1          |
|28    |2     |1          |
|28    |3     |1          |
|29    |1     |1          |
|29    |2     |1          |
|29    |3     |1          |
|3     |1     |1          |
|3     |1     |2          |
|3     |2     |1          |
|3     |2     |2          |
|3     |3     |1          |
|3     |3     |2          |
|30    |1     |1          |
|30    |2     |1          |
|30    |3     |1          |
|31    |1     |1          |
|31    |2     |1          |
|31    |3     |1          |
|32    |1     |1          |
|32    |2     |1          |
|32    |3     |1          |
|33    |1     |1          |
|33    |2     |1          |
|33    |3     |1          |
|36    |1     |1          |
|36    |1     |2          |
|36    |2     |1          |
|36    |2     |2          |
|36    |3     |1          |
|36    |3     |2          |
|38    |1     |1          |
|38    |1     |2          |
|38    |2     |1          |
|38    |2     |2          |
|38    |3     |1          |
|38    |3     |2          |
|4     |1     |1          |
|4     |2     |1          |
|4     |3     |1          |
|40    |1     |1          |
|40    |1     |2          |
|40    |2     |1          |
|40    |2     |2          |
|40    |3     |1          |
|40    |3     |2          |
|5     |1     |1          |
|5     |2     |1          |
|5     |3     |1          |
|6     |1     |1          |
|6     |2     |1          |
|6     |3     |1          |
|7     |1     |1          |
|7     |2     |1          |
|7     |3     |1          |
|8     |1     |1          |
|8     |2     |1          |
|8     |3     |1          |
|9     |1     |1          |
|9     |2     |1          |
|9     |3     |1          |


# Session information

```r
sessionInfo()
```

```
## R version 3.2.3 (2015-12-10)
## Platform: x86_64-redhat-linux-gnu (64-bit)
## Running under: Fedora 23 (Workstation Edition)
## 
## locale:
##  [1] LC_CTYPE=en_GB.UTF-8          LC_NUMERIC=C                 
##  [3] LC_TIME=en_GB.UTF-8           LC_COLLATE=en_GB.UTF-8       
##  [5] LC_MONETARY=en_GB.UTF-8       LC_MESSAGES=en_GB.UTF-8      
##  [7] LC_PAPER=en_GB.UTF-8          LC_NAME=en_GB.UTF-8          
##  [9] LC_ADDRESS=en_GB.UTF-8        LC_TELEPHONE=en_GB.UTF-8     
## [11] LC_MEASUREMENT=en_GB.UTF-8    LC_IDENTIFICATION=en_GB.UTF-8
## 
## attached base packages:
## [1] methods   stats     graphics  grDevices utils     datasets  base     
## 
## other attached packages:
##  [1] rrdfqbpresent_0.2.0 rrdfqbcrndex_0.2.0  rrdfqbcrnd0_0.2.0  
##  [4] rrdfqb_0.2.0        RCurl_1.95-4.7      bitops_1.0-6       
##  [7] xlsx_0.5.7          xlsxjars_0.6.1      rrdf_2.1.0         
## [10] rrdflibs_1.4.0      rJava_0.9-7        
## 
## loaded via a namespace (and not attached):
## [1] formatR_1.2.1   magrittr_1.5    evaluate_0.8    highr_0.5.1    
## [5] stringi_1.0-1   rrdfcdisc_0.2.0 tools_3.2.3     stringr_1.0.0  
## [9] knitr_1.12
```

